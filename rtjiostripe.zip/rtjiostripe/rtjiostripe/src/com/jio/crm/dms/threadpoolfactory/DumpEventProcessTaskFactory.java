package com.jio.crm.dms.threadpoolfactory;

import com.jio.crm.dms.ha.DumpEventProcessTask;
import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

public class DumpEventProcessTaskFactory implements PooledObjectFactory<DumpEventProcessTask> {

	 private static final String OBJECT_NAME = "DumpEventProcessTask";
	  private static final String CLASS_NAME = DumpEventProcessTaskFactory.class.getSimpleName();

	  @Override
	  public void activateObject(PooledObject<DumpEventProcessTask> arg0) throws Exception {
	  }

	  @Override
	  public void destroyObject(PooledObject<DumpEventProcessTask> arg0) throws Exception {
	  }

	  @Override
	  public PooledObject<DumpEventProcessTask> makeObject() throws Exception {
	    return new DefaultPooledObject<>(new DumpEventProcessTask());
	  }

	  @Override
	  public void passivateObject(PooledObject<DumpEventProcessTask> arg0) throws Exception {
	  }

	  @Override
	  public boolean validateObject(PooledObject<DumpEventProcessTask> arg0) {
	    return false;
	  }
	
}
