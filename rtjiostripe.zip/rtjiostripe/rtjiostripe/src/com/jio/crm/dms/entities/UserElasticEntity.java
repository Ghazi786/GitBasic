package com.jio.crm.dms.entities;

public class UserElasticEntity {

}
