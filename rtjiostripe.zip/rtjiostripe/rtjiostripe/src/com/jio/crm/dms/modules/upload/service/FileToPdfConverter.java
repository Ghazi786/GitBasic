/**
 * 
 */
package com.jio.crm.dms.modules.upload.service;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.eclipse.jetty.http.HttpStatus;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.jio.crm.dms.exceptions.BaseException;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class FileToPdfConverter {
	private static FileToPdfConverter fileToPdfConverter = null;

	private FileToPdfConverter() {

	}

	public static FileToPdfConverter getIndtance() {
		if (fileToPdfConverter == null) {
			fileToPdfConverter = new FileToPdfConverter();
		}
		return fileToPdfConverter;
	}

	public boolean convertImageToPdf(byte[] byteArray, String destPath, FileSystem fs) throws BaseException {

		try {

			Path path = new Path(destPath);

			FSDataOutputStream out = fs.create(path);
//			Document document = new Document(PageSize.A4, 20.0f, 20.0f, 20.0f, 150.0f);
//			PdfWriter writer = PdfWriter.getInstance(document, out);
			Image image = Image.getInstance(byteArray);
//			image.scaleToFit(PageSize.A4.getWidth(), PageSize.A4.getHeight());
//			float x = (PageSize.A4.getWidth() - image.getScaledWidth()) / 2;
//			float y = (PageSize.A4.getHeight() - image.getScaledHeight()) / 2;

			float w = image.getScaledWidth();
			float h = image.getScaledHeight();
			Rectangle page = new Rectangle(w + 20, h + 20);
			Document document = new Document(page, 10, 10, 10, 10);
			PdfWriter writer = PdfWriter.getInstance(document, out);
//			image.setAbsolutePosition(x, y);
			writer.setFullCompression();

			document.open();
			document.add(image);
			document.close();
			writer.close();
			System.out.println("Image file converted to pdf Successfully");
		} catch (Exception e) {
			
			System.out.println("Image Converting to padf Error: "+e.getMessage());
			
			e.printStackTrace();
			throw new BaseException(HttpStatus.BAD_REQUEST_400,
					e.getMessage());
		}

		return true;
	}

	public void compressPdfFile(byte[] byteArray, String destPath, FileSystem fs) throws BaseException {
		try {
			Path path = new Path(destPath);

			FSDataOutputStream out = fs.create(path);
			PdfReader reader = new PdfReader(byteArray);

			PdfStamper pdfStamper = new PdfStamper(reader, out);
			pdfStamper.setFullCompression();
			pdfStamper.close();
			reader.close();
		

			System.out.println("pdf created and compress successfully");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while craeteing PDF in method compressPdfFile:"+e.getMessage());
			throw new BaseException(HttpStatus.BAD_REQUEST_400,
					e.getMessage());

		}
	}
}
