package com.jio.crm.dms.utils;

/**
 * this class used to print message to console for debugging purpose
 * @author Arun2.Maurya
 *
 */
public class StackTrace {

	/**
	 * 
	 * @param msg
	 */
	public static void printToConsole(String msg){
		System.out.println(msg);
	}
	
}
