package com.jio.crm.dms.core;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Base controller class which will be implemented by every controllers
 * @author Barun.Rai
 * 
 */
public interface BaseController {

	public  BaseResponse<?> processGet(HttpServletRequest req, HttpServletResponse resp);

	public BaseResponse<?> processPost(HttpServletRequest req, HttpServletResponse resp);

}
