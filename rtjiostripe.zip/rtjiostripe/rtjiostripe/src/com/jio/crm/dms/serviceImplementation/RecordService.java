package com.jio.crm.dms.serviceImplementation;

import java.io.IOException;
import java.util.List;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.jio.crm.dms.node.es.ESOperationImpl;
import com.jio.crm.dms.node.startup.DmsBootStrapper;
import com.jio.crm.dms.serviceInterface.RecordInterface;
import com.jio.crm.dms.threads.RecordProcess;
import com.jio.crm.dms.utils.Ranked;
import com.jio.telco.framework.pool.PoolingManager;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import au.com.bytecode.opencsv.bean.CsvToBean;

public class RecordService implements RecordInterface {
	private static RecordService service;

	public static RecordService getInstance() {
		if (service == null) {
			synchronized (RecordService.class) {
				if (service == null) {
					service = new RecordService();
				}
			}
		}
		return service;
	}

	private static RecordProcess recordProcess;

	private long startMillis = System.currentTimeMillis();
	private Gson Json = new Gson();

	@Override
	public void processRecord(CSVReader reader) {
		int x = 0;
		System.out.println("in process record");
		try {
			// CSVReader reader = new CSVReader(new FileReader(file), ',' , '"' , 1);
			CsvToBean<Ranked> csv = new CsvToBean<Ranked>();
			List<Ranked> list = csv.parse(setColumMapping(), reader);
			for (Ranked object : list) {
				// Ranked ranked = (Ranked) object;
				ESOperationImpl.getInstance().addRecord(object);
				System.out.println("object " + object);
				x++;
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Record count is :" + x);

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static ColumnPositionMappingStrategy<Ranked> setColumMapping() {
		ColumnPositionMappingStrategy<Ranked> strategy = new ColumnPositionMappingStrategy<Ranked>();
		strategy.setType(Ranked.class);
		String[] columns = new String[] { "rank", "name", "prm_id", "parent_name", "parent_prm_id", "circle", "city",
				"jio_point", "jio_centre", "product_type", "no_of_sale", "total_amount" };
		strategy.setColumnMapping(columns);
		return strategy;
	}

	@Override
	public void calculateToken(JSONObject recordJson, String id) throws Exception {
		try {
		recordProcess = (RecordProcess) PoolingManager.getPoolingManager().borrowObject(RecordProcess.class);
		recordProcess.setRankData(recordJson);
		recordProcess.setId(id);
		DmsBootStrapper.getInstance().getDappExecutor().execute(recordProcess);
	}catch (Exception e) {
		e.printStackTrace();
		System.out.println(e + " " + e.getMessage());
	}
	}

}
