package com.jio.crm.dms.threadpoolfactory;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.AsyncContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jio.crm.dms.core.BaseContextMapper;
import com.jio.crm.dms.core.BaseEventBean;
import com.jio.crm.dms.core.BaseResponse;
import com.jio.crm.dms.core.DispatcherBaseController;
import com.jio.crm.dms.core.HttpRequestMethod;
import com.jio.crm.dms.ha.EventDumpTask;
import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.crm.dms.node.startup.DmsBootStrapper;
import com.jio.crm.dms.utils.SubscriptionEngineUtils;

public class EventAckAnnotationRequestDispatcher implements Runnable {

	private BaseEventBean eventPojo;
	private HttpServletRequest request;
	private DispatcherBaseController controller;
	private HttpServletResponse response;
	private AsyncContext context;

	public EventAckAnnotationRequestDispatcher(BaseEventBean eventPojo, HttpServletRequest request,
			HttpServletResponse response, DispatcherBaseController controller, AsyncContext context) {
		super();
		this.eventPojo = eventPojo;
		this.request = request;
		this.controller = controller;
		this.response = response;
		this.context = context;
	}

	@Override
	public void run() {

		BaseResponse<?> controllerresponse = null;
		try {

			DmsBootStrapper.getInstance().getThreadPoolService().execute(new EventDumpTask(eventPojo));

			String method = this.request.getMethod();
			if (HttpRequestMethod.valueOf(method).name() != null) {

				java.lang.reflect.Method methodCalled = null;
				if (eventPojo.getEventName() != null && !eventPojo.getEventName().isEmpty()
						&& BaseContextMapper.EVENT_MAPPING.containsKey(eventPojo.getEventName().trim())) {
					methodCalled = controller.getClass().getMethod(
							BaseContextMapper.EVENT_MAPPING.get(eventPojo.getEventName().trim()),
							HttpServletRequest.class, HttpServletResponse.class);

				} else {
					String path = request.getPathInfo();
					methodCalled = controller.getClass().getMethod(
							BaseContextMapper.PATH_MAPPING.get(HttpRequestMethod.valueOf(method).name()).get(path),
							HttpServletRequest.class, HttpServletResponse.class);
				}
				controllerresponse = (BaseResponse<?>) methodCalled.invoke(controller, request, response);

			} else {
				controllerresponse = new BaseResponse<String>(null, false, "No Such Method", 400, null);
			}
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			controllerresponse = new BaseResponse(null, false, "Requested mapping not found", 404, null);
		} finally {
			try {

				this.context.complete();
				SubscriptionEngineUtils.sendAsyncResponseToELB(eventPojo, controllerresponse, this.request.getInputStream());
			} catch (IOException e) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
			}
		}

	}

}
