package com.jio.crm.dms.utils;

public enum Category {
	FeatureDocument("FeatureDocument"),
	SRS("SRS"),
	Design("Design"), 
	Coding("Coding"), 
	UnitTesting("UnitTesting"), 
	IntegrationTesting("IntegrationTesting"), 
	LoadTesting("LoadTesting"), 
	BugFix("BugFix"), 
	Defect("Defect"), 
	Enhancement("Enhancement"), 
	Documentation("Documentation");
	
	String name;

	Category(String name) {
		this.name = name;
	}
	
	public static Category getByName(String name) {
		

			if (name.equalsIgnoreCase(FeatureDocument.name)) {
				return Category.FeatureDocument;
			} else if (name.equalsIgnoreCase(SRS.name)) {
				return Category.SRS;
			} else if (name.equalsIgnoreCase(Design.name)) {
				return Category.Design;
			} else if (name.equalsIgnoreCase(Coding.name)) {
				return Category.Coding;
			} else if (name.equalsIgnoreCase(UnitTesting.name)) {
				return Category.UnitTesting;
			} else if (name.equalsIgnoreCase(IntegrationTesting.name)) {
				return Category.IntegrationTesting;
			} else if (name.equalsIgnoreCase(LoadTesting.name)) {
				return Category.LoadTesting;
			} else if (name.equalsIgnoreCase(BugFix.name)) {
				return Category.BugFix;
			}else if (name.equalsIgnoreCase(Defect.name)) {
				return Category.Defect;
			} else if (name.equalsIgnoreCase(Enhancement.name)) {
				return Category.Enhancement;
			}else if (name.equalsIgnoreCase(Documentation.name)) {
				return Category.Documentation;
			}else {
				return null;
			}
		}
	
}
