package com.jio.crm.dms.kafka.producer;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

public class UOLProducerTaskFactory implements PooledObjectFactory<UOLProducerTask>{

	  private static final String OBJECT_NAME = "UOLProducerTask";
	  private static final String CLASS_NAME = UOLProducerTaskFactory.class.getSimpleName();
	  @Override
	  public PooledObject<UOLProducerTask> makeObject() throws Exception {
		  return new DefaultPooledObject<>(new UOLProducerTask());
	  }
	  @Override
	  public void destroyObject(PooledObject<UOLProducerTask> p) throws Exception {
	    
	    
	  }
	  @Override
	  public boolean validateObject(PooledObject<UOLProducerTask> p) {
	    
	    return false;
	  }
	  @Override
	  public void activateObject(PooledObject<UOLProducerTask> p) throws Exception {
	    
	    
	  }
	  @Override
	  public void passivateObject(PooledObject<UOLProducerTask> p) throws Exception {
	    
	    
	  }
}
