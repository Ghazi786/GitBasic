package com.jio.crm.dms.core;

public enum ResponseStatus {

}
