package com.jio.crm.dms.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.elastic.search.config.ElasticConfig;
import com.elastic.search.config.IndexConfig;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.subscriptions.modules.bean.APIKey;
import com.unboundid.util.Base64;

/**
 * @author Alpesh.Sonar
 *
 */
public class EncryptUtils {

	private static EncryptUtils encryptUtils = new EncryptUtils();

	private final String DEFAULT_ENCODING = "UTF-8";


	public static EncryptUtils getInstance() {

		return encryptUtils;
	}

	private EncryptUtils() {
	}

	/**
	 * @param text
	 * @return
	 */
	public String base64encode(String text) {
		try {
			return Base64.encode(text.getBytes(DEFAULT_ENCODING)).replace("\n", "^").replace("\r", "~");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}

	/**
	 * @param text
	 * @return
	 */
	public String base64decode(String text) {
		try {
			text = text.replace("^", "\n").replace("~", "\r");
			return new String(Base64.decode(text), DEFAULT_ENCODING);
		} catch (IOException | ParseException e) {
			return null;
		}
	}

	/**
	 * @param siteId
	 * @param vendorId
	 * @param month
	 * @return
	 */
	public String jwtEncode(String siteId, String vendorId, int month) {
		try {

			DateTime now = DateTime.now();
			DateTime sixMonthsLater = now.plusMonths(month);
			Algorithm algorithm = Algorithm.HMAC256("secret");
			String token = JWT.create().withIssuer(siteId).withIssuedAt(new Date()).withClaim("vendor-id", vendorId)
					.withClaim("month", month).withExpiresAt(sixMonthsLater.toDate()).sign(algorithm);

			return token;
		} catch (JWTCreationException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					EncryptUtils.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return null;
	}

	/**
	 * @param token
	 * @return
	 */
	public Map<String, Object> jwtDecode(String token) {

		Map<String, Object> decode = new HashMap<>();

		try {
			DecodedJWT jwt = JWT.decode(token);
			decode.put("month", jwt.getClaim("month").asInt());
			decode.put("vendorId", jwt.getClaim("vendor-id").asString());
			decode.put("siteId", jwt.getIssuer());
			decode.put("expires-at", jwt.getExpiresAt());
			return decode;
		} catch (JWTCreationException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					EncryptUtils.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return null;
	}

	/**
	 * @param token
	 * @return
	 */
	public String jwtRenew(String token) {
		Map<String, Object> decode = jwtDecode(token);
		return jwtEncode((String) decode.get("siteId"), (String) decode.get("vendorId"),
				Integer.parseInt((String) decode.get("month")));
	}

	// api key encryptor
	/**
	 * @param data
	 * @return
	 */
	public String apiKeyEncryotor(String data) {
		String apiKey = base64encode(data);
		return apiKey;
	}

	// api key decryotor
	/**
	 * @param data
	 * @return
	 */
	public String apiKeyDecryotor(String data) {
		String apiKeyDescrypted = base64decode(data);
		return apiKeyDescrypted;
	}

	public static void main(String[] args) throws Exception {

		EncryptUtils encryptUtils = getInstance();

		IndexConfig indexConfig = new IndexConfig();
		indexConfig.setIndexName("dev_subscriptionengine");

		ElasticConfig elasticConfig = new ElasticConfig();
		elasticConfig.setClusterName("development_cluster");
		elasticConfig.setUserName("elastic");
		elasticConfig.setPassword("changeme");
		elasticConfig.setHost("10.64.216.92:9333");
		
		SessionFactory factory = new SessionFactory.builder(indexConfig).withElasticConfig(elasticConfig)
				.buildSessionFactory();

		Session session = factory.getSession();
		
		///// BASE 64 ENCODE
		String base = encryptUtils.base64encode("alpesh.sonar@ril.com:password123");
		System.out.println("BASE 64 ENCODE " + base);
		System.out.println("BASE 64 DECODE " + encryptUtils.base64decode(base));

		APIKey key1 = new APIKey();
		key1.setExpireOn("On changed password");
		key1.setSiteId("4ff24f00-13ef-106c-a827-9cb6548b78e0");
		key1.setType("BASIC");
		key1.setKey(base);
		//session.save(key1);
		
		
		// API KEY
		String vendorId = "2679a600-4f90-106c-a827-9cb6548b78e0";
		String siteId = "4ff24f00-13ef-106c-a827-9cb6548b78e0";
		String data = siteId + ":" + vendorId;
		String apiKey = encryptUtils.apiKeyEncryotor(data);
		System.out.println("API KEY " + apiKey);
		System.out.println("API KEY DECODE " + encryptUtils.apiKeyDecryotor(apiKey));

		key1 = new APIKey();
		key1.setExpireOn("Never Expire");
		key1.setSiteId("4ff24f00-13ef-106c-a827-9cb6548b78e0");
		key1.setType("API_KEY");
		key1.setKey(apiKey);
		//session.save(key1);
		
		// JWT
		String token = encryptUtils.jwtEncode(siteId, vendorId, 1);
		System.out.println(" TOKEN " + token);
		System.out.println(" JWT DATA " + encryptUtils.jwtDecode(token));
		
		key1 = new APIKey();
		key1.setExpireOn("Expiry date");
		key1.setSiteId("4ff24f00-13ef-106c-a827-9cb6548b78e0");
		key1.setType("BEARER");
		key1.setKey(token);
		//session.save(key1);
		

	}
}
