package com.jio.crm.dms.utils;

//Dummy class..can be deleted
//used to show the usage of dapp sdk
public class Ranked {
	
	private long rank;
	private String name;
	private String prm_id;
	private String parent_prm_id;
	private String circle;
	private String city;
	private String jio_point;
	private String jio_centre;
	private String product_type;
	private long no_of_sale;
	private long total_amount;
	public long getRank() {
		return rank;
	}
	public void setRank(long rank) {
		this.rank = rank;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrm_id() {
		return prm_id;
	}
	public void setPrm_id(String prm_id) {
		this.prm_id = prm_id;
	}
	public String getParent_prm_id() {
		return parent_prm_id;
	}
	public void setParent_prm_id(String parent_prm_id) {
		this.parent_prm_id = parent_prm_id;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getJio_point() {
		return jio_point;
	}
	public void setJio_point(String jio_point) {
		this.jio_point = jio_point;
	}
	public String getJio_centre() {
		return jio_centre;
	}
	public void setJio_centre(String jio_centre) {
		this.jio_centre = jio_centre;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public long getNo_of_sale() {
		return no_of_sale;
	}
	public void setNo_of_sale(long no_of_sale) {
		this.no_of_sale = no_of_sale;
	}
	public long getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(long total_amount) {
		this.total_amount = total_amount;
	}
	
	@Override
	   public String toString()
	   {
	      return "Ranked data [rank=" + rank + ", name=" + name +"]";
	   }
}
