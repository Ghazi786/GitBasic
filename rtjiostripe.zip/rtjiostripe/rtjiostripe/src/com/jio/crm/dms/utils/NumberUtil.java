package com.jio.crm.dms.utils;

public class NumberUtil {

	public static int stringToNumber(String number) {

		try {
			
			if (number == null)
				return 0;

			return Integer.parseInt(number);

		} catch (Exception e) {
		}
		return 0;
	}

}
