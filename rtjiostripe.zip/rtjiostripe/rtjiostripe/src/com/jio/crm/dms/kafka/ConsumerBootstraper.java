package com.jio.crm.dms.kafka;

public class ConsumerBootstraper {

	private static ConsumerBootstraper instance;

	private ConsumerBootstraper() {
	}

	public static ConsumerBootstraper getInstance() {
		if (instance == null) {
			instance = new ConsumerBootstraper();
		}
		return instance;
	}

	public void startConsumer() {

		/*
		 * Runnable webhookExecuteConsumer = () -> {
		 * 
		 * try { WebhookExecuteConsumer.getInstance().consumer(); }
		 * 
		 * catch (Exception e) { e.printStackTrace(); }
		 * 
		 * };
		 * 
		 * Thread webhookExecuteConsumerThread = new Thread(webhookExecuteConsumer);
		 * webhookExecuteConsumerThread.start();
		 */

	}

}
