/**
 * 
 */
package com.jio.crm.dms.modules.upload.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.JsonNode;
import com.jio.crm.dms.bean.FileDocument;
import com.jio.crm.dms.configurationManager.ConfigParamsEnum;
import com.jio.crm.dms.hdfs.HdfsConfigurationManager;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.unboundid.util.json.JSONObject;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class ExcelService {

	/**
	 * 
	 */
	public ExcelService() {
		// TODO Auto-generated constructor stub
	}
	
	public HashMap<String, List<FileDocument>> readSearchParameter(XSSFSheet sheet,XSSFWorkbook workbook) {
		
		HashMap<String, List<FileDocument>> searchParameters=new HashMap<String, List<FileDocument>>();
		try {			

//			XSSFSheet sheet = workbook.getSheetAt(0);
//			sheet.removeRow(sheet.getRow(0));
			
			List<FileDocument> searchParam1=new ArrayList<FileDocument>();
			FileDocument data=null;
			Row row;
			
			for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
				row = sheet.getRow(i);
				if(i==0) {
					int lastColumn=row.getPhysicalNumberOfCells();
					Cell cellTemp=row.createCell(lastColumn);
					XSSFCellStyle style = workbook.createCellStyle();  
					style.setFillForegroundColor(IndexedColors.ROYAL_BLUE.getIndex()); 
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
					cellTemp.setCellValue("Remarks");
					cellTemp.setCellStyle(style); 
					continue;
				}
				data=new FileDocument();
//				row = sheet.getRow(i);
				if(row.getCell(0)!=null) {					
					row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
					data.setMobileNumber(row.getCell(0).getStringCellValue().trim());
				}
				if(row.getCell(1)!=null) {					
					row.getCell(1).setCellType(Cell.CELL_TYPE_STRING);
					data.setOrderId(row.getCell(1).getStringCellValue().trim());
				}
				if(row.getCell(2)!=null) {					
					row.getCell(2).setCellType(Cell.CELL_TYPE_STRING);
					data.setCustomerId(row.getCell(2).getStringCellValue().trim());
				}
				if(row.getCell(3)!=null) {					
					row.getCell(3).setCellType(Cell.CELL_TYPE_STRING);
					data.setDocumentCategory(row.getCell(3).getStringCellValue().trim());
				}
				if(row.getCell(4)!=null) {
					row.getCell(4).setCellType(Cell.CELL_TYPE_STRING);
					data.setDocumentNumber(row.getCell(4).getStringCellValue().trim());
				}
								
				searchParam1.add(data);	
			}
			
			searchParameters.put("s1", searchParam1);
			//
//			sheet = workbook.getSheetAt(1);
//			sheet.removeRow(sheet.getRow(0));
//
//			List<Document> searchParam2=new ArrayList<Document>();
//			
//			for (int i = 1; i <= sheet.getPhysicalNumberOfRows(); i++) {
//				data=new Document();
//				row = sheet.getRow(i);
//				row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
//				data.setdocumentType(row.getCell(0).getStringCellValue().trim());
//				data.setCafNumber(row.getCell(1).getStringCellValue().trim());
//				data.setServiceId(row.getCell(2).getStringCellValue().trim());
//				data.setBusinessParterId(row.getCell(3).getStringCellValue().trim());
//				searchParam2.add(data);
//				
//			}
//			searchParameters.put("s2", searchParam2);
			

		} catch (Exception e) {
			System.out.println("Exception");
		}
		
		return searchParameters;
	
	}
}
