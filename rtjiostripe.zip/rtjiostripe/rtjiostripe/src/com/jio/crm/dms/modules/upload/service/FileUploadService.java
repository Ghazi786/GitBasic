package com.jio.crm.dms.modules.upload.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jio.crm.dms.core.BaseResponse;
import com.jio.crm.dms.exceptions.BaseException;
import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.crm.dms.modules.upload.repository.FileUploadRepository;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Card;
import com.stripe.model.Charge;
import com.stripe.model.Customer;
import com.stripe.model.Invoice;
import com.stripe.model.InvoiceItem;
import com.stripe.model.PaymentIntent;
import com.stripe.model.PaymentMethod;
import com.stripe.model.Price;
import com.stripe.model.Product;
import com.stripe.model.SetupIntent;
import com.stripe.model.Source;
import com.stripe.model.Subscription;
import com.stripe.model.Token;
import com.stripe.model.checkout.Session;
import com.stripe.param.SubscriptionCreateParams;
import com.stripe.param.SubscriptionCreateParams.PaymentSettings.SaveDefaultPaymentMethod;
import com.stripe.param.checkout.SessionCreateParams;

public class FileUploadService {

	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "inline; filename=\"";
	private FileUploadRepository fileRepositoryService = new FileUploadRepository();

	/**
	 * @param req
	 * @param uiFileName
	 * @return
	 * @throws IOException
	 * @throws BaseException
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 */
	public BaseResponse<Customer> uploadFile(HttpServletRequest req, String uiFileName) throws BaseException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> params = new HashMap<>();
		params.put("description", "My First Test Customer (created for API docs at https://www.stripe.com/docs/api)");
		params.put("email", "ghazi@gmail.com");

		Customer customer = null;
		try {
			customer = Customer.create(params);
			System.out.println(customer.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		final BaseResponse<Customer> baseResponse = new BaseResponse<>(customer);

		return baseResponse;
	}

	public BaseResponse<Customer> addCard(HttpServletRequest req, String uiFileName) throws BaseException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		try {
			// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

			Map<String, Object> retrieveParams = new HashMap<>();
			List<String> expandList = new ArrayList<>();
			expandList.add("sources");
			retrieveParams.put("expand", expandList);
			Customer customer = Customer.retrieve("cus_NfZKLq9cEeTwxS", retrieveParams, null);

			Map<String, Object> params = new HashMap<>();
			params.put("source", "tok_amex");

			Card card = (Card) customer.getSources().create(params);
			System.out.println(card);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public BaseResponse<Customer> chargeCustomer(HttpServletRequest req, String uiFileName) throws BaseException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		try {
			// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

			Map<String, Object> retrieveParams = new HashMap<>();
			List<String> expandList = new ArrayList<>();
			expandList.add("sources");
			retrieveParams.put("expand", expandList);
			Customer customer = Customer.retrieve("cus_NfZKLq9cEeTwxS", retrieveParams, null);

			Map<String, Object> params = new HashMap<>();
			params.put("amount", "10000");
			params.put("currency", "inr");
			params.put("customer", customer.getId());
			Charge charge = Charge.create(params);
			System.out.println(charge);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public BaseResponse<?> createCheckout() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		// Product
		Map<String, Object> productParams = new HashMap<String, Object>();
		productParams.put("name", "Lg Washing machine-2");
		Product product = null;
		try {
			product = Product.create(productParams);
			System.out.println(product.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// product end

		// price start
		Map<String, Object> priceParams = new HashMap<String, Object>();
		priceParams.put("unit_amount", 50000);
		priceParams.put("currency", "inr");
		priceParams.put("product", product.getId());
		Price price = null;
		try {
			price = Price.create(priceParams);
			System.out.println(price.toString());
		} catch (StripeException e) {
			e.printStackTrace();
		}

		// price end

		// checkout start
		List<HashMap<String, Object>> lineItems = new ArrayList<HashMap<String, Object>>();
		Map<String, Object> lineItem1 = new HashMap<String, Object>();
		lineItem1.put("price", price.getId());
		lineItem1.put("quantity", 2);
		lineItems.add((HashMap<String, Object>) lineItem1);
		Map<String, Object> checkout = new HashMap<String, Object>();
		checkout.put("success_url", "http://localhost:7050/#/mop/execute");
		checkout.put("line_items", lineItems);
		checkout.put("mode", "payment");
		checkout.put("customer", "cus_NfZKLq9cEeTwxS");
		Session session = null;
		try {
			session = Session.create(checkout);
			System.out.println(session.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// checkout end
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("url", session.getUrl());

		return new BaseResponse<>(hm);
	}

	public BaseResponse<?> createPaymentIntent() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");
		Map<String, Object> automaticPaymentMethods = new HashMap<String, Object>();
		automaticPaymentMethods.put("enabled", true);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("amount", 6000 * 100);
		params.put("currency", "inr");
		params.put("customer", "cus_NfZKLq9cEeTwxS");
		params.put("automatic_payment_methods", automaticPaymentMethods);
//		params.put("return_url", "https://stripe.com/docs/api/payment_intents/create");
		PaymentIntent paymentIntent = null;
		try {
			paymentIntent = PaymentIntent.create(params);
			System.out.println(paymentIntent.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// confirm payment intent

		// To create a PaymentIntent for confirmation, see our guide at:
		// https://stripe.com/docs/payments/payment-intents/creating-payment-intents#creating-for-automatic

		Map<String, Object> paramss = new HashMap<String, Object>();
		paramss.put("payment_method", "card_1MuGDeSEux284pDqr1L5g1eR");
		paramss.put("return_url", "http://10.64.111.61:8080/T78854");

		try {
			PaymentIntent updatedPaymentIntent = paymentIntent.confirm(paramss);
			System.out.println(updatedPaymentIntent);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public BaseResponse<?> createSubscription() {

		// create Product

		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", "Netflix Subscription");
		Product product = null;
		try {
			product = Product.create(params);
			System.out.println(product.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// create Price
		Map<String, Object> recurring = new HashMap<String, Object>();
		recurring.put("interval", "day");
		Map<String, Object> pric = new HashMap<String, Object>();
		pric.put("unit_amount", 22500);
		pric.put("currency", "inr");
		pric.put("recurring", recurring);
		pric.put("product", product.getId());

		Price price = null;
		try {
			price = Price.create(pric);
			System.out.println(price.toString());

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// checkout start
		List<HashMap<String, Object>> lineItems = new ArrayList<HashMap<String, Object>>();
		Map<String, Object> lineItem1 = new HashMap<String, Object>();
		lineItem1.put("price", price.getId());
		lineItem1.put("quantity", 1);
		lineItems.add((HashMap<String, Object>) lineItem1);
		Map<String, Object> checkout = new HashMap<String, Object>();
		checkout.put("success_url", "https://www.google.co.in/");
		checkout.put("line_items", lineItems);
//		checkout.put("mode", "payment"); // You specified `payment` mode but passed a recurring price. Either switch to `subscription` mode or use only one-time prices.;
		checkout.put("mode", "subscription");
		checkout.put("customer", "cus_NfZKLq9cEeTwxS");

		try {
			Session session = Session.create(checkout);
			System.out.println(session.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// checkout end

		return null;

	}

	public BaseResponse<?> createSubscriptionWithoutcheckout() {

		// create Product

		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", "Netflix Subscription-4");
		Product product = null;
		try {
			product = Product.create(params);
			System.out.println(product.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// create Price
		Map<String, Object> recurring = new HashMap<String, Object>();
		recurring.put("interval", "day");
		Map<String, Object> pric = new HashMap<String, Object>();
		pric.put("unit_amount", 20000);
		pric.put("currency", "inr");
		pric.put("recurring", recurring);
		pric.put("product", product.getId());

		Price price = null;
		try {
			price = Price.create(pric);
			System.out.println(price.toString());

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/// create subscription
		List<Object> items = new ArrayList<>();
		Map<String, Object> item1 = new HashMap<>();
		item1.put("price", price.getId());
		items.add(item1);
		Map<String, Object> p1 = new HashMap<>();
		p1.put("customer", "cus_NfZKLq9cEeTwxS");
		p1.put("items", items);
//		p1.put("cancel_at_period_end", true);
		p1.put("default_payment_method", "card_1MuGDeSEux284pDqr1L5g1eR");
		p1.put("cancel_at", "1681973251");

		try {

			Subscription subscription = Subscription.create(p1);
			System.err.println(subscription);

			Invoice invoice = Invoice.retrieve(subscription.getLatestInvoice());

			Invoice updatedInvoice = invoice.pay();
			System.out.println(updatedInvoice);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}

	public BaseResponse<?> createSubscriptionWithoutcheckoutwithautopay() {

		// create Product

		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", "plan-azhar-2-" + new Date());
		Product product = null;
		try {
			product = Product.create(params);
			System.out.println(product.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// create Price
		Map<String, Object> recurring = new HashMap<String, Object>();
		recurring.put("interval", "day");
		Map<String, Object> pric = new HashMap<String, Object>();
		pric.put("unit_amount", 5000);
		pric.put("currency", "inr");
		pric.put("recurring", recurring);
		pric.put("product", product.getId());

		Price price = null;
		try {
			price = Price.create(pric);
			System.out.println(price.toString());

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/// create subscription
		List<Object> items = new ArrayList<>();
		Map<String, Object> item1 = new HashMap<>();
		item1.put("price", price.getId());
		items.add(item1);
		Map<String, Object> p1 = new HashMap<>();
		p1.put("customer", "cus_NcDk9mXY2U46Vo");
		p1.put("items", items);
//		p1.put("cancel_at_period_end", true);
//		p1.put("default_payment_method", "card_1MuGDeSEux284pDqr1L5g1eR");
		p1.put("cancel_at", "1683720331");
		p1.put("collection_method", "send_invoice");
		p1.put("days_until_due", "0");
//		p1.put("auto_advance", false);
//		p1.put("billing_cycle_anchor", "1683138832");
		Subscription subscription = null;
		try {

			subscription = Subscription.create(p1);
//			subscription.setStatus("incomplete");
			System.out.println(subscription);

			Invoice invoice = Invoice.retrieve(subscription.getLatestInvoice());
//			invoice.setCollectionMethod("send_invoice");
//			invoice.setAutoAdvance(false);
			Map<String, Object> invoiceParam = new HashMap<>();
			invoiceParam.put("auto_advance", false);
//			invoiceParam.put("collection_method", "send_invoice");
			invoiceParam.put("due_date", "1683284580");
			invoice.update(invoiceParam);
			invoice.finalizeInvoice();
//
//			Invoice updatedInvoice = invoice.pay();
//			System.out.println(updatedInvoice);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// creating invoice
		Map<String, Object> invoiceParams = new HashMap<>();
		invoiceParams.put("customer", "cus_NcDk9mXY2U46Vo");
		invoiceParams.put("auto_advance", false);
		invoiceParams.put("collection_method", "send_invoice");
		invoiceParams.put("due_date", "1683299731");
		invoiceParams.put("subscription", subscription.getId());

		Invoice invoice = null;
//		try {
//			invoice = Invoice.create(invoiceParams);
//			invoice.finalizeInvoice();
//
//			System.out.println(invoice);
//		} catch (StripeException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		// end invoice

		return null;

	}

	public BaseResponse<?> createcustomerAndsetupIntent() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> params = new HashMap<>();
		params.put("success_url", "https://example.com/success");
		params.put("mode", "setup");
		params.put("customer", "cus_NfZKLq9cEeTwxS");
		List<Object> paymentMethodTypes = new ArrayList<>();
		paymentMethodTypes.add("card");
		params.put("payment_method_types", paymentMethodTypes);

		try {
			Session session = Session.create(params);
			System.out.println(session);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public BaseResponse<?> createCheckoutSubscription() {

	// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		// Product
		Map<String, Object> productParams = new HashMap<String, Object>();
		productParams.put("name", "Netflix-112-" + new Date());
		Product product = null;
		try {
			product = Product.create(productParams);
			System.out.println(product.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// product end

		// price start
		Map<String, Object> priceParams = new HashMap<String, Object>();
		priceParams.put("unit_amount", 24000);
		priceParams.put("currency", "inr");
		priceParams.put("product", product.getId());

		Map<String, Object> recurring = new HashMap<String, Object>();
		recurring.put("interval", "day");
		priceParams.put("recurring", recurring);
		Price price = null;
		try {

			price = Price.create(priceParams);
			System.out.println(price.toString());
		} catch (StripeException e) {
			e.printStackTrace();
		}

		// price end

		/// create subscription
		List<Object> items = new ArrayList<>();
		Map<String, Object> item1 = new HashMap<>();
		item1.put("price", price.getId());
		items.add(item1);
		Map<String, Object> p1 = new HashMap<>();
		p1.put("customer", "cus_NfYkCkKv9vPUxm");
		p1.put("items", items);
//				p1.put("cancel_at_period_end", true);
//				p1.put("default_payment_method", "card_1MuGDeSEux284pDqr1L5g1eR");
		p1.put("cancel_at", "1683720331");
		p1.put("collection_method", "send_invoice");
		p1.put("days_until_due", "0");
		p1.put("payment_behavior", "allow_incomplete");
//				p1.put("auto_advance", false);
//				p1.put("billing_cycle_anchor", "1683138832");
		Subscription subscription = null;
		try {

			subscription = Subscription.create(p1);
//					subscription.setStatus("incomplete");
			System.out.println(subscription);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// checkout start
		List<HashMap<String, Object>> lineItems = new ArrayList<HashMap<String, Object>>();
		Map<String, Object> lineItem1 = new HashMap<String, Object>();
		lineItem1.put("price", price.getId());
		lineItem1.put("quantity", 1);

		lineItems.add((HashMap<String, Object>) lineItem1);
		Map<String, Object> checkout = new HashMap<String, Object>();
		checkout.put("success_url", "https://www.google.co.in/");
		checkout.put("line_items", lineItems);
		checkout.put("mode", "subscription");
		checkout.put("customer", "cus_NfYkCkKv9vPUxm");
//		checkout.put("subscription", subscription.getId());

		Map<String, Object> subscriptionData = new HashMap<String, Object>();
		subscriptionData.put("billing_cycle_anchor", "1683288331");
//		checkout.put("subscription_data", subscriptionData);

		try {
			Session session = Session.create(checkout);
			System.out.println(session.toString());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// checkout end

		return null;
	}

	public BaseResponse<?> updatePrice() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> recurring = new HashMap<>();
		recurring.put("interval", "day");
		Map<String, Object> params = new HashMap<>();
		params.put("unit_amount", 10000);
		params.put("currency", "inr");
		params.put("recurring", recurring);
		params.put("product", "prod_Nq2SV1N3WYrjSs");

		Price price = null;
//		try {
//			price = Price.create(params);
//		} catch (StripeException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		Subscription subscription = null;
		try {
			subscription = Subscription.retrieve("sub_1N4MJfSEux284pDqNTqAFPCA");
			System.out.println(subscription);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<Object> items = new ArrayList<>();
		Map<String, Object> item1 = new HashMap<>();
		item1.put("price", "price_1N5PA9SEux284pDqjAojmfCW");
		item1.put("id", "si_Nq2OgEshpEYnR0");
		items.add(item1);
		Map<String, Object> p1 = new HashMap<>();
		p1.put("items", items);

		try {
			Subscription updatedSubscription = subscription.update(p1);
			System.out.println(updatedSubscription);

		} catch (StripeException e) {

			e.printStackTrace();
		}
		return null;
	}

	public BaseResponse<?> createInvoice() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		PaymentIntent paymentIntent;
		String paymentmethod = null;
		try {

			paymentIntent = PaymentIntent.retrieve("pi_3N67SySEux284pDq1zbeHFnr");
			paymentmethod = paymentIntent.getPaymentMethod();
			paymentmethod = paymentIntent.getSource();
			System.out.println("paymentmethod=" + paymentmethod);

//			Map<String, Object> retrieveParams = new HashMap<>();
//			List<String> expandList = new ArrayList<>();
//			expandList.add("sources");
//			retrieveParams.put("expand", expandList);
//			Customer customer = Customer.retrieve("cus_NcDk9mXY2U46Vo", retrieveParams, null);
//
//
//			Map<String, Object> params = new HashMap<>();
//			params.put("source", paymentmethod);
//
//			Card card = (Card) customer.getSources().create(params);
//			System.out.println(card);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<String, Object> params = new HashMap<>();
		params.put("customer", "cus_NcDk9mXY2U46Vo");
		params.put("default_payment_method", "pm_1N6BMZSEux284pDqrMQzik0b");

		Invoice invoice = null;
		try {
			invoice = Invoice.create(params);
			System.out.println(invoice);

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<String, Object> paramss = new HashMap<>();
		paramss.put("customer", "cus_NcDk9mXY2U46Vo");
		paramss.put("unit_amount", 50000);
		paramss.put("quantity", 1);
		paramss.put("invoice", invoice.getId());

		try {
			InvoiceItem invoiceItem = InvoiceItem.create(paramss);
			System.out.println(invoiceItem);

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Invoice getinvoice;
		try {
			getinvoice = Invoice.retrieve(invoice.getId());
			Invoice updatedInvoice = getinvoice.pay();
			System.out.println(updatedInvoice);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("url", "");

		return new BaseResponse<>(hm);
	}

	public BaseResponse<?> createInvoiceforfirsttime() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

//		Map<String, Object> params = new HashMap<>();
//		params.put("customer", "cus_NcDk9mXY2U46Vo");
//		Invoice invoice = null;
//		try {
//			invoice = Invoice.create(params);
//			System.out.println(invoice);
//
//		} catch (StripeException e) {
//			
//			e.printStackTrace();
//		}
//
//		Map<String, Object> paramss = new HashMap<>();
//		paramss.put("customer", "cus_NcDk9mXY2U46Vo");
//		paramss.put("unit_amount", 5000);
//		paramss.put("quantity", 2);
//		paramss.put("invoice", invoice.getId());
//
//		try {
//			InvoiceItem invoiceItem = InvoiceItem.create(paramss);
//			System.out.println(invoiceItem);
//
//		} catch (StripeException e) {
//			
//			e.printStackTrace();
//		}
//
//		Invoice getinvoice;
//		Invoice updatedInvoice = null;
//		try {
//			getinvoice = Invoice.retrieve(invoice.getId());
//			updatedInvoice = getinvoice.finalizeInvoice();
//			
//			PaymentIntent paymentIntent =
//					  PaymentIntent.retrieve(
//					    updatedInvoice.getPaymentIntent()
//					  );
//
//			Map<String, Object> params1 = new HashMap<>();
//			params.put("setup_future_usage","off_session");
//			Map<String, Object> card = new HashMap<>();
//			card.put("setup_future_usage", "off_session");
//			params.put("payment_method_options.card",card);
//
//			PaymentIntent updatedPaymentIntent =
//			  paymentIntent.update(params1);
//	
//			System.out.println(updatedInvoice);
//		} catch (StripeException e) {
//			e.printStackTrace();
//		}
//
		HashMap<String, String> hm = new HashMap<String, String>();
//		hm.put("url", updatedInvoice.getHostedInvoiceUrl());
//		System.out.println("paymentIntent id===" + updatedInvoice.getPaymentIntent());

		// session
		Map<String, Object> paramssss = new HashMap<>();
		paramssss.put("unit_amount", 50000);
		paramssss.put("currency", "INR");
		paramssss.put("product", "prod_NrYvXhNRNRVoUX");
		Price price = null;
		try {
			price = Price.create(paramssss);
		} catch (StripeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		SessionCreateParams paramsss = SessionCreateParams.builder()
				.setPaymentIntentData(SessionCreateParams.PaymentIntentData.builder()
						.setSetupFutureUsage(SessionCreateParams.PaymentIntentData.SetupFutureUsage.OFF_SESSION)
						.build())
				.setCustomer("cus_NcDk9mXY2U46Vo")
				.addLineItem(SessionCreateParams.LineItem.builder().setPrice(price.getId()).setQuantity(1L).build())
				.setMode(SessionCreateParams.Mode.PAYMENT).setSuccessUrl("http://localhost:7050/#/mop/execute")
				.setCancelUrl("https://example.com/cancel.html").build();

		try {
			Session session = Session.create(paramsss);
			hm.put("url", session.getUrl());
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new BaseResponse<>(hm);
	}

	public BaseResponse<?> createInvoiceforfirsttimewithCustomer() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		Map<String, Object> c1 = new HashMap<>();
		c1.put("description", "new Customer");
		Customer customer = null;
		try {
			customer = Customer.create(c1);
		} catch (StripeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Map<String, Object> params = new HashMap<>();
//		params.put("customer", "cus_NcDk9mXY2U46Vo");
		params.put("customer", customer.getId());
		Invoice invoice = null;
		try {
			invoice = Invoice.create(params);
			System.out.println(invoice);

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<String, Object> paramss = new HashMap<>();
//		paramss.put("customer", "cus_NcDk9mXY2U46Vo");
		paramss.put("customer", customer.getId());
		paramss.put("unit_amount", 5000);
		paramss.put("quantity", 2);
		paramss.put("invoice", invoice.getId());

		try {
			InvoiceItem invoiceItem = InvoiceItem.create(paramss);
			System.out.println(invoiceItem);

		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Invoice getinvoice;
		try {
			getinvoice = Invoice.retrieve(invoice.getId());
			Invoice updatedInvoice = getinvoice.finalizeInvoice();
			System.out.println(updatedInvoice);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public BaseResponse<?> getchekoutSession() {
		// String stripeKey = System.getenv("STRIPE_SECRET_KEY");

		try {
			Session session = Session.retrieve("cs_test_a18eJ4F90gw4IfEKPyjeOC77udCJuyYtOtqoqFICOvBvQbaugG3mmgZ63a");
			System.out.println(session);
			PaymentIntent paymentIntent =
					  PaymentIntent.retrieve(
					    session.getPaymentIntent()
					  );
			String paymentMethodId=paymentIntent.getPaymentMethod();
			System.out.println("Session attched paymentMethodId="+paymentMethodId);
		} catch (StripeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

}
