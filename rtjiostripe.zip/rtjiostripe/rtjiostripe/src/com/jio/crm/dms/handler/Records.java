package com.jio.crm.dms.handler;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.crm.dms.node.es.ESOperationImpl;
import com.jio.crm.dms.utils.Constants;

public class Records extends HttpServlet {

	// private static long startMillis = System.currentTimeMillis();

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest httpservletrequest, HttpServletResponse resp)
			throws ServletException, IOException {
		handlerequest(httpservletrequest, resp);

	}

	@Override
	protected void doPost(HttpServletRequest httpservletrequest, HttpServletResponse resp)
			throws ServletException, IOException {

		handlerequest(httpservletrequest, resp);
	}

	@Override
	protected void doDelete(HttpServletRequest httpservletrequest, HttpServletResponse resp)
			throws ServletException, IOException {

		handlerequest(httpservletrequest, resp);
	}

	@Override
	protected void doPut(HttpServletRequest httpservletrequest, HttpServletResponse resp)
			throws ServletException, IOException {

		handlerequest(httpservletrequest, resp);
	}

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		super.service(arg0, arg1);
	}

	/*
	 * common handler for all request to send response to receiver object
	 */
	public void handlerequest(HttpServletRequest httpservletrequest, HttpServletResponse resp) throws IOException {
		try {
			// String body = IOUtils.toString(inputStream,
			// httpservletrequest.getCharacterEncoding());
			

			switch (httpservletrequest.getParameter(Constants.ACTION)) {
			case "submit":
				submitTransaction(httpservletrequest);
				
				break;

			case "get":

				break;

			default:
				break;
			}

		} catch (Exception e) {

		}

	}

	private void submitTransaction(HttpServletRequest httpservletrequest) {
		try {
		InputStream inputStream = httpservletrequest.getInputStream();
		Map<String, String> requestHeaders = putHeadersInMap(httpservletrequest);
		JSONObject bodyJson = new JSONObject(
				IOUtils.toString(inputStream, httpservletrequest.getCharacterEncoding()));
		boolean csvInfoUpdate = ESOperationImpl.getInstance().putCSVCredits(bodyJson);
		if(csvInfoUpdate) {
			DappLoggerService.GENERAL_INFO_LOG.getInfoLogBuilder("information updated in es");
		}
		else {
			DappLoggerService.GENERAL_INFO_LOG.getInfoLogBuilder("unable to upadate information in es");

		}
	
		}catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage());
		}
		
	}

	private Map<String, String> putHeadersInMap(HttpServletRequest req) {
		Map<String, String> requestHeaders = new HashMap<>();
		Enumeration<String> headerNames = req.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String headerName = headerNames.nextElement();
			requestHeaders.put(headerName, req.getHeader(headerName));
		}
		return requestHeaders;

	}

	/*
	 * public static void main(String args[]) { startMillis =
	 * System.currentTimeMillis();
	 * 
	 * RecordService rs = new RecordService();
	 * 
	 * //rs.processRecord("C:\\conf\\cmn.csv"); long diffMillis =
	 * System.currentTimeMillis() - startMillis;
	 * System.out.println(diffMillis/1000); }
	 */

}
