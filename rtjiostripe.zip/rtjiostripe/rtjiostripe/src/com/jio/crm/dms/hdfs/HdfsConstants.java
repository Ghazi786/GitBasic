/**
 * 
 */
package com.jio.crm.dms.hdfs;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class HdfsConstants {

	public static final String CORE_SITE_XML = "../configuration/core-site.xml";
	public static final String HDFS_SITE_XML = "../configuration/hdfs-site.xml";

	public HdfsConstants() {
		// TODO Auto-generated constructor stub
	}

}
