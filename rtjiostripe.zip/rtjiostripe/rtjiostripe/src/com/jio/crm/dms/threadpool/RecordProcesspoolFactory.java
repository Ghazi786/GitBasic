package com.jio.crm.dms.threadpool;

import com.jio.crm.dms.threads.RecordProcess;
import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

/*
 * Dummy pool factory to start the thread pool with User defined thread passed
 */
public class RecordProcesspoolFactory implements PooledObjectFactory<RecordProcess> {

	@Override
	public void activateObject(PooledObject<RecordProcess> arg0) throws Exception {

	}

	@Override
	public void destroyObject(PooledObject<RecordProcess> arg0) throws Exception {

	}

	@Override
	public PooledObject<RecordProcess> makeObject() throws Exception {
		return new DefaultPooledObject<>(new RecordProcess());
	}

	@Override
	public void passivateObject(PooledObject<RecordProcess> arg0) throws Exception {

	}

	@Override
	public boolean validateObject(PooledObject<RecordProcess> arg0) {
		return false;
	}

}
