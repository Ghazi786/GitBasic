package com.jio.crm.dms.utils;

public enum Status {
	Open, New, Resolved, Wontfix, Invalid, awaitingimpact, Fixed, Assigned, Deffered, Deployed, ReOpened, WorkInProgress, Parked, Duplicate
}
