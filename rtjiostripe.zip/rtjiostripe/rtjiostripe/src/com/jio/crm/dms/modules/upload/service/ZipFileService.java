/**
 * 
 */
package com.jio.crm.dms.modules.upload.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.crm.dms.bean.FileDocument;
import com.jio.crm.dms.clearCodes.ClearCodeLevel;
import com.jio.crm.dms.clearCodes.ClearCodes;
import com.jio.crm.dms.configurationManager.ConfigParamsEnum;
import com.jio.crm.dms.core.BaseResponse;
import com.jio.crm.dms.countermanager.CounterNameEnum;
import com.jio.crm.dms.hdfs.HdfsConfigurationManager;
import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.crm.dms.modules.upload.repository.FileUploadRepository;
import com.jio.crm.dms.node.startup.DmsBootStrapper;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class ZipFileService {

	/**
	 * 
	 */
	private ExcelService excelService = new ExcelService();
	private FileUploadRepository fileRepositoryService = new FileUploadRepository();
	private FileUploadService fileUploadService = new FileUploadService();

	public BaseResponse<?> downloadFileInBulk(String productName, String orderId, HttpServletResponse resp) {

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		final ClearCodeAsnPojo ccAsnPojo = DmsBootStrapper.getInstance().getClearCodeObj();
		try {
			Configuration conf = HdfsConfigurationManager.getConfiguration();

			FileSystem fileSystem = FileSystem.get(conf);

			Date date = new Date();
			String zipFilename = orderId + "_" + date.getTime() + ".zip";

			resp.setContentType("application/zip");
			resp.setHeader("Content-Disposition", "attachment; filename=" + zipFilename);

//			try (FSDataOutputStream out = fileSystem.create(path)) {
//				CheckedOutputStream checksum = new CheckedOutputStream(out, new Adler32());
//				ZipOutputStream zipOut = new ZipOutputStream(checksum);
//				
//				zipOut.setLevel(9);
			ServletOutputStream outs = resp.getOutputStream();
			ZipOutputStream zipOut = new ZipOutputStream(new BufferedOutputStream(outs));
			String pathTemp = ConfigParamsEnum.FILE_UPLOAD_DIR.getStringValue() + "/" + productName + "/" + orderId;
			Path orderPath = new Path(pathTemp);
			List<String> list = getAllFilePath(orderPath, fileSystem);
			for (String fileName : list) {
				String filePtah = pathTemp + "/" + fileName;
				Path paths = new Path(filePtah);
				try (FSDataInputStream in = fileSystem.open(paths)) {
					BufferedInputStream bis = null;
					bis = new BufferedInputStream(in, 1024);
					ZipEntry ze = new ZipEntry(fileName);
					zipOut.putNextEntry(ze);
					byte data[] = new byte[1024];
					int count;
					while ((count = bis.read(data, 0, 1024)) != -1) {
						zipOut.write(data, 0, count);
					}
					// close entry every time
					zipOut.closeEntry();
					bis.close();
				} catch (Exception e) {
					throw new IOException();
				}
			}

//				zipOut.flush();
			zipOut.close();
//				fileUploadService.getFile(resp, zipFilename, productName, null, null);
//				HdfsUtilsService.getInstance().deleteFile(zipFilePath);
			CounterNameEnum.CNTR_DOWNLOAD_FILE_IN_BULK_SUCCESS.increment();
			ccAsnPojo.addClearCode(ClearCodes.DOWNLOAD_FILE_IN_BULK_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			System.out.println("DOWNLOAD BULK FILE SUCCESSFULLY COMPLETED");
//			}
		} catch (Exception e) {
			ccAsnPojo.addClearCode(ClearCodes.DOWNLOAD_FILE_IN_BULK_FAILURE.getValue(), ClearCodeLevel.FAILURE);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			CounterNameEnum.CNTR_DOWNLOAD_FILE_IN_BULK_FAILURE.increment();
			System.out.println("DOWNLOAD BULK FILE FAILURE");
		}
		return null;

	}

	public BaseResponse<List<FileDocument>> downloadFileInBulkFomExcel(HttpServletRequest req,
			HttpServletResponse res) {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		final ClearCodeAsnPojo ccAsnPojo = DmsBootStrapper.getInstance().getClearCodeObj();
		List<FileDocument> documents = new ArrayList<FileDocument>();
		XSSFWorkbook workbook = null;
		try {

			byte[] byteArray = IOUtils.toByteArray(req.getInputStream());

			InputStream input = new ByteArrayInputStream(byteArray);

			workbook = new XSSFWorkbook(input);
			// read Excel file to search document from database
			XSSFSheet sheet = workbook.getSheetAt(0);
			HashMap<String, List<FileDocument>> searchparams = excelService.readSearchParameter(sheet, workbook);

			// making document object, to search from db
			List<FileDocument> search1 = searchparams.get("s1");
			HashMap<String, String> filters = null;
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();
			SearchResult<FileDocument> result = null;

			for (int i = 0; i < search1.size(); i++) {
				filters = new HashMap<String, String>();
				FileDocument tempDocument = search1.get(i);
				if (tempDocument.getCustomerId() != null && !tempDocument.getCustomerId().isEmpty()) {
					filters.put("customerId", tempDocument.getCustomerId());
				}
				if (tempDocument.getMobileNumber() != null && !tempDocument.getMobileNumber().isEmpty()) {
					filters.put("mobileNumber", tempDocument.getMobileNumber());

				}
				if (tempDocument.getOrderId() != null && !tempDocument.getOrderId().isEmpty()) {
					filters.put("orderId", tempDocument.getOrderId());
				}
				if (tempDocument.getDocumentCategory() != null && !tempDocument.getDocumentCategory().isEmpty()) {
					filters.put("documentCategory", tempDocument.getDocumentCategory());
				}
				if (tempDocument.getDocumentNumber() != null && !tempDocument.getDocumentNumber().isEmpty()) {
					filters.put("documentNumber", tempDocument.getDocumentNumber());
				}
				// fetching document from DB
				Page page = session.defaultPage();
				page.setPageLength(1000);
				if(filters.isEmpty()) {
					continue;
				}
				result = fileRepositoryService.getAllDocumentByFilters(session, filters,page);
				
				int lastColumn=sheet.getRow(0).getPhysicalNumberOfCells()-1;
				if (result.getResult().size() != 0) {
					Row row = sheet.getRow(i + 1);
					
					XSSFCellStyle style = workbook.createCellStyle();
					style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					Cell cellTemp = row.createCell(lastColumn);
					cellTemp.setCellValue("File Found for this Data");
					sheet.autoSizeColumn(lastColumn);
					cellTemp.setCellStyle(style);
				} else {
					Row row = sheet.getRow(i + 1);
					Cell cellTemp = row.createCell(lastColumn);
					XSSFCellStyle style = workbook.createCellStyle();
					style.setFillForegroundColor(IndexedColors.RED.getIndex());
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					cellTemp.setCellValue("File Not Found for this data");
					sheet.autoSizeColumn(lastColumn);
					cellTemp.setCellStyle(style);
				}
				// adding to list
				documents.addAll(result.getResult());
				System.out.println(documents);
			}
//			List<Document> search2 = searchparams.get("s2");
//
//			for (int i = 0; i < search2.size(); i++) {
//				filters = new HashMap<String, String>();
//				Document tempDocument = search2.get(i);
//				if (tempDocument.getCustomerId() != null) {
//					filters.put("customerId", tempDocument.getCustomerId());
//				}
//				if (tempDocument.getCafNumber() != null) {
//					filters.put("cafNumber", tempDocument.getCafNumber());
//
//				}
//				if (tempDocument.getServiceId() != null) {
//					filters.put("serviceId", tempDocument.getServiceId());
//				}
//				if (tempDocument.getBusinessParterId() != null) {
//					filters.put("businessParterId", tempDocument.getBusinessParterId());
//				}
//
//				// fetching document from DB
//				result = fileRepositoryService.getAllDocumentByFilters(session, filters);
//
//				// adding to list
//				documents.addAll(result.getResult());
//				System.out.println("India");
//
//
//			}
			// creating zip file of found documents
			Configuration conf = HdfsConfigurationManager.getConfiguration();
			FileSystem fileSystem = FileSystem.get(conf);
			Date date = new Date();
			String zipFileName = date.getTime() + "_bulkFile.zip";
			res.setContentType("application/zip");
			res.setHeader("Content-Disposition", "attachment; filename=" + zipFileName);
//			String zipFilePath = uploadFilePath + "/temp/" + zipFileName;
			try {

				ServletOutputStream outs = res.getOutputStream();
				ZipOutputStream zipOut = new ZipOutputStream(new BufferedOutputStream(outs));
//				ZipOutputStream zipOut = new ZipOutputStream(out);

				appendRequestedExcelFilewithStatus(zipOut, workbook);
				createZipFile(zipOut, fileSystem, documents, res);
//				fileUploadService.getFile(res, zipFileName, null, null, null);
//				HdfsUtilsService.getInstance().deleteFile(zipFilePath);
				CounterNameEnum.CNTR_DOWNLOAD_FILE_IN_BULK_EXCEL_SUCCESS.increment();
				ccAsnPojo.addClearCode(ClearCodes.DOWNLOAD_FILE_IN_BULK_EXCEL_SUCCESS.getValue(),
						ClearCodeLevel.FAILURE);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			} catch (Exception e) {
				ccAsnPojo.addClearCode(ClearCodes.DOWNLOAD_FILE_IN_BULK_EXCEL_FAILURE.getValue(),
						ClearCodeLevel.FAILURE);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
				CounterNameEnum.CNTR_DOWNLOAD_FILE_IN_BULK_EXCEL_FAILURE.increment();
				System.out.println("CNTR_DOWNLOAD_FILE_IN_BULK_EXCEL_FAILURE");
			}

		} catch (Exception e) {
			ccAsnPojo.addClearCode(ClearCodes.DOWNLOAD_FILE_IN_BULK_EXCEL_FAILURE.getValue(), ClearCodeLevel.FAILURE);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			CounterNameEnum.CNTR_DOWNLOAD_FILE_IN_BULK_EXCEL_FAILURE.increment();
			System.out.println("CNTR_DOWNLOAD_FILE_IN_BULK_EXCEL_FAILURE_2");
			try {
				workbook.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		BaseResponse<List<FileDocument>> response = new BaseResponse<List<FileDocument>>(documents);
		return response;
	}

	public void createZipFile(ZipOutputStream zipOut, FileSystem fileSystem, List<FileDocument> documents,
			HttpServletResponse resp) throws IOException {
//		Configuration conf = HdfsConfigurationManager.getConfiguration();
//		FileSystem fileSystem = FileSystem.get(conf);
//		String uploadFilePath = ConfigParamsEnum.FILE_UPLOAD_DIR.getStringValue();
//		Path path = new Path(uploadFilePath + "/" + "bulkFile.zip");
//		try (FSDataOutputStream out = fileSystem.create(path)) {
//			ZipOutputStream zipOut = new ZipOutputStream(out);
		HashMap<String, String> check = new HashMap<String, String>();
		for (FileDocument document : documents) {
			String filePath = document.getFilePath();
//				try {
			String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
			Path paths = new Path(filePath);

			// check if file is already written or file not found in hdfs then continue to
			// next
			if (!fileSystem.exists(paths) || check.get(filePath) != null) {
				continue;
//				throw new FileNotFoundException();
			}
			check.put(filePath, "true");
			try (FSDataInputStream in = fileSystem.open(paths)) {
				BufferedInputStream bis = null;
				bis = new BufferedInputStream(in, 1024);
				ZipEntry ze = new ZipEntry(fileName);
				zipOut.putNextEntry(ze);
				byte data[] = new byte[1024];
				int count;
				while ((count = bis.read(data, 0, 1024)) != -1) {
					zipOut.write(data, 0, count);
				}
				// close entry every time
				zipOut.closeEntry();
				bis.close();
			} catch (Exception e) {
				throw new IOException();
			}
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}

		}
		zipOut.close();
		System.out.println("Successfully zip file Created after reading excel");
//		} catch (Exception e) {
//			// TODO: handle exception
//		}

	}

	public void appendRequestedExcelFilewithStatus(ZipOutputStream zipOut, XSSFWorkbook workbook) throws IOException {
		BufferedInputStream bis = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		byte[] barray = bos.toByteArray();
		InputStream is = new ByteArrayInputStream(barray);
		bis = new BufferedInputStream(is, 1024);
		ZipEntry ze = new ZipEntry("status.xlsx");
		zipOut.putNextEntry(ze);
		byte data[] = new byte[1024];
		int count;
		while ((count = bis.read(data, 0, 1024)) != -1) {
			zipOut.write(data, 0, count);
		}
		// close entry every time
		zipOut.closeEntry();
		bis.close();
	}

	public static List<String> getAllFilePath(Path filePath, FileSystem fs) throws FileNotFoundException, IOException {
		List<String> fileList = new ArrayList<String>();
		FileStatus[] fileStatus = fs.listStatus(filePath);
		for (FileStatus fileStat : fileStatus) {
			if (fileStat.isDirectory()) {
				fileList.addAll(getAllFilePath(fileStat.getPath(), fs));
			} else {
				String fileName = fileStat.getPath().toString();
				fileList.add(fileName.substring(fileName.lastIndexOf("/") + 1));
			}
		}
		return fileList;
	}

}
