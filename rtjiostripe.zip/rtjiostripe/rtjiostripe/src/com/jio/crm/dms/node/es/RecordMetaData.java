package com.jio.crm.dms.node.es;

//for reference
public class RecordMetaData {
	private long rank;
	private String name;
	private String prm_id;
	private String parent_id;
	private String circle;
	private String city;
	private String jio_point;
	private String jio_centre;
	private String productType;
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	private long no_of_sale;
	private long total_amount;
	public long getRank() {
		return rank;
	}
	public void setRank(long rank) {
		this.rank = rank;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrm_id() {
		return prm_id;
	}
	public void setPrm_id(String prm_id) {
		this.prm_id = prm_id;
	}
	public String getParent_id() {
		return parent_id;
	}
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getJio_point() {
		return jio_point;
	}
	public void setJio_point(String jio_point) {
		this.jio_point = jio_point;
	}
	public String getJio_centre() {
		return jio_centre;
	}
	public void setJio_centre(String jio_centre) {
		this.jio_centre = jio_centre;
	}
	public long getNo_of_sale() {
		return no_of_sale;
	}
	public void setNo_of_sale(long no_of_sale) {
		this.no_of_sale = no_of_sale;
	}
	public long getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(long total_amount) {
		this.total_amount = total_amount;
	}

}
