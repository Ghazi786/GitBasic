package com.jio.crm.dms.fms;

/**
 * 
 * 
 * @author Kiran.Jangid
 *
 */

public interface FMSIntegrationConstants {
	static public String SUBSCRIBE_NAME = "subscribe-name";
	static public String SUBSCRIBE_ID = "subscribe-id";
	static public String AUTH_KEY = "auth-key";
	static public String X_FLOW_ID = "X-Flow-Id";
	static public String CONTEXT_SUBSCRIBE_FMS = "/subscribeJioOSS";
	static public String WMPO_CONTEXT = "/WMPO/eventHandler";
	
	static public String IS_MILESTONE = "Is-Milestone";
	static public String X_EVENT_NAME = "X-Event-Name";
	static public String X_MESSAGE_TYPE= "X-Message-Type";
	static public String TYPE= "type";
	static public String RE_PUSH_ALL= "rePushAll";
	static public String RE_PUSH= "rePush";
	static public String WORKFLOW_NAME= "workflow-name";
	static public String WORKFLOW_VERSION = "workflow-version";

	static public String FALSE =  "false";
	static public String EVENT_NAME =  "GET_CHANNEL_REFERENE_ID_FOR_ORDER";
	static public String EVENT =  "event";
	static public String IOT =  "iot";
	static public String NBIOT =  "nbiot";
	static public String V_1_0_0 =  "1.0.0";
	
	static public String AUTH_KEY_WMPO = "Auth-Key";


}
