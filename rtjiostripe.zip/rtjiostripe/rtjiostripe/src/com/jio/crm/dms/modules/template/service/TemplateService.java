/**
 * 
 */
package com.jio.crm.dms.modules.template.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.http.HttpStatus;

import com.jio.crm.dms.exceptions.BaseException;
import com.jio.crm.dms.utils.MimeTypes;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class TemplateService {
	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "inline; filename=\"";

	public void getTemplateForFileSearch(HttpServletRequest req, HttpServletResponse resp) throws BaseException {

		String fileName = req.getParameter("fileName");
		String filePath = "../configuration/" + fileName;
		String profile = System.getProperty("profile");
		if (profile != null && profile.equals("dev")) {
			filePath = "./configuration/" + fileName;
		}
		try {
			FileInputStream in = new FileInputStream(filePath);
			OutputStream os = resp.getOutputStream();
			String extension = FilenameUtils.getExtension(fileName);
			String contentType = MimeTypes.getMimeType(extension);
			resp.setContentType(contentType);
			resp.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + fileName + "\"");
			resp.setContentLength((int) in.available());
			try {
				byte[] buffer = new byte[1024];
				int numBytes = 0;
				while ((numBytes = in.read(buffer)) > 0) {
					os.write(buffer, 0, numBytes);
				}

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					os.flush();
					os.close();
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			throw new BaseException(HttpStatus.SC_NOT_FOUND, "Template NOT found for file Name: " + fileName);
		}
	}
}
