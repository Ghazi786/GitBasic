package com.jio.crm.dms.node.es;

import org.elasticsearch.plugins.Plugin;

public class ESPlugin extends Plugin {

}
