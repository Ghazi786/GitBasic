package com.jio.crm.dms.modules.customer.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.elastic.search.exception.ElasticSearchException;
import com.jio.crm.dms.core.BaseResponse;
import com.jio.crm.dms.core.DispatcherBaseController;
import com.jio.crm.dms.core.HttpRequestMethod;
import com.jio.crm.dms.core.annotations.Controller;
import com.jio.crm.dms.core.annotations.EventName;
import com.jio.crm.dms.core.annotations.RequestMapping;

@Controller
@RequestMapping(name = "/customer")
public class CustomerController implements DispatcherBaseController {

	private static final long serialVersionUID = 1L;
	
	@RequestMapping(name = "/getCustomerList", type = HttpRequestMethod.GET)
	@EventName("GET_CUSTOMERS")
	public BaseResponse<?> getCustomerList(HttpServletRequest req, HttpServletResponse resp) throws ElasticSearchException {

		BaseResponse<String> response = new BaseResponse<>("CUSTOMER");
		return response;

	}


}
