package com.jio.crm.dms.node.shutdown;

import java.io.IOException;

import com.atom.OAM.Client.Management.OamClientManager;
import com.jio.blockchain.sdk.bootstrap.SDKBootStrap;
import com.jio.crm.dms.node.es.ESConnection;
import com.jio.crm.dms.node.startup.DmsBootStrapper;

public class ServerShutdownHook extends Thread {

	private DmsBootStrapper bootStrapper;

	/**
	 * 
	 * @param bootStrapper
	 */
	public ServerShutdownHook(DmsBootStrapper bootStrapper) {
		this.bootStrapper = bootStrapper;
	}

	@Override
	public void run() {
		System.out.println("Shutdown hook called...");

		if (bootStrapper.getConfigEngine().dumpConfigParams()) {
			System.out.println("Configuration file dumped Successfully");
		}
		try {
			stopMbeans();
			SDKBootStrap.getInstance().shutDownSdk();
			DmsBootStrapper.getInstance().shutdown_node();
			DmsBootStrapper.getInstance().getDappExecutor().shutdown();

			ESConnection.getInstance().getClient().close();

			OamClientManager.getInstance().disconnect();
			bootStrapper.getJettyRestEngine().stopJettyServer();
			System.out.println("Mbean stopped successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void stopMbeans() {

		bootStrapper.getConfigEngine().stopMbean();
		System.out.println("Mbean Stopped..");
	}

}
