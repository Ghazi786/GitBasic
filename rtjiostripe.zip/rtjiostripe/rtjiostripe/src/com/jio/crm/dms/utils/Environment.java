package com.jio.crm.dms.utils;

public enum Environment {
	DEV("DEV"), IOT("IOT"), Replica("Replica"), Production("Production");

	String name;

	Environment(String name) {
		this.name = name;
	}

	public static Environment getByName(String name) {
		
		if (name.equalsIgnoreCase(DEV.name)) {
			return Environment.DEV;
		} else if (name.equalsIgnoreCase(IOT.name)) {
			return Environment.IOT;
		} else if (name.equalsIgnoreCase(Replica.name)) {
			return Environment.Replica;
		} else if (name.equalsIgnoreCase(Production.name)) {
			return Environment.Production;
		} else {
			return null;
		}
	}
}
