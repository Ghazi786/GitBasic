package com.jio.crm.dms.countermanager;

/**
 * this interface will have counter related Constant
 * 
 * @author Ashish14.Gupta
 *
 */

public interface CounterConstants {

  public static final String BULK = "bulk";
  public static final String CSV_HEADER_COUNTERS = "Type,Name,Value\n";

}
