package com.jio.crm.dms.modules.upload.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.elastic.search.exception.ElasticSearchException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.jio.crm.dms.bean.DocumentCategory;
import com.jio.crm.dms.bean.FileDocument;
import com.jio.crm.dms.core.BaseResponse;
import com.jio.crm.dms.core.DispatcherBaseController;
import com.jio.crm.dms.core.HttpRequestMethod;
import com.jio.crm.dms.core.annotations.Controller;
import com.jio.crm.dms.core.annotations.EventName;
import com.jio.crm.dms.core.annotations.RequestMapping;
import com.jio.crm.dms.countermanager.CounterNameEnum;
import com.jio.crm.dms.exceptions.BaseException;
import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.crm.dms.modules.upload.service.FileUploadService;
import com.jio.crm.dms.modules.upload.service.ZipFileService;
import com.jio.crm.dms.utils.ObjectMapperHelper;
import com.jio.crm.dms.utils.RequestToBeanMapper;
import com.jio.subscriptions.modules.bean.Order;
import com.stripe.model.Customer;

/**
 * @author Ghajnafar.Shahid
 *
 */
@Controller
@RequestMapping(name = "/file")
public class FileUploadController implements DispatcherBaseController {

	private FileUploadService fileUploadService = new FileUploadService();
	private ZipFileService zipFileService = new ZipFileService();

	/**
	 * @param req
	 * @param resp
	 * @return
	 * @throws BaseException
	 * @throws IOException
	 */
	@EventName("STRIPE_CREATE_CUSTOMER")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<Customer> uploadFile(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();

		String fileName = req.getParameter("fileName");
		BaseResponse<Customer> response = this.fileUploadService.uploadFile(req, fileName);
		response.setMessage("File Uploaded Successfully");
		return response;

	}

	@EventName("STRIPE_ADD_CARD")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<Customer> addCard(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();

		String fileName = req.getParameter("fileName");
		BaseResponse<Customer> response = this.fileUploadService.addCard(req, "");
		response.setMessage("File Uploaded Successfully");
		return response;

	}

	@EventName("STRIPE_CHARGE_CUSTOMER")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<Customer> chargeCustomer(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();

		String fileName = req.getParameter("fileName");
		BaseResponse<Customer> response = this.fileUploadService.chargeCustomer(req, "");
		response.setMessage("File Uploaded Successfully");
		return response;

	}

	@EventName("STRIPE_CRAETE_CHECKOUT")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.GET)
	public BaseResponse<?> createCheckout(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createCheckout();
		response.setMessage("Create Checkout Successfully");
		return response;

	}

	@EventName("STRIPE_CRAETE_PAYMENT_INTENT")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<?> createPaymentIntent(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createPaymentIntent();
		response.setMessage("Create Checkout Successfully");
		return response;

	}

	@EventName("STRIPE_CREATE_SUBSCRIPTION")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<?> createSubscription(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createSubscription();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	
	@EventName("STRIPE_CREATE_SUBSCRIPTION_WITHOUT_CHECKOUT")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<?> createSubscriptionWithoutcheckout(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createSubscriptionWithoutcheckout();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	
	@EventName("STRIPE_CREATE_SUBSCRIPTION_WITHOUT_CHECKOUT_WITHOUT_AUTOPAY")
	@RequestMapping(name = "/upload", type = HttpRequestMethod.POST)
	public BaseResponse<?> createSubscriptionWithoutcheckoutwithautopay(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createSubscriptionWithoutcheckoutwithautopay();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	@EventName("STRIPE_CREATE_SETUPINTENT")
	@RequestMapping(name = "/setupintent", type = HttpRequestMethod.POST)
	public BaseResponse<?> createSetupintent(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createcustomerAndsetupIntent();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	
	@EventName("STRIPE_CREATE_CHECKOUT_SUBSCRIPTION")
	@RequestMapping(name = "/createcheckoutsubscription", type = HttpRequestMethod.POST)
	public BaseResponse<?> createCheckoutSubscription(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createCheckoutSubscription();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	@EventName("STRIPE_UPDATE_PRICE")
	@RequestMapping(name = "/createcheckoutsubscription", type = HttpRequestMethod.POST)
	public BaseResponse<?> updatePrice(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.updatePrice();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	
	@EventName("STRIPE_CREATE_INVOICE")
	@RequestMapping(name = "/createInvoice", type = HttpRequestMethod.POST)
	public BaseResponse<?> createInvoice(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createInvoice();
		response.setMessage("Payment Done");
		return response;

	}
	
	@EventName("STRIPE_CREATE_INVOICE_FINALIZE")
	@RequestMapping(name = "/createInvoice", type = HttpRequestMethod.POST)
	public BaseResponse<?> createInvoiceforfirsttime(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createInvoiceforfirsttime();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	
	@EventName("STRIPE_CREATE_INVOICE_FINALIZE_CUSTOMER")
	@RequestMapping(name = "/createInvoice", type = HttpRequestMethod.POST)
	public BaseResponse<?> createInvoiceforfirsttimewithCustomer(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.createInvoiceforfirsttimewithCustomer();
		response.setMessage("Create Checkout Successfully");
		return response;

	}
	
	@EventName("STRIPE_GET_CHECKOUT")
	@RequestMapping(name = "/getCheckout", type = HttpRequestMethod.POST)
	public BaseResponse<?> getchekoutSession(HttpServletRequest req, HttpServletResponse resp)
			throws BaseException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		CounterNameEnum.CNTR_UPLOAD_FILE_REQUEST.increment();
		BaseResponse<?> response = this.fileUploadService.getchekoutSession();
		response.setMessage("Create Checkout Successfully");
		return response;

	}

}
