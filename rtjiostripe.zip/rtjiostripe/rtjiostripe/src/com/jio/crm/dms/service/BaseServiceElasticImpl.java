package com.jio.crm.dms.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jio.crm.dms.core.BaseModal;
import com.jio.crm.dms.core.BaseResponse;
import com.jio.crm.dms.core.Cursor;
import com.jio.crm.dms.core.Mapper;
import com.jio.crm.dms.exceptions.BaseException;
import com.jio.crm.dms.node.es.ESConnection;

/**
 * Abstract elastic service implementation class to do basic CRUD operations for
 * Jio Devops
 * 
 * @author Barun.rai
 * 
 */
public abstract class BaseServiceElasticImpl<E, M, T> implements BaseService<E, M, T> {

	private Mapper<Map<String, Object>, M> mapper;
	private Cursor cursor;

	public BaseServiceElasticImpl(Mapper<Map<String, Object>, M> mapper) {
		this.mapper = mapper;
	}

	/**
	 * Used to save data to elastic search database
	 * 
	 * @param obj : M model object to be saved
	 *
	 */
	public BaseResponse<M> save(M obj) {

		BaseResponse<M> response = new BaseResponse<>();
		ObjectMapper mapper = new ObjectMapper();
		IndexResponse indexResponse = null;
		try {
			IndexRequest indexRequest = new IndexRequest("subscriptionengine_" + obj.getClass().getSimpleName());
			indexRequest.id(((BaseModal) obj).getId()).source(mapper.writeValueAsBytes(obj));
			indexResponse = ESConnection.getInstance().getClient().index(indexRequest, RequestOptions.DEFAULT);

			response.setData(obj);
			response.setSuccess(indexResponse.getResult().getLowercase().equals("created"));
			response.setMessage("Some message");
			response.setStatus(200);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	/**
	 * Used to save list of data to elastic search database
	 * 
	 * @param objects : a list with T type objects
	 */
	public BaseResponse<List<M>> saveAll(List<M> objects) {
		ObjectMapper mapper = new ObjectMapper();
		BulkResponse response1 = null;
		BaseResponse<List<M>> response = new BaseResponse<>();
		try {
			BulkRequest bulkRequest = new BulkRequest();

			for (M obj : objects) {
				bulkRequest.add(new IndexRequest("subscriptionengine_" + obj.getClass().getSimpleName())
						.id(((BaseModal) obj).getId()).source(mapper.writeValueAsBytes(obj)));

			}

			// ESConnection.getInstance().getClient().prepareIndex(index, type, id)
			response1 = ESConnection.getInstance().getClient().bulk(bulkRequest, RequestOptions.DEFAULT);
			response.setData(objects);
			response.setSuccess(!response1.hasFailures());
			response.setStatus(200);
			response.setMessage(response1.buildFailureMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	/**
	 * Used to retrieve all T type data from database
	 * 
	 * @param c : a class of type T
	 * @return list of data with type as T
	 * 
	 */
	public List<Map<String, Object>> getAll(Class<M> c) {

		SearchResponse response = null;
		try {
			response = ESConnection.getInstance().getClient()
					.search(new SearchRequest("subscriptionengine_" + c.getSimpleName()), RequestOptions.DEFAULT);
		} catch (IOException e) {

			e.printStackTrace();
		}
//				.setQuery(QueryBuilders.matchQuery("_type", c.getSimpleName())).get();"subscriptionengine"
		List<Map<String, Object>> list = new ArrayList<>();
		response.getHits().forEach(x -> {
			x.getSourceAsMap().put("id", x.getId());
			list.add(x.getSourceAsMap());
		});

		return list;
	}

	/**
	 * Used to retrieve all T type data from database based on filters provided
	 * 
	 * @param c   : Class c of Type T
	 * @param map : Map with key value as filter value
	 * @return list of map with filtered value based on filters provided
	 * 
	 */
	// public List<Map<String, Object>> getByParams(Class<M> c, Map<String, String>
	// map) {
	// List<Map<String, Object>> list = new ArrayList<>();
	// BoolQueryBuilder query = new BoolQueryBuilder();
	// map.forEach((key, value) -> {
	// query.filter(QueryBuilders.termsQuery(key, value));
	// });
	// query.filter(QueryBuilders.termsQuery("_type", c.getSimpleName()));
	// SearchResponse response =
	// ESConnection.getInstance().getClient().prepareSearch("subscriptionengine").setQuery(query).get();
	// response.getHits().forEach(x -> {
	// //x.getSource().put("id", x.getId());
	// list.add(x.getSource());
	// });
	//
	// BaseResponse<>
	// return mdata;
	// }

	public BaseResponse<List<M>> get() {
		SearchResponse response = null;
		try {
			if (this.cursor == null) {

				SearchRequest searchRequest = new SearchRequest(
						"subscriptionengine_" + mapper.getType().getSimpleName());
				SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
				searchSourceBuilder.size(100);
				searchRequest.source(searchSourceBuilder);
				searchRequest.scroll(new TimeValue(60000));

				response = ESConnection.getInstance().getClient().search(searchRequest, RequestOptions.DEFAULT);

//					.search(new SearchRequest("subscriptionengine_" + mapper.getType().getSimpleName()),
//							RequestOptions.DEFAULT)
//					.setScroll(new TimeValue(60000)).setSize(100)
//					.setQuery(QueryBuilders.matchQuery("_type", mapper.getType().getSimpleName())).get();

				cursor = new Cursor();
				this.cursor.setAfter(response.getScrollId());

			} else {

				response = ESConnection.getInstance().getClient().scroll(
						new SearchScrollRequest(this.cursor.getAfter()).scroll(new TimeValue(60000)),
						RequestOptions.DEFAULT);

//			response = ESConnection.getInstance().getClient().prepareSearchScroll(this.cursor.getAfter())
//					.setScroll(new TimeValue(60000)).execute().actionGet();
				this.cursor.setAfter(response.getScrollId());

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Map<String, Object>> list = new ArrayList<>();
		response.getHits().forEach(x -> {
			// x.getSource().put("id", x.getId());
			list.add(x.getSourceAsMap());
		});

		List<M> mdata = mapper.mapEntitiesToModels(list);
		BaseResponse<List<M>> responseJson = new BaseResponse<>();
		responseJson.setData(mdata);
		responseJson.setSuccess(true);
		responseJson.setStatus(200);
		if (mdata.isEmpty()) {
			this.cursor = null;
			responseJson.setCursor(null);
		} else {

			responseJson.setCursor(this.cursor);
		}

		responseJson.setMessage("Success");
		return responseJson;

	}

	public BaseResponse<M> getById(T id) {
		GetResponse response = null;
		try {
			response = ESConnection.getInstance().getClient().get(
					new GetRequest("subscriptionengine_" + mapper.getType().getSimpleName()).id(id.toString()),
					RequestOptions.DEFAULT);

		} catch (IOException e) {

			e.printStackTrace();
		}
//				.prepareGet("subscriptionengine", mapper.getType().getSimpleName(), id.toString()).get();

		Map<String, Object> dataMap = response.getSourceAsMap();
		dataMap.put("id", response.getId());
		M data = mapper.mapEntityToModel(dataMap);
		BaseResponse<M> baseResponse = new BaseResponse<>();
		baseResponse.setData(data);
		baseResponse.setMessage("Success");
		baseResponse.setStatus(200);
		return baseResponse;
	}

	public BaseResponse<List<M>> getByParams(Map<?, ?> filters) {

		List<Map<String, Object>> list = new ArrayList<>();
		BoolQueryBuilder query = new BoolQueryBuilder();
		filters.forEach((key, value) -> {
			query.filter(QueryBuilders.termsQuery((String) key, ((String[]) value)[0]));
		});

//		query.filter(QueryBuilders.termsQuery("_type", mapper.getType().getSimpleName()));

		SearchRequest searchRequest = new SearchRequest("subscriptionengine_" + mapper.getType().getSimpleName());
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(query);
		searchRequest.source(searchSourceBuilder);

		SearchResponse response = null;

		try {
			response = ESConnection.getInstance().getClient().search(searchRequest, RequestOptions.DEFAULT);
		} catch (IOException e) {
			e.printStackTrace();
		}

//		SearchResponse response = ESConnection.getInstance().getClient().prepareSearch("subscriptionengine")
//				.setQuery(query).get();

		response.getHits().forEach(x -> {
			// x.getSource().put("id", x.getId());
			list.add(x.getSourceAsMap());
		});
		List<M> mdata = mapper.mapEntitiesToModels(list);
		BaseResponse<List<M>> responseJson = new BaseResponse<>();
		responseJson.setData(mdata);
		responseJson.setSuccess(true);
		responseJson.setMessage("Success");
		responseJson.setStatus(200);
		return responseJson;
	}

	public BaseResponse<M> update(T id, M data) {
		ObjectMapper mapper = new ObjectMapper();
		UpdateRequest updateRequest = new UpdateRequest();
		updateRequest.index("subscriptionengine_" + this.mapper.getType().getSimpleName());
//		updateRequest.type(this.mapper.getType().getSimpleName());
		updateRequest.id(id.toString());

		try {
			updateRequest.doc(mapper.writeValueAsBytes(data));
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			UpdateResponse response = ESConnection.getInstance().getClient().update(updateRequest,
					RequestOptions.DEFAULT);
			System.out.println(response.status());
		} catch (Exception e) {
			System.out.println(e);
		}
		BaseResponse<M> responseJson = new BaseResponse<>();
		responseJson.setSuccess(true);
		responseJson.setMessage("Success");
		responseJson.setStatus(200);
		return responseJson;
	}

	public BaseResponse<M> delete(T id) {

		DeleteRequest deleteRequest = new DeleteRequest("subscriptionengine_User", id.toString());

		DeleteResponse response = null;
		try {
			response = ESConnection.getInstance().getClient().delete(deleteRequest, RequestOptions.DEFAULT);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		DeleteResponse response = ESConnection.getInstance().getClient()
//				.prepareDelete("subscriptionengine", "User", id.toString()).get();

		System.out.println(response.status());
		BaseResponse<M> responseJson = new BaseResponse<>();
		responseJson.setSuccess(true);
		responseJson.setMessage("Success");
		responseJson.setStatus(200);
		return responseJson;
	}

	public BaseResponse<List<M>> getByCursor(Map<?, ?> filters, Cursor cursor) throws BaseException {

		return null;
	}

}
