/**
 * 
 */
package com.jio.crm.dms.modules.upload.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.crm.dms.bean.DocumentCategory;
import com.jio.crm.dms.bean.FileDocument;
import com.jio.crm.dms.logger.DappLoggerService;
import com.jio.subscriptions.modules.bean.DeactivedFileDocument;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class FileUploadRepository {

	public void saveDocument(Session session, FileDocument document) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ document :: " + document + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		session.save(document);
	}

	public void getAllDocument(Session session, FileDocument doc) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		session.get(FileDocument.class);
	}

	public SearchResult<FileDocument> getAllDocumentByFilters(Session session, HashMap<String, String> filters,
			Page page) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		return session.get(FileDocument.class, filters, page);
	}

	public FileDocument getFileDocument(Session session, String fileName) throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		FileDocument document = session.getObject(FileDocument.class, "fileName", fileName);
		return document;
	}

	public FileDocument getFileDocument(Session session, HashMap<String, String> filters)
			throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		FileDocument document = session.getObject(FileDocument.class, filters);
		return document;
	}

	public void updateFiledocuments(Session session, List<FileDocument> filedocuments) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		session.bulk(filedocuments, false);
	}

	public DocumentCategory getDocumentCategory(Session session) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		return session.getObject(DocumentCategory.class, "12345");
	}

	public static void pushDocumentCategory(Session session, DocumentCategory documentCategory) throws Exception {
		session.merge(documentCategory);
	}

	public void deleteFileDocument(Session session, FileDocument fileDocument) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ deleting file document from bean" + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		session.delete(fileDocument);

	}

	public SearchResult<FileDocument> getFileDataOfCustomer(Session session, String customerId)
			throws ElasticSearchException {
		Map<String, Object> filter = new HashMap<String, Object>();
		filter.put("customerId", customerId);
		return session.get(FileDocument.class, filter);
	}

	public void saveDeactivatedFileDocument(Session session, DeactivedFileDocument fileDeactivated) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [saving file data in deactivated file document bean " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		session.merge(fileDeactivated);

	}

}
