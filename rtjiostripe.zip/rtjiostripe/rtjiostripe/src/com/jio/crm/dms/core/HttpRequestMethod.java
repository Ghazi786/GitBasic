package com.jio.crm.dms.core;

public enum HttpRequestMethod {

	GET, POST, DELETE, PUT,PATCH
}
