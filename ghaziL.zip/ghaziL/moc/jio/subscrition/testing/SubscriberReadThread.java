package com.jio.subscrition.testing;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.LongAdder;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;
import com.jio.subscriptions.modules.bean.Plan;
import com.jio.subscriptions.modules.bean.Subscriber;
import com.rjil.gls.timertask.GLSCounterTimerTask;
import com.rjil.gls.timertask.GLSTimerTask;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class SubscriberReadThread implements Runnable {

	public static CopyOnWriteArrayList<String> planlist = new CopyOnWriteArrayList<String>();
	public static Timer timer;

	public static TimerTask timerTask;
	public volatile LongAdder counter = new LongAdder();

	@Override
	public void run() {

		try {
//			createSubscriberExcel();
			synchronized (this) {
				while (SubscriberExcelCreation.pageNo < 500) {
					int a=++SubscriberExcelCreation.pageNo;
					getSubscription2(a, 1);
					Collection<Subscriber> list =getSubscription(a, 10000).getResult();
					System.out.println("list.size="+list.size());
					int init = 0;
					String[] subscriberList = new String[list.size()];
					for (Subscriber subscriber : list) {
						subscriberList[init++] = new String(subscriber.getId());
					}
//				List<String> sublist= list.stream().map(x->x.getId()).collect(Collectors.toList());
					
					SubscriberExcelCreation.data.add(subscriberList);
					System.out.println("SubscriberExcelCreation.data.size=="+SubscriberExcelCreation.data.size());
					
				}
			}
			writeinfile();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void increment() {
		this.counter.increment();
	}

	/**
	 * @return the current value of the counter
	 */
	public long getValue() {
		return counter.longValue();
	}

	public synchronized void  writeinfile() {
		try {
			// this Writes the workbook gfgcontribute

//			if (SubscriberExcelCreation.flag == 0) {
//				return;
//			}
			System.out.println("Size of list=" + SubscriberExcelCreation.data.size());
			if (SubscriberExcelCreation.data.size() != 500) {
				System.out.println("Till now all thread not excuted");
				return;
			}
			SubscriberExcelCreation.flag = 0;
			String profile = System.getProperty("profile");
			String path;
			if (profile != null && profile.equals("dev")) {
				path = "./configuration/susbcription.csv";
			} else {
				path = "../configuration/susbcription.csv";
			}
			FileWriter out = new FileWriter(new File(path));
			CSVWriter writer = new CSVWriter(out);
			writer.writeAll(SubscriberExcelCreation.data);
			writer.close();
			System.out.println("susbcription.csv written successfully on disk.");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void createSubscriberExcel() throws Exception {
		// Blank workbook
		System.out.println("Reading Thread file from Data Base and duming in configuration");

		List<String[]> data = new ArrayList<String[]>();
		for (int i = 0; i < 1000; i++) {

			Collection<Subscriber> list = getSubscription(i + 1, 10000).getResult();
			int init = 0;
			String[] subscriberList = new String[list.size()];
			for (Subscriber subscriber : list) {
				subscriberList[init++] = new String(subscriber.getId());
			}
//			List<String> sublist= list.stream().map(x->x.getId()).collect(Collectors.toList());

			data.add(subscriberList);

		}
		try {
			// this Writes the workbook gfgcontribute

			String profile = System.getProperty("profile");
			String path;
			if (profile != null && profile.equals("dev")) {
				path = "./configuration/susbcription.csv";
			} else {
				path = "../configuration/susbcription.csv";
			}
			FileWriter out = new FileWriter(new File(path));
			CSVWriter writer = new CSVWriter(out);
			writer.writeAll(data);
			writer.close();
			System.out.println("susbcription.csv written successfully on disk.");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static SearchResult<Subscriber> getSubscription(int pageNo, int pageSize) throws Exception {
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		Page page = session.defaultPage();
		page.setPageLength(pageSize);
		page.setPageNo(pageNo);
//		SearchSourceBuilder source=new SearchSourceBuilder();
//		SearchRequest s2=session.getSearchRequestBuilder(Subscriber.class);
//		
//		source.timeout(new TimeValue(10, TimeUnit.MINUTES));
		
		SearchResult<Subscriber> result = session.get(Subscriber.class, page);
		System.out.println(
				"Page no=" + pageNo + ", " + "data Count=" + result.getDocumentsCount() + " page Size=" + pageSize);
		return result;

	}
	public static SearchResult<Subscriber> getSubscription2(int pageNo, int pageSize) throws Exception {
//		SessionFactory factory = SessionFactory.getSessionFactory();
//		Session session = factory.getSession();
//		SearchSourceBuilder source=new SearchSourceBuilder();
//		SearchRequest s2=session.getSearchRequestBuilder(Subscriber.class);
//		
//		source.timeout(new TimeValue(10, TimeUnit.MINUTES));
		SearchRequest searchRequest = new SearchRequest("dev_subscriptionengine_subscriber");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder
		.size(10);
		searchRequest.source(searchSourceBuilder);
		searchRequest.scroll(TimeValue.timeValueMinutes(1L));
		SearchResponse searchResponse = ESConnection.getInstance().getClient().search(searchRequest, RequestOptions.DEFAULT);
		String scrollId = searchResponse.getScrollId();
		SearchHit[] resultsHits = searchResponse.getHits().getHits();
		// Printing the numberOfHits obtainedlogger.info("Total number of hits from ES obtained for dataSource "+dataSourceName+":- " + searchResponse.getHits().getTotalHits().value);
		if(searchResponse.getHits().getHits().length>0)
		{
		while (resultsHits!=null && resultsHits.length > 0)
		{
//		for (SearchHit hit : resultsHits) {
//		// Storing the file obtained in the fileNames json Array
//		}

		SearchScrollRequest scrollRequest = new SearchScrollRequest(scrollId);
		scrollRequest.scroll(TimeValue.timeValueMinutes(1L));
		SearchResponse searchScrollResponse= ESConnection.getInstance().getClient().scroll(scrollRequest, RequestOptions.DEFAULT);
		scrollId = searchScrollResponse.getScrollId();
		resultsHits = searchScrollResponse.getHits().getHits();

		}

		}
		
		System.out.println(
				"Page no=" + pageNo + ", " + " page Size=" + pageSize);
		return null;

	}

//	public static void readSubscriberExcel() {
//		FileReader fileInputStream2 = null;
//		CSVReader csvReader = null;
//		try {
//			System.out.println("Reading");
//			String profile = System.getProperty("profile");
//			if (profile != null && profile.equals("dev")) {
//				fileInputStream2 = new FileReader("./configuration/susbcription.csv");
//			} else {
//				fileInputStream2 = new FileReader("../configuration/susbcription.csv");
//			}
//			csvReader = new CSVReader(fileInputStream2);
//			String[] nextRecord;
//			ConcurrentLinkedQueue<String> list = new ConcurrentLinkedQueue<String>();
//
//			// we are going to read data line by line
//			while ((nextRecord = csvReader.readNext()) != null) {
//				for (String cell : nextRecord) {
//					list.add(cell);
//				}
//			}
//
//			SubscriberExcelCreation.list = list;
//			System.out.println("Size of List=" + list.size());
//			getAllPlan();
//			timer = new Timer();
//			/* 91 */ timerTask = (TimerTask) new GLSTimerTask();
//			/* 92 */ timer.schedule(timerTask, 1000L, 100L);
//			/*     */
//			/* 94 */ Timer timerCounter = new Timer();
//			/* 95 */ GLSCounterTimerTask gLSCounterTimerTask = new GLSCounterTimerTask();
//			/* 96 */ timerCounter.schedule((TimerTask) gLSCounterTimerTask, 1000L, 1000L);
//
//		} catch (Exception e) {
//			System.out.println("Exception");
//		} finally {
//			try {
//				fileInputStream2.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}

	public static Collection<Plan> getAllPlan() throws ElasticSearchException {
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();

		Collection<Plan> result = session.get(Plan.class).getResult();
		int flag = 0;
		for (Plan plan : result) {
			if (flag == 0) {
				SubscriberExcelCreation.planlist.add(plan.getId());
				SubscriberExcelCreation.planlist.add(plan.getId());
				SubscriberExcelCreation.planlist.add(plan.getId());
				SubscriberExcelCreation.planlist.add(plan.getId());
				flag = 1;
			}
			SubscriberExcelCreation.planlist.add(plan.getId());
		}
		return result;
	}

}
