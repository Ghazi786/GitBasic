package com.jio.subscrition.testing;

import java.util.TimerTask;

import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.gls.boostrapmanager.GLSBootstrapper;

public class SubscriberReadTask extends TimerTask {

	@Override
	public void run() {
		try {
			
				for(int i=0;i<200;i++) {
					
					SubscriberReadThread task = (SubscriberReadThread) PoolingManager.getPoolingManager()
							.borrowObject(SubscriberReadThread.class);
					GLSBootstrapper.getInstance().getThreadPoolExecutor().execute((Runnable) task);
				}
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	

}
