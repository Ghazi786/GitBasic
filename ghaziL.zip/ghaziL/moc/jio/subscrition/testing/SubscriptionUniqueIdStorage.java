/**
 * 
 */
package com.jio.subscrition.testing;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class SubscriptionUniqueIdStorage {
	public static ConcurrentHashMap<String,String> hashSet = (new ConcurrentHashMap<String, String>());
	public static ConcurrentLinkedQueue<String> list[] = new ConcurrentLinkedQueue[1000];
	public static volatile int index =0;
	public static volatile int start =1;
	public static String xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
			"<EDITS>\r\n" + 
			"  <EDITS_VERSION>-63</EDITS_VERSION>\r\n" + 
			"  <RECORD>\r\n" + 
			"    <OPCODE>OP_START_LOG_SEGMENT</OPCODE>\r\n" + 
			"    <DATA>\r\n" + 
			"      <TXID>1074959</TXID>\r\n" + 
			"    </DATA>\r\n" + 
			"  </RECORD>\r\n" + 
			"  <RECORD>\r\n" + 
			"    <OPCODE>OP_END_LOG_SEGMENT</OPCODE>\r\n" + 
			"    <DATA>\r\n" + 
			"      <TXID>1074960</TXID>\r\n" + 
			"    </DATA>\r\n" + 
			"  </RECORD>\r\n" + 
			"</EDITS>\r\n" + 
			"";
	public static void get() {
		
	}

}
