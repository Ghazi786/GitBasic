/**
 * 
 */
package com.jio.subscrition.testing;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.LongAdder;

import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptions.modules.bean.Plan;
import com.jio.subscriptions.modules.bean.Subscriber;
import com.rjil.gls.timertask.GLSCounterTimerTask;
import com.rjil.gls.timertask.GLSTimerTask;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class SubscriberExcelCreation {
	public static ConcurrentLinkedQueue<String> list[] = new ConcurrentLinkedQueue[100];
	public static CopyOnWriteArrayList<String> planlist=new CopyOnWriteArrayList<String>();
	public static Timer timer;

	public static TimerTask timerTask;
	public volatile LongAdder counter=new LongAdder();
	public static CopyOnWriteArrayList<String[]> data=new CopyOnWriteArrayList<String[]>();
	static volatile int pageNo =0;  
	public static volatile int index =0;
	static volatile int flag =1;  
	
	
	public void increment() {
		this.counter.increment();
		
	}

	/**
	 * @return the current value of the counter
	 */
	public long getValue() {
		return counter.longValue();
	}

	public static void createSubscriberExcel() throws Exception {
		// Blank workbook
		System.out.println("Reading file from Data Base and duming in configuration");

		
		List<String[]> data = new ArrayList<String[]>();
		for (int i = 0; i < 1000; i++) {
			
			Collection<Subscriber> list = getSubscription(i + 1, 10000).getResult();
			int init=0;
			String[] subscriberList=new String[list.size()];
			for (Subscriber subscriber : list) {
				subscriberList[init++]=new String(subscriber.getId());
			}
//			List<String> sublist= list.stream().map(x->x.getId()).collect(Collectors.toList());

			data.add(subscriberList);


		}
		try {
			// this Writes the workbook gfgcontribute

			String profile = System.getProperty("profile");
			String path;
			if (profile != null && profile.equals("dev")) {
				path = "./configuration/susbcription.csv";
			} else {
				path = "../configuration/susbcription.csv";
			}
			FileWriter out = new FileWriter(new File(path));
			CSVWriter writer = new CSVWriter(out);
			writer.writeAll(data);
			writer.close();
			System.out.println("susbcription.csv written successfully on disk.");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static SearchResult<Subscriber> getSubscription(int pageNo, int pageSize) throws Exception {
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		Page page = session.defaultPage();
		page.setPageLength(pageSize);
		page.setPageNo(pageNo);
		SearchResult<Subscriber> result = session.get(Subscriber.class, page);
		System.out.println("Page no="+pageNo+", "+"data Count="+result.getDocumentsCount()+" page Size="+pageSize);
		return result;

	}

	public static void readSubscriberExcel() {
		FileReader fileInputStream2 = null;
		CSVReader csvReader = null;
		try {
			System.out.println("Reading");
			String profile = System.getProperty("profile");
			if (profile != null && profile.equals("dev")) {
				fileInputStream2 = new FileReader("./configuration/susbcription.csv");
			} else {
				fileInputStream2 = new FileReader("../configuration/susbcription.csv");
			}
			csvReader=new CSVReader(fileInputStream2);
			String[] nextRecord;
			ConcurrentLinkedQueue<String> list = new ConcurrentLinkedQueue<String>();
			  
	        // we are going to read data line by line
	        while ((nextRecord = csvReader.readNext()) != null) {
	            for (String cell : nextRecord) {
	                list.add(cell);
	            }
	        }
	        int size=list.size();
	        System.out.println("Size of List=" + size);
	        for(int i=0;i<100;i++) {
	        	SubscriberExcelCreation.list[i]=new ConcurrentLinkedQueue<String>();
	        }
			for(int i=0;i<size;i++) {
//				System.out.println(i);
				SubscriberExcelCreation.list[i/100000].add(list.poll());
			}
			
			for(int i=0;i<100;i++) {
				System.out.println("list size "+(i+1)+"="+SubscriberExcelCreation.list[i].size());
	        }
//			SubscriberExcelCreation.list = list;
			
			getAllPlan();
			timer = new Timer();
			/* 91 */ timerTask = (TimerTask) new GLSTimerTask();
			/* 92 */ timer.schedule(timerTask, 1000L, 100L);
//			/*     */
			/* 94 */ Timer timerCounter = new Timer();
			/* 95 */ GLSCounterTimerTask gLSCounterTimerTask = new GLSCounterTimerTask();
			/* 96 */ timerCounter.schedule((TimerTask) gLSCounterTimerTask, 1000L, 1000L);

		} catch (Exception e) {
			System.out.println("Exception");
		} finally {
			try {
				fileInputStream2.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static Collection<Plan> getAllPlan() throws ElasticSearchException {
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();

		Collection<Plan> result = session.get(Plan.class).getResult();
		int flag=0;
		for (Plan plan : result) {
			if(flag==0) {
				SubscriberExcelCreation.planlist.add(plan.getId());
				SubscriberExcelCreation.planlist.add(plan.getId());
				SubscriberExcelCreation.planlist.add(plan.getId());
				SubscriberExcelCreation.planlist.add(plan.getId());
				flag=1;
			}
			SubscriberExcelCreation.planlist.add(plan.getId());
		}
		return result;
	}

}
