package com.jio.subscrition.testing;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.RandomStringUtils;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptions.modules.bean.Subscriber;

import au.com.bytecode.opencsv.CSVWriter;

public class SubscriberCreateThread implements Runnable {
	

	@Override
	public void run() {
		
		synchronized (this) {
			
			for (int i = 0; i < 20; i++) {
				// make pojoSu
				String[] subscriberListTemp=null;
				List<Subscriber> subscriberList = new ArrayList<Subscriber>();
				subscriberListTemp= new String[5000];

				for (int j = 0; j < 5000; j++) {
					Subscriber s = new Subscriber();
					String email=RandomStringUtils.randomAlphanumeric(15)+"@ril.com";
					s.setEmail(email);
					s.setUsername(email);
					String uuid=UUID.randomUUID().toString();
					s.setId(uuid);
					subscriberList.add(s);
					subscriberListTemp[j] = new String(uuid);
//			List<String> sublist= list.stream().map(x->x.getId()).collect(Collectors.toList());
					
//				100*20*5000=10000000
				}
				SubscriberExcelCreation.data.add(subscriberListTemp);
				// save
				try {
					System.out.println("Size store in List="+SubscriberExcelCreation.data.size());
					saveSubscriber(subscriberList);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					subscriberList = null;
				}
				
			}
			writeinfile();
		}
		
	}
	
	public synchronized void  writeinfile() {
		try {
			// this Writes the workbook gfgcontribute

//			if (SubscriberExcelCreation.flag == 0) {
//				return;
//			}
			System.out.println("Size of list=" + SubscriberExcelCreation.data.size());
			if (SubscriberExcelCreation.data.size() != 2000) {
				System.out.println("Till now all thread not excuted");
				return;
			}
			SubscriberExcelCreation.flag = 1;
			String profile = System.getProperty("profile");
			String path;
			if (profile != null && profile.equals("dev")) {
				path = "./configuration/susbcription.csv";
			} else {
				path = "../configuration/susbcription.csv";
			}
			FileWriter out = new FileWriter(new File(path));
			CSVWriter writer = new CSVWriter(out);
			writer.writeAll(SubscriberExcelCreation.data);
			writer.close();
			System.out.println("susbcription.csv written successfully on disk.");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void saveSubscriber(List<Subscriber> subscriberList) throws Exception {
		final SessionFactory factory = SessionFactory.getSessionFactory();

		final Session session = factory.getSession();
		session.bulk(subscriberList, false);
	}

}
