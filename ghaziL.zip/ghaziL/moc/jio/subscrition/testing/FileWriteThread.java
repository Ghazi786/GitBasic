package com.jio.subscrition.testing;

public class FileWriteThread {

	public FileWriteThread() {
		// TODO Auto-generated constructor stub
	}

}
