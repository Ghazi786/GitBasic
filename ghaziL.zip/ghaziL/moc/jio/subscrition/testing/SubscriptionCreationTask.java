package com.jio.subscrition.testing;

import java.util.TimerTask;

import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.gls.boostrapmanager.GLSBootstrapper;

public class SubscriptionCreationTask extends TimerTask {

	@Override
	public void run() {
		try {
			for (int i = 0; i < 100; i++) {
				
				SubscriberCreateThread task = (SubscriberCreateThread) PoolingManager.getPoolingManager()
						.borrowObject(SubscriberCreateThread.class);
				GLSBootstrapper.getInstance().getThreadPoolExecutor().execute((Runnable) task);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
