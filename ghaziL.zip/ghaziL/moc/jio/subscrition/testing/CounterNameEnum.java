package com.jio.subscrition.testing;

import java.util.concurrent.atomic.LongAdder;

/**
 * 
 * This Class Define Counter Name
 * 
 * @author Kiran.Jangid
 *
 */

public enum CounterNameEnum {

	PAGE_NO;

	private volatile LongAdder counter;

	private CounterNameEnum() {
		this.counter = new LongAdder();
	}

	/**
	 * reset the counter value to 0
	 */
	public void reset() {
		this.counter.reset();
	}

	/**
	 * increment the counter value by 1
	 */
	public void increment() {
		this.counter.increment();
	}
	

	/**
	 * @return the current value of the counter
	 */
	public long getValue() {
		return counter.longValue();
	}

}
