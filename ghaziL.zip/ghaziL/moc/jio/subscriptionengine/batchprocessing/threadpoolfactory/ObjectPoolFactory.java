package com.jio.subscriptionengine.batchprocessing.threadpoolfactory;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;

public class ObjectPoolFactory<T> implements PooledObjectFactory<T> {


	private String object_name = null;
	private String class_name = null;
	
	public ObjectPoolFactory(String objName, String classsName) {
		this.object_name = objName;
		this.class_name = classsName;
	}

	@Override
	public void activateObject(PooledObject<T> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroyObject(PooledObject<T> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PooledObject<T> makeObject() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void passivateObject(PooledObject<T> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateObject(PooledObject<T> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

}
