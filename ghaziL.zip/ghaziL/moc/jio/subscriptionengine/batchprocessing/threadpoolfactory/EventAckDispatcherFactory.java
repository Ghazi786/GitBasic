package com.jio.subscriptionengine.batchprocessing.threadpoolfactory;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;

public class EventAckDispatcherFactory implements PooledObjectFactory<EventAckRequestDispatcher> {

	@Override
	public void activateObject(PooledObject<EventAckRequestDispatcher> arg0) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void destroyObject(PooledObject<EventAckRequestDispatcher> arg0) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public PooledObject<EventAckRequestDispatcher> makeObject() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void passivateObject(PooledObject<EventAckRequestDispatcher> arg0) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean validateObject(PooledObject<EventAckRequestDispatcher> arg0) {
		// TODO Auto-generated method stub
		return false;
	}
}
