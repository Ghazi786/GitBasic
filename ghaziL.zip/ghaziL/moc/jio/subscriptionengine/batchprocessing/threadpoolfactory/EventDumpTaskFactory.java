package com.jio.subscriptionengine.batchprocessing.threadpoolfactory;

import com.jio.subscriptionengine.batchprocessing.ha.EventDumpTask;
import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class EventDumpTaskFactory implements PooledObjectFactory<EventDumpTask> {

	private static final String OBJECT_NAME = "EventDumpTask";
	private static final String CLASS_NAME = EventDumpTaskFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<EventDumpTask> arg0) throws Exception {
	}

	@Override
	public void destroyObject(PooledObject<EventDumpTask> arg0) throws Exception {
	}

	@Override
	public PooledObject<EventDumpTask> makeObject() throws Exception {
		return new DefaultPooledObject<>(new EventDumpTask());
	}

	@Override
	public void passivateObject(PooledObject<EventDumpTask> arg0) throws Exception {
	}

	@Override
	public boolean validateObject(PooledObject<EventDumpTask> arg0) {
		return false;
	}
}
