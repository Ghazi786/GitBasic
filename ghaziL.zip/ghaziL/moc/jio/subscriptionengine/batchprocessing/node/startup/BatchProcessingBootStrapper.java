package com.jio.subscriptionengine.batchprocessing.node.startup;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import com.atom.OAM.Client.Management.OamClientManager;
import com.atom.OAM.Client.Management.OamClientRegistrationNotifier;
import com.atom.OAM.Client.util.OamClientConstants;
import com.elastic.search.config.ElasticConfig;
import com.elastic.search.config.IndexConfig;
import com.elastic.search.launcher.SessionFactory;
import com.j256.simplejmx.server.JmxServer;
import com.j256.simplejmx.web.JmxWebServer;
import com.jio.blockchain.sdk.event.ERMRequestBuilderManager;
import com.jio.resttalk.service.impl.RestTalkManager;
import com.jio.subscriptionengine.batchprocessing.Kafka.ConsumerUtils;
import com.jio.subscriptionengine.batchprocessing.alarmManager.AlarmConditionalCntrListener;
import com.jio.subscriptionengine.batchprocessing.alarmManager.AlarmLoggingListener;
import com.jio.subscriptionengine.batchprocessing.alarmManager.MemoryOverflowListener;
import com.jio.subscriptionengine.batchprocessing.clearCodes.JiodevopsAsnCallBackIntfImpl;
import com.jio.subscriptionengine.batchprocessing.configurationManager.ConfigParamsEnum;
import com.jio.subscriptionengine.batchprocessing.configurationManager.ExcelWorkbook;
import com.jio.subscriptionengine.batchprocessing.configurationManager.InterfaceStatus;
import com.jio.subscriptionengine.batchprocessing.configurationManager.RuntimeConfigurationEngine;
import com.jio.subscriptionengine.batchprocessing.countermanager.CounterManager;
import com.jio.subscriptionengine.batchprocessing.handler.ReplicationListener;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.logger.MarketplaceLogManager;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;
import com.jio.subscriptionengine.batchprocessing.node.shutdown.ServerShutdownHook;
import com.jio.subscriptionengine.batchprocessing.notification.NotificationService;
import com.jio.subscriptionengine.batchprocessing.redis.RedisConnectionService;
import com.jio.subscriptionengine.batchprocessing.registry.RtJioObserver;
import com.jio.subscriptionengine.batchprocessing.rest.JettyRestEngine;
import com.jio.subscriptionengine.batchprocessing.rest.Statistics;
import com.jio.subscriptionengine.batchprocessing.scheduler.SchedularApiService;
import com.jio.subscriptionengine.batchprocessing.threadpool.DappThreadPoolExecutor;
import com.jio.subscriptionengine.batchprocessing.utils.ExcelBookConstants;
import com.jio.subscrition.testing.SubscriberExcelCreation;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeBuilder;
import com.jio.telco.framework.pool.PoolingManager;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rpc.cluster.OSValidator;
import com.rjil.rpc.cluster.RPCManager;

/**
 * This class is a bootstrap class. It is used to initialize all the modules.
 * 
 * @author Kiran.Jangid
 *
 */

public class BatchProcessingBootStrapper {
	private static BatchProcessingBootStrapper bootStrapper = new BatchProcessingBootStrapper();
	private Serializer serializer = new Persister();
	private String componentId = "na";
	private JettyRestEngine jettyRestEngine = null;
	private RuntimeConfigurationEngine configEngine = null;
	private JmxServer jmxServer = null;
	private JmxWebServer jmxWebServer = null;
	private Mbeans mbean = null;
	private DappThreadPoolExecutor dappExecutor = null;
	private ThreadPoolExecutor threadPoolService = (ThreadPoolExecutor) Executors.newFixedThreadPool(12);
	private ERMRequestBuilderManager ermRequestBuilderManager;
	private static Properties configProps = new Properties();

	public static BatchProcessingBootStrapper getInstance() {
		synchronized (BatchProcessingBootStrapper.class) {
			if (bootStrapper == null) {
				bootStrapper = new BatchProcessingBootStrapper();
			}
		}
		return bootStrapper;
	}

	/*
	 * main method to start the java application
	 */
	public static void main(String args[]) throws Exception {
		System.out.println("-------------- Starting Dapp --------------");
		bootStrapper.initializeConfigParamSheet();
		bootStrapper.initLogger();
		bootStrapper.initializeMbeans();
		bootStrapper.initializeManagers();
		bootStrapper.initilizeJetteyRestEngine();
//		ESConnection.getInstance().initializeES();
//		bootStrapper.registerWithOAM();
//		 ESConnection.getInstance().initializeES();
		bootStrapper.printModulesStatus();
		bootStrapper.addShutdownHook();
		bootStrapper.initializeClearCode();

		// Elastic search wrapper
//		bootStrapper.initializeElasticSearchSessionFactory();
//		bootStrapper.initializeRedis();

		// init RPC
//		bootStrapper.initRPC();

		// String profile = System.getProperty("profile");
		// if (profile != null && !profile.equals("dev")) {
		// bootStrapper.initializeSchedular();
		// }

		// initializing notification service
//		NotificationService.getInstance().init();
		//CachePlansUtils.getInstance().setAllPlans();
//		ConsumerUtils.getInstance().startConsumer();
//		SubscriberExcelCreation.createSubscriberExcel();
//		SubscriberExcelCreation.readSubscriberExcel();
		
		

		System.out.println("-------------- Dapp is started successfully --------------");

		// Thread.sleep(5000);
		// System.out.println("Raising alarm..!!!");
		// OamClientManager.getOamClientForAlarm().raiseAlarmToOamServer(DappAlarmNameIntf.DEVOPS_STARTUP_SUCCESS);

	}

	private void initializeRedis() {
		try {
			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeLog();
			RedisConnectionService.initialize();
			// RedisConnectionService.initializeClient("127.0.0.1",6379);

		} catch (Exception e) {
			// error logger
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
	}

	public void initializeConfigParamSheet() {
		ExcelWorkbook.getInstance().initialize();

		// loading configuration from excel to ConfigParamEnum
		configEngine = new RuntimeConfigurationEngine();
		System.out.println("Configuration Sheet has been loaded");

	}

	private void initLogger() {
		try {

			String CONFIG_PARAM_PATH = "./configuration/ConfigParamSheet.xlsx";

			String profile = System.getProperty("profile");
			if (profile == null || !profile.equals("dev")) {
				CONFIG_PARAM_PATH = ExcelBookConstants.CONFIG_PARAM_PATH;
			}

			bootStrapper.setComponentId(OamClientManager.getInstance().readOamClientConfig(CONFIG_PARAM_PATH));
			MarketplaceLogManager.getInstance().initLogger(componentId);
			InterfaceStatus.status.setLoggingModule(true);
			System.out.println("Logger has been initialized");
		} catch (Exception e) {

			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), "initLogger");
			InterfaceStatus.status.setLoggingModule(false);
		}

	}

	private void initializeManagers() {

		try {
			RestTalkManager.getInstance().startRestTalk();
			CounterManager.getInstance();

			// thread pool getting initailized
			// dappExecutor
			dappExecutor = new DappThreadPoolExecutor(ConfigParamsEnum.CORE_POOL_SIZE.getIntValue(),
					ConfigParamsEnum.MAX_CORE_POOL_SIZE.getIntValue(), ConfigParamsEnum.KEEP_ALIVE_TIME.getLongValue(),
					TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
			InterfaceStatus.status.setThreadPoolingManager(true);

			System.out.println("Managers have been initialzed");
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "initializeManagers")
					.writeExceptionLog();
		}

	}

	// Method to add Mbeans
	private void initializeMbeans() {
		try {
			configEngine.startMbean();
			CounterManager.getInstance().startCounterMbeanService();
			Statistics.getInstance().startStatisticsMbeanService();
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "initializeMbeans")
					.writeExceptionLog();
		}
	}

	public JettyRestEngine getJettyRestEngine() {
		return jettyRestEngine;
	}

	private void initilizeJetteyRestEngine() {

		this.jettyRestEngine = new JettyRestEngine();
		try {
			this.jettyRestEngine.initialise();
		} catch (Exception e) {

			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					BatchProcessingBootStrapper.getInstance().getClass().getName(), "initilizeJetteyRestEngine")
					.writeExceptionLog();
		}

	}

	public DappThreadPoolExecutor getDappExecutor() {
		return dappExecutor;
	}

	public Serializer getSerializer() {
		return serializer;
	}

	public String getComponentId() {
		return componentId;
	}

	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}

	public RuntimeConfigurationEngine getConfigEngine() {
		return configEngine;
	}

	public ERMRequestBuilderManager getErmRequestBuilderManager() {
		return ermRequestBuilderManager;
	}

	/**
	 * Register with Oam
	 */

	public void registerWithOAM() {
		try {

			String CONFIG_PARAM_PATH = "./configuration/ConfigParamSheet.xlsx";

			String profile = System.getProperty("profile");
			if (profile == null || !profile.equals("dev")) {
				CONFIG_PARAM_PATH = ExcelBookConstants.CONFIG_PARAM_PATH;
			}

			OamClientRegistrationNotifier.getInstance().addObserver(new RtJioObserver());

			OamClientManager.getInstance().initializeWithESHttpClient(MarketplaceLogManager.getInstance().getLogger(),
					CONFIG_PARAM_PATH, new AlarmLoggingListener(), new AlarmConditionalCntrListener(), null,
					new MemoryOverflowListener(), false, null,
					OamClientManager.getInstance().getOAMClientParam(OamClientConstants.ID),
					ConfigParamsEnum.httpIP.getStringValue(), ConfigParamsEnum.httpPort.getStringValue(),
					ConfigParamsEnum.username.getStringValue(), ConfigParamsEnum.password.getStringValue());

			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder("Registration done...", this.getClass().getName(), "registerWithOAM").writeLog();

			InterfaceStatus.status.setRegisterWithOAM(true);

		} catch (Exception e) {

			InterfaceStatus.status.setRegisterWithOAM(false);
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "registerWithOAM")
					.writeExceptionLog();

		}
	}

	public String printModulesStatus() {

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("\n+++++++++++++++++++++++++++++++++").append("\nMODULE/INTERFACE\t: STATUS")
				.append("\n+++++++++++++++++++++++++++++++++")
				.append("\n" + "LoggingModule\t\t: " + InterfaceStatus.status.isLoggingModule())
				.append("\n" + "ConfigurationModule\t: " + InterfaceStatus.status.isConfigurationModule())
				.append("\n" + "JettyInterface\t\t: " + InterfaceStatus.status.isJettyInterface())
				.append("\n" + "CounterModule\t\t: " + InterfaceStatus.status.isCounterModule())
				.append("\n" + "Thread PoolingManager   : " + InterfaceStatus.status.isThreadPoolingManager())
				.append("\n" + "Object PoolingManager   : " + InterfaceStatus.status.isObjectPoolingManager())
				.append("\n" + "RegisterWithOAM\t\t: " + InterfaceStatus.status.isRegisterWithOAM())
				.append("\n" + "RegisterWithES\t\t: " + InterfaceStatus.status.isEsConnected())
				.append("\n+++++++++++++++++++++++++++++++++");

		DappLoggerService.GENERAL_INFO_LOG.getInfoLogBuilder(stringBuilder.toString()).writeLog();

		System.out.println(stringBuilder.toString());

		return stringBuilder.toString();

	}

	/*
	 * stop local jetty server and jmx server
	 */
	public boolean shutdown_node() {
		boolean res = false;
		try {
			JettyRestEngine jettyRestEngine = new JettyRestEngine();
			jettyRestEngine.stopJettyServer();
			jmxServer.unregister(mbean);
			jmxServer.stop();
			jmxWebServer.stop();
			res = true;
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage());
		}
		return res;
	}

	/**
	 * 
	 */

	public void initializeClearCode() {
		try {
			ClearCodeBuilder builder = ResourceBuilder.clearCode();
			builder.setXdrRecordLimitPerFile(ConfigParamsEnum.XDR_RECORD_LIMIT_PER_FILE.getStringValue())
					.setXdrLocalPath(ConfigParamsEnum.XDR_LOCAL_DUMP_PATH.getStringValue())
					.setIsXDRFtpEnabled(ConfigParamsEnum.XDR_FTP_ENABLED.getBooleanValue())
					.setRemoteHostAddress(ConfigParamsEnum.XDR_REMOTE_ADDRESSES.getStringValue())
					.setRemoteUsername(ConfigParamsEnum.XDR_REMOTE_USER_NAME.getStringValue())
					.setRemotePassword(ConfigParamsEnum.XDR_REMOTE_PASSWORD.getStringValue())
					.setRemotePath(ConfigParamsEnum.XDR_REMOTE_DUMP_PATH.getStringValue())
					.setXdrNodeName(ConfigParamsEnum.MARKET_PLACE_CLEAR_CODE.getStringValue())
					.setXdrAsnCallBackIntf(new JiodevopsAsnCallBackIntfImpl());
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, "Error in initializeClearCode",
					this.getClass().getName(), "initializeClearCode");
		}

	}

	// getting clearcode class object from this method
	public ClearCodeAsnPojo getClearCodeObj() {
		ClearCodeAsnPojo cccObj = null;
		try {
			cccObj = (ClearCodeAsnPojo) PoolingManager.getPoolingManager().borrowObject(ClearCodeAsnPojo.class);
			cccObj.setStartTime();
			cccObj.getStartTime();
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, "Error in getClearcodeObj",
					this.getClass().getName(), "getClearCodeObj");
		}
		return cccObj;
	}

	public void initializeElasticSearchSessionFactory() {
		try {

			IndexConfig indexConfig = new IndexConfig();
			indexConfig.setIndexName(ConfigParamsEnum.ES_IndexName.getStringValue());
			indexConfig.setType(ConfigParamsEnum.ES_TypeName.getStringValue());

			ElasticConfig elasticConfig = new ElasticConfig();
			elasticConfig.setClusterName(ConfigParamsEnum.ES_ClusterName.getStringValue());
			elasticConfig.setUserName(ConfigParamsEnum.ES_XPackUname.getStringValue());
			elasticConfig.setPassword(ConfigParamsEnum.ES_XPackPassword.getStringValue());
			elasticConfig.setHost(ConfigParamsEnum.ES_CoordinatorNodeipAndPort.getStringValue());

			SessionFactory factory = new SessionFactory.builder(indexConfig).withElasticConfig(elasticConfig)
					.buildSessionFactory();

			boolean isConnected = factory.ping();

			if (isConnected) {
				InterfaceStatus.status.setEsConnected(true);
				DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(
						"###################### Connection has been created with ES cluster ######################",
						this.getClass().getName(), "initializeElasticSearchSessionFactory").writeLog();

			} else {
				DappLoggerService.GENERAL_INFO_LOG
						.getLogBuilder("XXXXXXXXXXXXXXXXXXXXXX ES CONNECTION NOT CREATEDXXXXXXXXXXXXXXXXXXXXXX",
								this.getClass().getName(), "createConnectionWithCluster")
						.writeLog();

			}

		} catch (Exception e) {
			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(e.getMessage(), this.getClass().getName(), "initializeElasticSearchSessionFactory")
					.writeLog();
		}

	}

	private void addShutdownHook() {
		Runtime.getRuntime().addShutdownHook(new ServerShutdownHook(BatchProcessingBootStrapper.getInstance()));
	}

	private void initializeSchedular() {
		try {
			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeLog();
			SchedularApiService.getInstance().initialize();

		} catch (Exception e) {
			// error logger
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
	}

	private void initRPC() {
		// TODO Auto-generated method stub
		FileInputStream in = null;
		try {
			if (OSValidator.isWindows())
				in = new FileInputStream(
						new File("." + File.separator + "configuration" + File.separator + "cluster.properties"));

			else
				in = new FileInputStream(
						new File(".." + File.separator + "configuration" + File.separator + "cluster.properties"));

			configProps.load(in);
			// in.close();
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, "Error in initRPC",
					this.getClass().getName(), "initRPC");
		}
		/**
		 * -----------------------
		 */

		// Initialisation of RPC MOdule

		RPCManager.rpcManager.setListener(new ReplicationListener());

		RPCManager.rpcManager.initClusterAndReplication(configProps.getProperty("clusterName"),
				configProps.getProperty("nodeId"), configProps.getProperty("localIp"),
				configProps.getProperty("clusterAddresses"), configProps.getProperty("nodeNamesInTheCluster"),
				Integer.parseInt(configProps.getProperty("localReconnectionInterval")),
				configProps.getProperty("geoLocalIp"), Integer.parseInt(configProps.getProperty("geoLocalPort")),
				configProps.getProperty("geoRemoteIp"), Integer.parseInt(configProps.getProperty("geoRemotePort")),
				Boolean.parseBoolean(configProps.getProperty("geoNode")),
				Integer.parseInt(configProps.getProperty("geoReconnectionInterval")),
				MarketplaceLogManager.getInstance().getLogger());

		try {
			RPCManager.rpcManager.getChannelFluctuationTestingMBean().start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, "Error in initRPC",
					this.getClass().getName(), "initRPC");
		}
		RPCManager.rpcManager.replicationMapStats();

	}

	public ThreadPoolExecutor getThreadPoolService() {
		return threadPoolService;
	}

	public void setThreadPoolService(ThreadPoolExecutor threadPoolService) {
		this.threadPoolService = threadPoolService;
	}
}
