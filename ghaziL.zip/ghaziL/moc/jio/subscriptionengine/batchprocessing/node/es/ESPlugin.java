package com.jio.subscriptionengine.batchprocessing.node.es;

import org.elasticsearch.plugins.Plugin;

public class ESPlugin extends Plugin {

}
