package com.jio.subscriptionengine.batchprocessing.node.shutdown;

import java.io.IOException;

import com.atom.OAM.Client.Management.OamClientManager;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.redis.RedisConnectionService;
import com.jio.subscriptionengine.batchprocessing.scheduler.SchedularApiService;
import com.jio.blockchain.sdk.bootstrap.SDKBootStrap;

public class ServerShutdownHook extends Thread {

	private BatchProcessingBootStrapper bootStrapper;

	/**
	 * 
	 * @param bootStrapper
	 */
	public ServerShutdownHook(BatchProcessingBootStrapper bootStrapper) {
		this.bootStrapper = bootStrapper;
	}

	@Override
	public void run() {
		System.out.println("Shutdown hook called...");

		if (bootStrapper.getConfigEngine().dumpConfigParams()) {
			System.out.println("Configuration file dumped Successfully");
		}

		try {
			RedisConnectionService.getInstance().close();
			SchedularApiService.getInstance().shutdown();
			stopMbeans();
			SDKBootStrap.getInstance().shutDownSdk();
			BatchProcessingBootStrapper.getInstance().shutdown_node();
			BatchProcessingBootStrapper.getInstance().getDappExecutor().shutdown();
			ESConnection.getInstance().getClient().close();
			OamClientManager.getInstance().disconnect();
			bootStrapper.getJettyRestEngine().stopJettyServer();
			System.out.println("Mbean stopped successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void stopMbeans() {

		bootStrapper.getConfigEngine().stopMbean();
		System.out.println("Mbean Stopped..");
	}

}
