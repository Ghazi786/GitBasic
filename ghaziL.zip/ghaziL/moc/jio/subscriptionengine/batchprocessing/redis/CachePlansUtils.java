package com.jio.subscriptionengine.batchprocessing.redis;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.jio.subscriptionengine.batchprocessing.modules.plan.helper.PlanConstant;

public class CachePlansUtils {
	
	
	private CopyOnWriteArrayList<String> allPlans;
	private long documentsCount;
	private static CachePlansUtils instance;

	private CachePlansUtils() {
	}
	
	public static CachePlansUtils getInstance() {
		if (instance == null) {
			instance = new CachePlansUtils();
		}
		return instance;
	}
	
	public List<String> getAllPlans() {
		if(allPlans == null) {
			setAllPlans();
		}
		return allPlans;
	}

	public void setAllPlans() {
		final RedisOperationImpl redisOperationImpl = new RedisOperationImpl();

		try {
			documentsCount = redisOperationImpl.llen(PlanConstant.REDIS_ALL_PLAN_LIST_KEY);
			final List<String> fromListAsString = redisOperationImpl.getFromListAsString(PlanConstant.REDIS_ALL_PLAN_LIST_KEY, 0, -1);
			this.allPlans = new CopyOnWriteArrayList<>(fromListAsString);
			
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	public long getDocumentsCount() {
		return documentsCount;
	}

}
