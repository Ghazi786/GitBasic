package com.jio.subscriptionengine.batchprocessing.redis;

import java.util.Map;
import java.util.concurrent.ExecutionException;

public interface IRedisCRUDOperation {

	String get(String key);

	boolean delete(String key);

	String set(String key, Object value);

	String getFromMap(String key, String field);

	boolean setMapKeyField(String key, String field, String value) throws InterruptedException, ExecutionException;

	void decCr(String field, long value);

	void incCr(String field, long value);

	Map<String, String> hGetAll(String key);

	boolean setMapofObjects(String key, Map<String, String> value);
}
