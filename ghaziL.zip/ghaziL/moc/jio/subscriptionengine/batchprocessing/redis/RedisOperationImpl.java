package com.jio.subscriptionengine.batchprocessing.redis;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.eclipse.jetty.http.HttpStatus;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;

import io.lettuce.core.api.sync.RedisCommands;
import io.lettuce.core.cluster.api.sync.RedisAdvancedClusterCommands;

/**
 * This class is used to perform CRUD actions in Redis
 * @author Samrudhi.Gandhe
 *
 */
public class RedisOperationImpl implements IRedisCRUDOperation {

	private static ObjectMapper objectMapper = ObjectMapperHelper.getInstance().getEntityObjectMapper();
	
	/** 
	 * Convert object of required type to string
	 */
	private String getStringValue(final Object value) {
		try {
			return objectMapper.writeValueAsString(value);
		} catch (final JsonProcessingException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return null;
	}
	/** 
	 * Return object of required type from string
	 */
	private <T> T getObjectByClazz(final Class<T> clazz, final Object obj){
		try {
			return  objectMapper.readValue(obj.toString(), clazz);
		} catch (final IOException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return null;
	}

	/** 
	 * Return Collection objects of required type from string
	 */
	private <T> T getObjectByTypeReference(final TypeReference<T> typeReference, final Object obj){
		try {
			return  objectMapper.readValue(obj.toString(), typeReference);
		} catch (final IOException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return null;
	}
	
	
	/** 
	 * Return object as Value of required type from redis by key and clazz type
	 */
	public <T> T get(final String key, final Class<T> clazz) {
        
		final Object obj = getRedisAdvancedClusterCommand().get(key);
		if (obj == null) {
			return null;
		}
		return getObjectByClazz(clazz, obj);
	}
	
	/** 
	 * Get Object/Collection as Value of required type from redis by key and TypeReference 
	 * @param key
	 * @return typeReference
	 */
	public <T> T get(final String key, final TypeReference<T> typeReference) {
		
		final String obj = (String) getRedisAdvancedClusterCommand().get(key);
		if (obj == null) {
			return null;
		}
		return getObjectByTypeReference(typeReference, obj);
	}
	
	/** 
	 * Get String Value from redis by key 
	 * @param key
	 * @return String
	 */
	@Override
	public String get(final String key) {
		final String response = null;
		final String obj = (String) getRedisAdvancedClusterCommand().get(key);
		if (obj == null) {
			return response;
		}
		return obj;
		
	}

	/** 
	 * Delete Key-Value from redis by key 
	 * @param key
	 * @return boolean
	 */
	@Override
	public boolean delete(final String key) {
		return getRedisAdvancedClusterCommand().del(key) != 0 ;
	}
	/**
	 * Set Key-Value in redis by key with default expiry time of 1hr 
	 * @param key
	 * @param value
	 * @return
	 */
	
	public String set(final String key, final Object value) {
		return getRedisAdvancedClusterCommand().set(key, getStringValue(value));
	}
	
	public Boolean expire(final String key, final long time) {
		return getRedisAdvancedClusterCommand().expire(key, time);
	}
	
	public Boolean expireAt(final String key, final Date time) {
		return getRedisAdvancedClusterCommand().expireat(key, time);
	}
	public Long llen(final String key) {
		return getRedisAdvancedClusterCommand().llen(key);
	}
	
	public long addTolist(final String key, final Object value) {
		return getRedisAdvancedClusterCommand().rpush(key, getStringValue(value));
	}

	public <T> List<T> getFromList(final String key, Class<T> class1, long first, long last) {
		List<String> list = null;
		try {
			list = getRedisAdvancedClusterCommand().lrange(key, first, last);
		} catch (Exception e) {
		}
		return  list.stream().map(str ->  getObjectByClazz(class1, str)).collect(Collectors.toList());

	}
	
	@SuppressWarnings("unchecked")
	public String setClient(final String key, final Object value) {
		 RedisCommands<String, Object> rediscommand =  RedisConnectionService.getInstance().getConnection().sync();
		return rediscommand.set(key, getStringValue(value));
	}
	@SuppressWarnings("unchecked")
	public <T> T getClient(final String key, final TypeReference<T> typeReference) {
		
		RedisCommands<String, Object> redisCommands = (RedisCommands<String, Object>) RedisConnectionService.getInstance().getConnection().sync();
		
		final String obj = (String) redisCommands.get(key);
		if (obj == null) {
			return null;
		}
		return getObjectByTypeReference(typeReference, obj);
	}
	
	@SuppressWarnings("unchecked")
	public String getClient(final String key) {
		final String response = null;
		
		RedisCommands<String, Object> redisCommands = (RedisCommands<String, Object>) RedisConnectionService.getInstance().getConnection().sync();
		
		final String obj = (String) redisCommands.get(key);
		if (obj == null) {
			return response;
		}
		return obj;
		
	}
	/**
	 * Set Key-Value in redis by key with specific time in seconds 
	 * @param key
	 * @param value
	 * @param timeInSeconds
	 * @return
	 */
	public String setObjectWithExpiry(final String key, final Object value, final long timeInSeconds) {
		return getRedisAdvancedClusterCommand().setex(key, timeInSeconds,  getStringValue(value));
	}
	
	/**
	 * Set map object in redis by key
	 * @param key
	 * @param value
	 * @return
	 */
	@Override
	public boolean setMapofObjects(final String key, final Map<String, String> value) {
		return "OK".equals(getRedisAdvancedClusterCommand().hmset(key, value));
	}
	
	/**
	 * Get map object in redis by key
	 * @param key
	 * @return
	 */
	@Override
	public Map<String, String> hGetAll(final String key) {
		return getRedisAdvancedClusterCommand().hgetall(key);

	}

	/**
	 * Get value from Map by redis-key and key of map field
	 * @param key
	 * @return
	 */
	@Override
	public String getFromMap(final String key, final String field) {
		return (String) getRedisAdvancedClusterCommand().hget(key, field);

	}
	
	/**
	 * Add key-value pair object in Map stored in redis
	 * @param key
	 * @param field
	 * @param value
	 * @return
	 */
	@Override
	public boolean setMapKeyField(final String key, final String field, final String value) {
		return getRedisAdvancedClusterCommand().hset(key, field, value);
	}

	@Override
	public void decCr(final String field, final long value) {
		getRedisAdvancedClusterCommand().decrby(field, value);
	}

	@Override
	public void incCr(final String field, final long value) {
		getRedisAdvancedClusterCommand().incrby(field, value);
	}
	
	private RedisAdvancedClusterCommands getRedisAdvancedClusterCommand() {
		return RedisConnectionService.getInstance().getSyncConnection();
	}
	public List<String> hkeys(String redisRatingsKey) {
		return getRedisAdvancedClusterCommand().hkeys(redisRatingsKey);
	}

	public List<String> getFromListAsString(final String key, long first, long last) {
		List<String> list = null;
		try {
			list = getRedisAdvancedClusterCommand().lrange(key, first, last);
		} finally {
			if(list == null) {
				BaseException e = new BaseException(HttpStatus.NOT_FOUND_404, "No redis List Found");
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage())
				.writeExceptionLog();
			}
		}
		return  list;
		
	}
	
}
