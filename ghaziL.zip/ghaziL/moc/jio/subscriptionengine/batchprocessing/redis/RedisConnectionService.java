package com.jio.subscriptionengine.batchprocessing.redis;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.math.NumberUtils;

import com.jio.subscriptionengine.batchprocessing.configurationManager.ConfigParamsEnum;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;

import io.lettuce.core.ReadFrom;
import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.SocketOptions;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.cluster.ClusterClientOptions;
import io.lettuce.core.cluster.ClusterTopologyRefreshOptions;
import io.lettuce.core.cluster.RedisClusterClient;
import io.lettuce.core.cluster.api.StatefulRedisClusterConnection;
import io.lettuce.core.cluster.api.async.RedisAdvancedClusterAsyncCommands;
import io.lettuce.core.cluster.api.sync.RedisAdvancedClusterCommands;

/**
 * This class is used to instantiate the Redis connection
 * @author Samrudhi.Gandhe
 *
 */
public class RedisConnectionService {
	private static StatefulRedisClusterConnection redisClusterConnection;
	private static RedisConnectionService redis;
	static RedisClusterClient redisClusterClient;
	private static RedisClient redisClient;
	private static StatefulRedisConnection connection;
	private static RedisAdvancedClusterAsyncCommands asyncConnection;
	private static RedisAdvancedClusterCommands syncConnection;
	private RedisConnectionService() {

	}

	public static RedisConnectionService getInstance() {
		if (redis == null) {
			redis = new RedisConnectionService();
		}
		return redis;
	}

	public static void initialize() {
		try {

			DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Initialize Redis Cluster Connection",
					Thread.currentThread().getStackTrace()[1].getClassName(),
					Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
			
			final String multiRedisIPPorts = ConfigParamsEnum.REDIS_CLUSTER_IP_PORTS.getStringValue();
			final String[] redisIps = multiRedisIPPorts.split(",");
			final List<RedisURI> redisURIs = new ArrayList<>();
			for (int i = 0; i < redisIps.length; i++) {
				final String[] redisIpPort = redisIps[i].split(":");
				final int redisPort = NumberUtils.toInt(redisIpPort[1]);
				redisURIs.add(RedisURI.Builder.redis(redisIpPort[0].trim()).withPort(redisPort).build());
			}
			redisClusterClient = RedisClusterClient.create(redisURIs);
			
			ClusterTopologyRefreshOptions topologyRefreshOptions = ClusterTopologyRefreshOptions.builder()
					.enablePeriodicRefresh(Duration.ofMillis(150))
					.enableAllAdaptiveRefreshTriggers().build();

			redisClusterClient
					.setOptions(ClusterClientOptions.builder().topologyRefreshOptions(topologyRefreshOptions)
							.socketOptions(SocketOptions.builder()
									.connectTimeout(Duration.ofMillis(150))
									.tcpNoDelay(true).build())
							.build());
			
			redisClusterConnection = redisClusterClient.connect();
			redisClusterConnection.setReadFrom(ReadFrom.ANY);
			asyncConnection = redisClusterConnection.async();
			syncConnection = redisClusterConnection.sync();
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					Thread.currentThread().getStackTrace()[1].getClassName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
	}

	public static  void initializeClient(final String ip, final int port) {
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Initialize Redis Client Connection",
				Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		final RedisURI redisURI = new RedisURI(ip, port, Duration.ofSeconds(180));
		
		 redisClient = RedisClient.create(redisURI);
		 connection = redisClient.connect();
	}

	public RedisClusterClient getRedisClusterClient() {
		return redisClusterClient;
	}

	public StatefulRedisClusterConnection getRedisClusterConnection() {
		return redisClusterConnection;
	}
	
	public void close(){
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		closeCluster();
		
		closeClient();
	}

	private void closeClient() {
		if(getConnection() != null) {
			getConnection().close();
			redisClient.shutdown();
		}
	}

	private void closeCluster() {
		if(redisClusterConnection != null) {
			redisClusterConnection.close();
			redisClusterClient.shutdown();
		}
	}

	public StatefulRedisConnection getConnection() {
		return connection;
	}
	public RedisAdvancedClusterAsyncCommands getAsyncConnection() {
		return asyncConnection;
	}
	public RedisAdvancedClusterCommands getSyncConnection() {
		return syncConnection;
	}

	
}
