package com.jio.subscriptionengine.batchprocessing.alarmManager;

/**
 * 
 * @author Milindkumar.S
 *
 */
public class AlarmNameIntf {

	public static final String DEVOPS_STARTUP_SUCCESS = "DEVOPS_STARTUP_SUCCESS";
	
	//---------------------Database related Alarms--------------------//
	public static final String CMN_DATABASE_CONNECTION_SUCCESS ="ES Database connection successful";
	public static final String CMN_ES_CONNECTION_FAILURE ="ES Database connection failure";
	//---------------------FTP related Alarms--------------------//
	public static final String CMN_LOG_FTP_FAILURE ="FTP of log files failed";
	public static final String CMN_LOG_FTP_SUCCESS ="FTP of log files Success";
	//---------------------OAM COnnection Alarms--------------------//
	public static final String CMN_OAM_CONNECTION_SUCCESS ="OAM Connectivity Success";
	public static final String CMN_OAM_CONNECTION_FAILURE ="OAM Connectivity failure";
	//---------------------Directory structure Alarms--------------------//
	public static final String CMN_FCAPS_DIRECTORY_ERROR ="FCAPS Directory structure failure";
	////---------------------CSV related Alarms--------------------//
	public static final String CMN_CSV_PARSING_ERROR ="ERROR during CVS file  validation and processing";
	public static final String CMN_WRITE_ERROR_IN_DB ="insertion failure in elastic";

	public static final String CMN_ES_EVENT_INDEX_CREATION_FAILED = null;

	public static final String CMN_EVENT_MAPPING_CREATION_FAIL = "error during creating mapping in es";

	private AlarmNameIntf(){
		
	}

}
