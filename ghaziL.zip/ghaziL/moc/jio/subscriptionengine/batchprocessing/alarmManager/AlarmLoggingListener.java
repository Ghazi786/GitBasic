package com.jio.subscriptionengine.batchprocessing.alarmManager;


import com.rjil.management.alarm.AlarmLoggingCallbackHandler;
//import com.rancore.management.alarm.AlarmLoggingCallbackHandler;

/**
 * 
 * @author Milindkumar.S
 *
 */

public class AlarmLoggingListener implements AlarmLoggingCallbackHandler {

	@Override
	public void debug(String arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

//	@Override
//	public void DEBUG(String arg0, String arg1) {
//		if (DappLogManager.getInstance().getLogger().isDebugEnabled())
//			DappLogManager.getInstance().getLogger().debug((arg1 != null) ? arg1 + " > " + arg0 : arg0);
//	}
//
//	@Override
//	public void ERROR(String arg0, String arg1) {
//		DappLogManager.getInstance().getLogger().error((arg1 != null) ? arg1 + " > " + arg0 : arg0);
//	}
//
//	@Override
//	public void FATAL(String arg0, String arg1) {
//		DappLogManager.getInstance().getLogger().fatal((arg1 != null) ? arg1 + " > " + arg0 : arg0);
//	}
//
//	@Override
//	public void INFO(String arg0, String arg1) {
//		if (DappLogManager.getInstance().getLogger().isInfoEnabled()) {
//			DappLogManager.getInstance().getLogger().info((arg1 != null) ? arg1 + " > " + arg0 : arg0);
//		}
//	}
//
//	@Override
//	public void TRACE(String arg0, String arg1) {
//		DappLogManager.getInstance().getLogger().trace((arg1 != null) ? arg1 + " > " + arg0 : arg0);
//	}
//
//	@Override
//	public void WARN(String arg0, String arg1) {
//		DappLogManager.getInstance().getLogger().warn((arg1 != null) ? arg1 + " > " + arg0 : arg0);
//	}

}
