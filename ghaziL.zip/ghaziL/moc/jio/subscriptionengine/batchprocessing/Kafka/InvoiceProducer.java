package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;

public class InvoiceProducer {

	private static Producer<String, Object> producer = KafkaProducerUtil.createProducer();

	private static InvoiceProducer invoiceProducer = new InvoiceProducer();;

	private InvoiceProducer() {

	}

	public static InvoiceProducer getInstance() {

		return invoiceProducer;
	}

	public void createProducer(List<SubscriberSubscription> subscriptionDetails) {
		Runnable task = () -> {
			try {
				for (SubscriberSubscription subscription : subscriptionDetails) {
					// produce to produce details on the mentioned topic
					ProducerRecord<String, Object> record = new ProducerRecord<String, Object>("generate-invoice-topic",
							subscription.getId(), subscription);
					producer.send(record, (metadata, exception) -> {

						if (metadata == null) {
							exception.printStackTrace();
						}
					});
				}
			} catch (Exception e) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
				e.printStackTrace();
			}
		};
	//	executor.submit(task);
	}

}
