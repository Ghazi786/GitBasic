package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

public class KafkaConsumerUtil {
	
	public static Consumer<String, String> createConsumer(String topicName) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, KafkaConfigEnum.KAFKA_BROKERS.getStringValue());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, KafkaConfigEnum.GROUP_ID_CONFIG.getStringValue());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, KafkaConfigEnum.MAX_POLL_RECORDS.getStringValue());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, KafkaConfigEnum.ENABLE_AUTO_COMMIT_CONFIG.getBooleanValue());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, KafkaConfigEnum.OFFSET_RESET_EARLIER.getStringValue());
        
        props.put(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG, 1048576);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 10000);
        props.put(ConsumerConfig.FETCH_MIN_BYTES_CONFIG, 100000);
        props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, 300000);

        Consumer<String, String> consumer = new KafkaConsumer<>(props);
        if(topicName!=null)
        {
        	consumer.subscribe(Collections.singletonList(topicName));
        }
        
        else
        {
        	consumer.subscribe(Collections.singletonList(null));
        }
        
        
        return consumer;
    }


}
