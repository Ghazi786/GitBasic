package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailHandler;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;

public class EmailConsumerTask implements Runnable {
	private List<List<Object>> subscriptionInvoices;

	final InvoiceService invoiceService = new InvoiceService();

	public List<List<Object>> getSubscriptionInvoices() {
		return subscriptionInvoices;
	}

	public void setSubscriptionInvoices(List<List<Object>> subscriptionInvoices) {
		this.subscriptionInvoices = subscriptionInvoices;
	}

	@Override
	public void run() {

		for (List<Object> subscriptionInvoiceDetails : subscriptionInvoices) {

			try {

				SubscriberSubscription subscriptionDetails = ObjectMapperHelper.getInstance()
						.getBeanFromObject(subscriptionInvoiceDetails.get(0), SubscriberSubscription.class);

				List<Invoice> invoices = new ArrayList<>();

				if (subscriptionInvoiceDetails.size() > 1) {

					invoices = ObjectMapperHelper.getInstance().getEntityObjectMapper()
							.convertValue(subscriptionInvoiceDetails.get(1), new TypeReference<List<Invoice>>() {
							});
				}

				final List<File> invoiceFiles = new ArrayList<File>();
				for (Invoice tempInvoice : invoices) {

					final File tempInvoiceFile = invoiceService.createInvoiceFile(tempInvoice,
							subscriptionDetails.getPlan());
					invoiceFiles.add(tempInvoiceFile);
				}
				EmailHandler.triggerEmailWithListOfAttachments(subscriptionDetails,
						EmailTemplateConstants.NEW_SUBSCRIPTION_LABEL, subscriptionDetails.getSiteId(),
						subscriptionDetails.getPlan().getEmailSettingAttributes().isNewSubscriptionNotification(),
						invoiceFiles);
			} catch (final Exception e) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
				e.printStackTrace();
			}
		}
		subscriptionInvoices=null;

	}

}
