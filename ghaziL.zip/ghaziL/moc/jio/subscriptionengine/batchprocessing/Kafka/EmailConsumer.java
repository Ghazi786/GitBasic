package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;

import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;
import com.jio.telco.framework.pool.PoolingManager;

public class EmailConsumer {

	private static EmailConsumer emailConsumer = new EmailConsumer();

	private EmailConsumer() {

	}

	public static EmailConsumer getInstance() {

		return emailConsumer;
	}

	public void emailConsumer() {

		Consumer<String, String> consumer = KafkaConsumerUtil.createConsumer("email-topic");

		while (true) {

			
			ConsumerRecords<String, String> consumerRecords = consumer
					.poll(Duration.ofMillis(KafkaConfigEnum.POLL_TIME.getLongValue()));
			// is the time in milliseconds consumer will wait if no record is found at
			// broker.

			if (consumerRecords.count() > 0) {

				System.out.println("EmailConsumer Count : " + consumerRecords.count());
				List<List<Object>> subscriptionInvoices = new ArrayList<>();

				// print each record.
				consumerRecords.forEach(record -> {

					try {
						subscriptionInvoices.add(
								ObjectMapperHelper.getInstance().getBeanFromString(record.value(), ArrayList.class));
					} catch (IOException e) {
						e.printStackTrace();
					}

				});

				try {
					EmailConsumerTask emailConsumerTask = (EmailConsumerTask) PoolingManager.getPoolingManager()
							.borrowObject(EmailConsumerTask.class);
					emailConsumerTask.setSubscriptionInvoices(subscriptionInvoices);
					BatchProcessingBootStrapper.getInstance().getDappExecutor().execute(emailConsumerTask);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// commits the offset of record to broker.
				consumer.commitAsync();
			}

		}

	}

}
