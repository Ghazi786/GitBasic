package com.jio.subscriptionengine.batchprocessing.Kafka;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

public class SubscriptionConsumerTaskFactory implements PooledObjectFactory<SubscriptionConsumerTask> {

	private static final String OBJECT_NAME = "SubscriptionConsumerTask";
	private static final String CLASS_NAME = SubscriptionConsumerTaskFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<SubscriptionConsumerTask> arg0) throws Exception {
	}

	@Override
	public void destroyObject(PooledObject<SubscriptionConsumerTask> arg0) throws Exception {
	}

	@Override
	public PooledObject<SubscriptionConsumerTask> makeObject() throws Exception {
		return new DefaultPooledObject<>(new SubscriptionConsumerTask());
	}

	@Override
	public void passivateObject(PooledObject<SubscriptionConsumerTask> arg0) throws Exception {
	}

	@Override
	public boolean validateObject(PooledObject<SubscriptionConsumerTask> arg0) {
		return false;
	}
}
