package com.jio.subscriptionengine.batchprocessing.Kafka;

public class ConsumerUtils {

	private static ConsumerUtils instance;

	private ConsumerUtils() {
	}

	public static ConsumerUtils getInstance() {
		if (instance == null) {
			instance = new ConsumerUtils();
		}
		return instance;
	}

	public void startConsumer() {

		Runnable subscription = () -> {

			try {
				SubscriptionConsumer.getInstance().createSubscriptionConsumer();
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		};

		Thread subscriptionTread = new Thread(subscription);
		subscriptionTread.start();

/*		Runnable invoice = () -> {

			try {
				InvoiceConsumer.getInstance().invoiceConsumer();
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		};

		Thread invoiceTread = new Thread(invoice);
		invoiceTread.start();
*/
		Runnable email = () -> {

			try {
				EmailConsumer.getInstance().emailConsumer();
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		};

		Thread emailTread = new Thread(email);
		emailTread.start();
/*
		Runnable webhook = () -> {

			try {
				WebHookConsumer.getInstance().webhookConsumer();
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		};

		Thread webhookTread = new Thread(webhook);
		webhookTread.start();*/

	}

}
