package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.util.ArrayList;
import java.util.List;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.blockchain.sdk.util.UniqueUUIDGenerator;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberActivity;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.repository.InvoiceRepository;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.repository.SubscribeRepository;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.subscriptiontermination.helper.SubscriptionTerminationDeatilsService;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.telco.framework.clearcode.GenericWorkerThreadInterface;
import com.jio.telco.framework.pool.PoolingManager;

public class SubscriptionConsumerTask implements Runnable, GenericWorkerThreadInterface {

	private List<SubscriberSubscription> subscriptionsList;

	public List<SubscriberSubscription> getSubscriptionsList() {
		return subscriptionsList;
	}

	public void setSubscriptionsList(List<SubscriberSubscription> subscriptionsList) {
		this.subscriptionsList = subscriptionsList;
	}

	private final static InvoiceService invoiceService = new InvoiceService();
	private final static SubscribeRepository subscribeRepository = new SubscribeRepository();

	@Override
	public void run() {

		try {

			final SessionFactory factory = SessionFactory.getSessionFactory();

			final Session session = factory.getSession();

			// invoice producer for producing the invoice details on the mentioned topic
			List<Invoice> invoices = invoiceExecution(subscriptionsList);

			// webhook for logging activity for the plan subscribed by the subscriber
			List<SubscriberActivity> subscriberActivityList = webhookExecution(subscriptionsList);

			// ############### INSERT FLOW #################
			// For bulk insert into db
			subscribeRepository.saveBulkSubscription(session, subscriptionsList);

			// for buld insert
			if (!invoices.isEmpty()) {
				InvoiceRepository.getInstance().bulkAddInvoice(session, invoices);
			}

			// for buld insert
			if (!subscriberActivityList.isEmpty()) {
				session.bulk(subscriberActivityList, false);
			}

//			 TODO: Request to PSC handler
//			SubscriptionTerminationDeatilsService.getInstance().createSubscriptionDetails(subscriptionsList);

			// TODO make it as null
			subscriptionsList = null;
			invoices = null;
			subscriberActivityList = null;
			session.close();

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			e.printStackTrace();
		}

	}

	private List<Invoice> invoiceExecution(List<SubscriberSubscription> subscriptionsList) {

		List<Invoice> invoices = new ArrayList<Invoice>();

		List<List<Object>> subscriptionInvoices = new ArrayList<>();

		List<Object> subscriptionInvoiceList = new ArrayList<>();

		// print each record.
		List<Invoice> tempInvoices = new ArrayList<Invoice>();

		for (SubscriberSubscription subscriptionDetails : subscriptionsList) {

			subscriptionInvoiceList.clear();
			tempInvoices.clear();
			final Invoice setupFeeInvoice = invoiceService.createSetupFeeInvoice(subscriptionDetails);
			if (setupFeeInvoice != null && setupFeeInvoice.getId() != null) {
				tempInvoices.add(setupFeeInvoice);
			}

			if (!(subscriptionDetails.getPlan().getTrialInterval() != null
					&& subscriptionDetails.getPlan().getTrialInterval().getValue() > 0)) {
				final Invoice planInvoice = invoiceService.createPlanInvoice(subscriptionDetails);
				if (planInvoice != null) {
					tempInvoices.add(planInvoice);
				}
			}

			// for email process - producer data ; start
			subscriptionInvoiceList.add(subscriptionDetails);
			if (!tempInvoices.isEmpty()) {
				subscriptionInvoiceList.add(tempInvoices);
			}

			if (!subscriptionInvoiceList.isEmpty()) {
				subscriptionInvoices.add(subscriptionInvoiceList);
			}

			// end

			if (!tempInvoices.isEmpty()) {
				invoices.addAll(tempInvoices);
			}

		}

		// for sending email to the user i.e plan is subscribed successfully
//		 EmailProducer.getInstance().createProducer(subscriptionInvoices);
		subscriptionInvoiceList = null;
		tempInvoices = null;

		return invoices;

	}

	private List<SubscriberActivity> webhookExecution(List<SubscriberSubscription> subscriptionsList) {

		List<SubscriberActivity> subscriberActivitys = new ArrayList<>();
		for (SubscriberSubscription subscriptionDetails : subscriptionsList) {

			Subscriber subscriberById = subscriptionDetails.getSubscriber();
			String name = subscriberById != null ? subscriberById.getFirstName() + " " + subscriberById.getLastName()
					: Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME;
			String siteId = subscriptionDetails.getPlan().getSiteId();

			SubscriberActivity subscriberActivity = new SubscriberActivity();
			subscriberActivity.setId(UniqueUUIDGenerator.getInstance().getUniqueUUID());
			subscriberActivity.setSiteId(siteId);
			subscriberActivity.setName(name + " " + Constants.DEFAULT_LOG_PLATFORM);
			subscriberActivity.setDescription("Created Subscription" + subscriptionDetails.getPlan().getName());
			subscriberActivity.setSubscriberId(subscriptionDetails.getSubscriberId());
			subscriberActivitys.add(subscriberActivity);

			// Subscription Webhook Activity
//			addSubscriptionWebhookActivity(subscriptionDetails);
		}
		return subscriberActivitys;
	}

	public void addSubscriptionWebhookActivity(final SubscriberSubscription subscriptionDetails) {

		try {

			SubscriptionActivityTask subscriptionActivityTask = (SubscriptionActivityTask) PoolingManager
					.getPoolingManager().borrowObject(SubscriptionActivityTask.class);
			subscriptionActivityTask.setSubscriptionDetails(subscriptionDetails);

			BatchProcessingBootStrapper.getInstance().getDappExecutor().execute(subscriptionActivityTask);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub
		subscriptionsList = null;
	}

}
