package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;

import com.jio.subscriptionengine.batchprocessing.countermanager.StringNameEnum;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;
import com.jio.telco.framework.pool.PoolingManager;

public class SubscriptionConsumer {

	private final static SubscriptionConsumer subscriptionConsumer = new SubscriptionConsumer();

	private SubscriptionConsumer() {
	}

	public static SubscriptionConsumer getInstance() {

		return subscriptionConsumer;
	}

	public void createSubscriptionConsumer() {

		Consumer<String, String> consumer = KafkaConsumerUtil.createConsumer("subscription-details-topic");

		while (true) {

			if(BatchProcessingBootStrapper.getInstance().getDappExecutor().getQueue().size()>5)
			continue;
			
			StringNameEnum.OBJECT_POOL_STATISTICS.setValue(PoolingManager.getPoolingManager().getPoolStatistics());
			StringNameEnum.THREAD_POOL_INFO
					.setValue(BatchProcessingBootStrapper.getInstance().getDappExecutor().getThreadPoolInfo());

			if (BatchProcessingBootStrapper.getInstance().getDappExecutor().getQueue().size() > 5)
				continue;
			ConsumerRecords<String, String> consumerRecords = consumer
					.poll(Duration.ofMillis(KafkaConfigEnum.POLL_TIME.getLongValue()));
			// is the time in milliseconds consumer will wait if no record is found at
			// broker.

			if (consumerRecords.count() > 0) {
				
				// commits the offset of record to broker.
				consumer.commitSync();
//				System.out.println("SubscriptionConsumer Count : " + consumerRecords.count());

				List<SubscriberSubscription> subscriptionsList = new ArrayList<>();
				// print each record.
				consumerRecords.forEach(record -> {

					try {
						SubscriberSubscription subscription = ObjectMapperHelper.getInstance()
								.getBeanFromString(record.value(), SubscriberSubscription.class);
						subscriptionsList.add(subscription);
						System.out.println("ID : " + subscription.getId());
					} catch (Exception e) {
						DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
								this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
								.writeExceptionLog();
						e.printStackTrace();
					}

				});

				try {
					SubscriptionConsumerTask subscriptionConsumerTask = (SubscriptionConsumerTask) PoolingManager
							.getPoolingManager().borrowObject(SubscriptionConsumerTask.class);
					subscriptionConsumerTask.setSubscriptionsList(null);
					subscriptionConsumerTask.setSubscriptionsList(subscriptionsList);
					BatchProcessingBootStrapper.getInstance().getDappExecutor().execute(subscriptionConsumerTask);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				

			}
		}

	}

}
