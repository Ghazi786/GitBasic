package com.jio.subscriptionengine.batchprocessing.Kafka;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

public class EmailConsumerTaskFactory implements PooledObjectFactory<EmailConsumerTask> {

	private static final String OBJECT_NAME = "EmailConsumerTask";
	private static final String CLASS_NAME = EmailConsumerTaskFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<EmailConsumerTask> arg0) throws Exception {
	}

	@Override
	public void destroyObject(PooledObject<EmailConsumerTask> arg0) throws Exception {
	}

	@Override
	public PooledObject<EmailConsumerTask> makeObject() throws Exception {
		return new DefaultPooledObject<>(new EmailConsumerTask());
	}

	@Override
	public void passivateObject(PooledObject<EmailConsumerTask> arg0) throws Exception {
	}

	@Override
	public boolean validateObject(PooledObject<EmailConsumerTask> arg0) {
		return false;
	}
}
