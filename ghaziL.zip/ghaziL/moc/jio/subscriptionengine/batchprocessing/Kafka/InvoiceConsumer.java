package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.elasticsearch.cluster.metadata.AliasAction.Add;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.repository.InvoiceRepository;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;

public class InvoiceConsumer {

	private static InvoiceConsumer invoiceConsumer = new InvoiceConsumer();

	final InvoiceService invoiceService = new InvoiceService();

	final SessionFactory factory = SessionFactory.getSessionFactory();
	final Session session = factory.getSession();

	private InvoiceConsumer() {
		
	}

	public static InvoiceConsumer getInstance() {

		return invoiceConsumer;
	}

	public void invoiceConsumer() {

		Consumer<String, String> consumer = KafkaConsumerUtil.createConsumer("generate-invoice-topic");

		while (true) {
/*
			if (executor.getPoolSize() > executor.getCorePoolSize() * 2)
				continue;
*/
			ConsumerRecords<String, String> consumerRecords = consumer
					.poll(Duration.ofMillis(KafkaConfigEnum.POLL_TIME.getLongValue()));
			// is the time in milliseconds consumer will wait if no record is found at
			// broker.

			if (consumerRecords.count() > 0) {

				System.out.println("InvoiceConsumer Count : " + consumerRecords.count());

				List<SubscriberSubscription> subscriptionsList = new ArrayList<>();

				consumerRecords.forEach(record -> {
					try {
						SubscriberSubscription subscription = ObjectMapperHelper.getInstance()
								.getBeanFromString(record.value(), SubscriberSubscription.class);
						subscriptionsList.add(subscription);
					} catch (Exception e) {
						DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
								this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
								.writeExceptionLog();
						e.printStackTrace();
					}
				});

				/// in thread pool execution
				asyncExecution(subscriptionsList);

				// commits the offset of record to broker.
				consumer.commitAsync();
			}

		}

	}

	private void asyncExecution(List<SubscriberSubscription> subscriptionsList) {
		Runnable task = () -> {

			final List<Invoice> invoices = new ArrayList<Invoice>();

			final List<List<Object>> subscriptionInvoices = new ArrayList<>();

			for (SubscriberSubscription subscriptionDetails : subscriptionsList) {

				List<Object> subscriptionInvoiceList = new ArrayList<>();

				// print each record.
				final List<Invoice> tempInvoices = new ArrayList<Invoice>();

				final Invoice setupFeeInvoice = invoiceService.createSetupFeeInvoice(subscriptionDetails);
				if (setupFeeInvoice != null && setupFeeInvoice.getId() != null) {
					tempInvoices.add(setupFeeInvoice);
				}

				if (!(subscriptionDetails.getPlan().getTrialInterval() != null
						&& subscriptionDetails.getPlan().getTrialInterval().getValue() > 0)) {
					final Invoice planInvoice = invoiceService.createPlanInvoice(subscriptionDetails);
					if (planInvoice != null) {
						tempInvoices.add(planInvoice);
					}
				}

				// for email process - producer data ; start
				subscriptionInvoiceList.add(subscriptionDetails);
				if (!tempInvoices.isEmpty()) {
					subscriptionInvoiceList.add(tempInvoices);
				}

				if (!subscriptionInvoiceList.isEmpty()) {
					subscriptionInvoices.add(subscriptionInvoiceList);
				}

				// end

				if (!tempInvoices.isEmpty()) {
					invoices.addAll(tempInvoices);
				}

			}

			// bulk insert
			// for sending email to the user i.e plan is subscribed successfully
			EmailProducer.getInstance().createProducer(subscriptionInvoices);

			if (!invoices.isEmpty()) {
				InvoiceRepository.getInstance().bulkAddInvoice(session, invoices);
			}
		};

	//	executor.submit(task);
	}

}
