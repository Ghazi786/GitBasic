package com.jio.subscriptionengine.batchprocessing.Kafka;

import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;

public class SubscriptionActivityTask implements Runnable {
	private SubscriberSubscription subscriptionDetails;

	public SubscriberSubscription getSubscriptionDetails() {
		return subscriptionDetails;
	}

	public void setSubscriptionDetails(SubscriberSubscription subscriptionDetails) {
		this.subscriptionDetails = subscriptionDetails;
	}

	public SubscriptionActivityTask() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		final Subscriber subscriberById = subscriptionDetails.getSubscriber();

		final String name = subscriberById != null ? subscriberById.getFirstName() + " " + subscriberById.getLastName()
				: Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME;

		final String siteId = subscriptionDetails.getPlan().getSiteId();

		ServiceCommunicator.triggerWebHook(null,siteId, subscriptionDetails, name,
				SubscriptionConstants.EVENT_CREATE_SUBSCRIPTION);
	}

}
