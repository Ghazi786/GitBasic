package com.jio.subscriptionengine.batchprocessing.Kafka;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;

public class SubscriptionActivityTaskFactory implements PooledObjectFactory<SubscriptionActivityTask> {

	private static final String OBJECT_NAME = "SubscriptionActivityTask";
	private static final String CLASS_NAME = SubscriptionActivityTaskFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<SubscriptionActivityTask> arg0) throws Exception {
	}

	@Override
	public void destroyObject(PooledObject<SubscriptionActivityTask> arg0) throws Exception {
	}

	@Override
	public PooledObject<SubscriptionActivityTask> makeObject() throws Exception {
		return new DefaultPooledObject<>(new SubscriptionActivityTask());
	}

	@Override
	public void passivateObject(PooledObject<SubscriptionActivityTask> arg0) throws Exception {
	}

	@Override
	public boolean validateObject(PooledObject<SubscriptionActivityTask> arg0) {
		return false;
	}
}
