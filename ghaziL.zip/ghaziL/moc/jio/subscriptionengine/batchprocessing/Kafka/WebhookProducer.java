package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;

public class WebhookProducer {

	private static Producer<String, Object> producer = KafkaProducerUtil.createProducer();

	private static WebhookProducer webhookProducer = new WebhookProducer();

	private WebhookProducer() {
	}

	public static WebhookProducer getInstance() {

		return webhookProducer;
	}

	public void createProducer(List<SubscriberSubscription> subscriptionDetails) {
		Runnable task = () -> {
			try {
				for (SubscriberSubscription subscription : subscriptionDetails) {
					ProducerRecord<String, Object> record = new ProducerRecord<String, Object>(
							"subscriber-webhook-topic", subscription.getId(), subscription);
					producer.send(record, (metadata, exception) -> {

						if (metadata == null) {
							exception.printStackTrace();
						}
					});
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
		//executor.submit(task);
	}

}
