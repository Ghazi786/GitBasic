package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.blockchain.sdk.util.UniqueUUIDGenerator;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberActivity;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.repository.InvoiceRepository;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.service.SubscribeService;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;

public class WebHookConsumer {

	private static WebHookConsumer webHookConsumer = new WebHookConsumer();

	private static ThreadPoolExecutor executor;

	private WebHookConsumer() {
	}

	public static WebHookConsumer getInstance() {

		return webHookConsumer;
	}

	final SessionFactory factory = SessionFactory.getSessionFactory();
	final Session session = factory.getSession();

	SubscribeService subscribeService = new SubscribeService();

	public void webhookConsumer() {

		Consumer<String, String> consumer = KafkaConsumerUtil.createConsumer("subscriber-webhook-topic");

		while (true) {

			if (executor.getPoolSize() > executor.getCorePoolSize() * 2)
				continue;

			ConsumerRecords<String, String> consumerRecords = consumer
					.poll(Duration.ofMillis(KafkaConfigEnum.POLL_TIME.getLongValue()));
			// is the time in milliseconds consumer will wait if no record is found at
			// broker.

			if (consumerRecords.count() > 0) {

				System.out.println("WebHookConsumer Count : " + consumerRecords.count());
				List<SubscriberSubscription> subscriptionsList = new ArrayList<>();
				consumerRecords.forEach(record -> {
					try {
						SubscriberSubscription subscription = ObjectMapperHelper.getInstance()
								.getBeanFromString(record.value(), SubscriberSubscription.class);
						subscriptionsList.add(subscription);
					} catch (Exception e) {
						DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
								this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
								.writeExceptionLog();
						e.printStackTrace();
					}
				});

				/// in thread pool execution
				asyncExecution(subscriptionsList);

				// commits the offset of record to broker.
				consumer.commitAsync();
			}

		}

	}

	private void asyncExecution(List<SubscriberSubscription> subscriptionsList) {
		Runnable task = () -> {

			List<SubscriberActivity> subscriberActivitys = new ArrayList<>();

			for (SubscriberSubscription subscriptionDetails : subscriptionsList) {

				Subscriber subscriberById = subscriptionDetails.getSubscriber();
				String name = subscriberById != null
						? subscriberById.getFirstName() + " " + subscriberById.getLastName()
						: Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME;
				String siteId = subscriptionDetails.getPlan().getSiteId();

				SubscriberActivity subscriberActivity = new SubscriberActivity();
				subscriberActivity.setId(UniqueUUIDGenerator.getInstance().getUniqueUUID());
				subscriberActivity.setSiteId(siteId);
				subscriberActivity.setName(name + " " + Constants.DEFAULT_LOG_PLATFORM);
				subscriberActivity.setDescription("Created Subscription" + subscriptionDetails.getPlan().getName());
				subscriberActivity.setSubscriberId(subscriptionDetails.getSubscriberId());
				subscriberActivitys.add(subscriberActivity);

				// Subscription Webhook Activity
				subscribeService.addSubscriptionWebhookActivity(new BaseEventBean(), session, subscriptionDetails);
			}

			// bulk insert
			if (!subscriberActivitys.isEmpty()) {
				try {
					session.bulk(subscriberActivitys, false);
				} catch (Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeExceptionLog();
					e.printStackTrace();
				}
			}
		};

		executor.submit(task);

	}

}
