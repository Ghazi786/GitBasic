package com.jio.subscriptionengine.batchprocessing.Kafka;

import java.util.List;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.jio.blockchain.sdk.util.UniqueUUIDGenerator;

public class EmailProducer {

	private static Producer<String, Object> producer = KafkaProducerUtil.createProducer();

	private static EmailProducer emailProducer = new EmailProducer();

	private EmailProducer() {

	}

	public static EmailProducer getInstance() {

		return emailProducer;
	}

	public void createProducer(List<List<Object>> subscriptionInvoices) {
		try {
			for (List<Object> subscriptionInvoiceDetails : subscriptionInvoices) {
				ProducerRecord<String, Object> record = new ProducerRecord<String, Object>("email-topic",
						UniqueUUIDGenerator.getInstance().getUniqueUUID(), subscriptionInvoiceDetails);
				producer.send(record, (metadata, exception) -> {

					if (metadata == null) {
						exception.printStackTrace();
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
