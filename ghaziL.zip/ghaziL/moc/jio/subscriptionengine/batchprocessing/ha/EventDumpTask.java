package com.jio.subscriptionengine.batchprocessing.ha;

import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;
import com.rjil.management.alarm.db.elastic.EsManager;

/**
 * Thread to Dump Event
 * 
 * @author Kiran.Jangid
 *
 */

public class EventDumpTask implements Runnable {

	private BaseEventBean eventData;

	/**
	 * 
	 * @param eventData
	 */

	public EventDumpTask(BaseEventBean eventData) {
		this.eventData = eventData;
	}

	public EventDumpTask() {
		/**
		 * Default Constructor
		 */
	}

	@Override
	public void run() {

		String identifier = eventData.getFlowId() + "_" + eventData.getBranchId();
		String eventDataStr = eventData.toString();
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();

		ESConnection.getInstance().getHaOperation().dumpEventData(identifier, eventDataStr);

	}

}
