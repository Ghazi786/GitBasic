package com.jio.subscriptionengine.batchprocessing.ha;
import java.util.concurrent.ExecutorService;

import javax.servlet.AsyncContext;

import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.threadpoolfactory.EventAckAnnotationRequestDispatcher;

/**
 * Thread to Process all dump Event
 * 
 * @author Kiran.Jangid
 *
 */

public class DumpEventProcessTask implements Runnable {

	private BaseEventBean eventPojo;
	BaseResponse<?> controllerresponse = null;
	Class<?> classObj = null;


	/**
	 * 
	 * @param eventPojo
	 */

	public DumpEventProcessTask(BaseEventBean eventPojo) {
		this.eventPojo = eventPojo;
	}

	/**
	 * 
	 */

	public DumpEventProcessTask() {
		/**
		 * Default
		 */
	}

	@Override
	public void run() {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();

		/*RMRSubscribedEvent subscribedEvent = new RMRSubscribedEvent();
		RMREventProcessor processEvent = subscribedEvent.getEventObject(this.eventPojo.getEventName());
		processEvent.processEvent(this.eventPojo);*/
		try {
		DispatcherBaseController controller = (DispatcherBaseController) classObj.newInstance();
		
		AsyncContext context = this.eventPojo.getRequest().startAsync();
		
		ExecutorService executorService = BatchProcessingBootStrapper.getInstance().getDappExecutor();
		executorService
				.execute(new EventAckAnnotationRequestDispatcher(this.eventPojo, this.eventPojo.getRequest(), this.eventPojo.getResponse(), controller, context));

		
		} catch(Exception e) {
			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder(
					"Error [ " + this.getClass().getName() + "."
							+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();

		}

	}

}
