package com.jio.subscriptionengine.batchprocessing.rest;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.MBeanParameters;
import com.jio.telco.framework.pool.PoolingManager;

/**
 * @author Pramod.Jundre, Puspesh.Prakash
 *
 */
public class Statistics implements StatisticsMBean {
	
	private static Statistics st = new Statistics();

	private Statistics() {

	}

	public static Statistics getInstance() {
		if (st == null) {
			st = new Statistics();
		}
		return st;
	}
	
	public void startStatisticsMbeanService() {
		try {
			MBeanServer counterMbeanServer = ManagementFactory.getPlatformMBeanServer();
			ObjectName adapterName = new ObjectName(MBeanParameters.MBEAN_NAME_STATISTICS);
			counterMbeanServer.registerMBean(this, adapterName);

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "startStatisticsMbeanService")
					.writeExceptionLog();
		}
		
	}
	
	

	@Override
	public boolean fetchJettyStats()  
	{		
		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		try
		{
			String result = BatchProcessingBootStrapper.getInstance().getJettyRestEngine().jettyStats();
			
			File fileDir = new File(Constants.DUMP_PATH_JETTY);
			
			if (!fileDir.exists())
				fileDir.mkdirs();
			
			File file = new File(fileDir, "jettystats_" + (new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime())).toString() + ".txt");
			
			if (!file.exists()) 
			{
				file.createNewFile();
			}
			
            fileWriter = new FileWriter(fileDir + "/" + file.getName(), true);
			
			bufferedWriter = new BufferedWriter(fileWriter);
			
			bufferedWriter.write(result);
			
			bufferedWriter.close();
			fileWriter.close();
			
			if(new File(fileDir + "/" + file.getName()).length() == 0)
			{
				return false;
			}
		}
		
		catch(IOException e)
		{
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
			.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "fetchJettyStats")
			.writeExceptionLog();
			
			return false;
		} finally {
			if(fileWriter != null) {
				try {
					fileWriter.close();
				} catch (IOException e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "fetchJettyStats")
					.writeExceptionLog();
		}
			}
			if(bufferedWriter != null) {
				try {
					bufferedWriter.close();
				} catch (IOException e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "fetchJettyStats")
					.writeExceptionLog();
				}
			}
		}
	
		return true;
	}
	
	@Override
	public boolean fetchPoolingStats() 
	{
		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		try
		{
			String result = PoolingManager.getPoolingManager().getPoolStatistics();
				
			File fileDir = new File(Constants.DUMP_PATH_OBJECTPOOL);
			
			if (!fileDir.exists())
				fileDir.mkdirs();
			
			File file = new File(fileDir, "objectpoolstats_" + (new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime())).toString() + ".txt");
			
			if (!file.exists()) 
			{
				file.createNewFile();
			}
			
			fileWriter = new FileWriter(fileDir + "/" + file.getName(), true);
			
			bufferedWriter = new BufferedWriter(fileWriter);
			
			bufferedWriter.write(result);
			
			bufferedWriter.close();
			fileWriter.close();
			
			if(new File(fileDir + "/" + file.getName()).length() == 0)
			{
				return false;
			}
		} catch (IOException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
			.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "fetchPoolingStats")
			.writeExceptionLog();
			
			return false;
		} finally {
			if (fileWriter != null) {
				try {
					fileWriter.close();
				} catch (IOException e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG
							.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "fetchPoolingStats")
							.writeExceptionLog();
		}
			}
			if (bufferedWriter != null) {
				try {
					bufferedWriter.close();
				} catch (IOException e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG
							.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "fetchPoolingStats")
							.writeExceptionLog();
				}
			}
		}
		return true;
	}

		
	@Override
	public String fetchPoolStatistics()
	{
		return PoolingManager.getPoolingManager().getPoolStatistics();
	}

	
}
