package com.jio.subscriptionengine.batchprocessing.rest;

/**
 * @author Pramod.Jundre, Puspesh.Prakash
 *
 */
public interface StatisticsMBean {
	
	public boolean fetchJettyStats();
	
	public boolean fetchPoolingStats();
	
	public String fetchPoolStatistics();
}
