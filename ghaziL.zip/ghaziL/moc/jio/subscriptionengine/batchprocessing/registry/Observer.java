package com.jio.subscriptionengine.batchprocessing.registry;

public interface Observer {

	public void update(String query,String httpBody,String method,String serverState);
}
