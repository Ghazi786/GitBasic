package com.jio.subscriptionengine.batchprocessing.registry;

import java.util.Observable;
import java.util.Observer;

import com.jio.subscriptionengine.batchprocessing.configurationManager.InterfaceStatus;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;


public class RtJioObserver implements Observer {
	@Override
	public void update(Observable arg0, Object arg) {
		
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Observer received : " + arg, "RtJioObserver", "update").writeLog();
		if (arg.toString().equals("200")) {
			System.out.println("Status code: 200 received");
			DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Start component further task", "RtJioObserver", "update").writeLog();
			InterfaceStatus.status.setRegisterWithOAM(true);
			
		} else if (arg.toString().equals("500")) {
			System.out.println("Status code: 500 received");
			DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("############# OAM IS DOWN #############", "RtJioObserver", "update").writeLog();
			InterfaceStatus.status.setRegisterWithOAM(false);	
		}
	}

}
