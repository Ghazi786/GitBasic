/**
 * 
 */
package com.jio.subscriptionengine.batchprocessing.countermanager;

/**
 * @author Ghajnafar.Shahid
 *
 */
public enum StringNameEnum {
	OBJECT_POOL_STATISTICS,
	THREAD_POOL_INFO;

	private volatile String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
