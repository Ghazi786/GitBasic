package com.jio.subscriptionengine.batchprocessing.countermanager;

/**
 * this interface will have counter related Constant
 * 
 * @author Kiran.Jangid
 *
 */

public interface CounterConstants {

	public static final String BULK = "bulk";
	public static final String CSV_HEADER_COUNTERS = "Type,Name,Value\n";

}
