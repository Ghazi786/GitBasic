package com.jio.subscriptionengine.batchprocessing.countermanager;

import java.util.HashMap;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;

/**
 * 
 * This Enum defines Counter Category and Counter name
 * 
 * @author Kiran.Jangid
 *
 */
public enum CounterCategoryEnum {

	ES_CLIENT("es_operation", CounterNameEnum.CNTR_ES_INDEX_CREATION_REQUESTS,
			CounterNameEnum.CNTR_ES_INDEX_CREATION_SUCCESS, CounterNameEnum.CNTR_ES_INDEX_CREATION_FAILURE,
			CounterNameEnum.CNTR_ES_DOCUMENTS_CREATION_SUCCESS, CounterNameEnum.CNTR_ES_DOCUMENTS_CREATION_FAILURE,
			CounterNameEnum.CNTR_ES_SEARCH_REQUESTS, CounterNameEnum.CNTR_ES_SEARCH_SUCCESS,
			CounterNameEnum.CNTR_ES_SEARCH_FAILURE),

	SUBSCRIPTION_ACCOUNT("subscription_account", CounterNameEnum.CNTR_CREATE_SUBSCRIPTION_ACCOUNT_SUCCESS,
			CounterNameEnum.CNTR_CREATE_SUBSCRIPTION_ACCOUNT_FAILURE,
			CounterNameEnum.CNTR_CREATE_SUBSCRIPTION_ACCOUNT_REQUEST,
			CounterNameEnum.CNTR_UPDATE_SUBSCRIPTION_ACCOUNT_SUCCESS,
			CounterNameEnum.CNTR_UPDATE_SUBSCRIPTION_ACCOUNT_FAILURE,
			CounterNameEnum.CNTR_UPDATE_SUBSCRIPTION_ACCOUNT_REQUEST,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_ACCOUNT_SUCCESS,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_ACCOUNT_FAILURE,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_ACCOUNT_REQUEST,
			CounterNameEnum.CNTR_DELETE_SUBSCRIPTION_ACCOUNT_SUCCESS,
			CounterNameEnum.CNTR_DELETE_SUBSCRIPTION_ACCOUNT_FAILURE,
			CounterNameEnum.CNTR_DELETE_SUBSCRIPTION_ACCOUNT_REQUEST, CounterNameEnum.CNTR_GET_BILLING_ACCOUNT_SUCCESS,
			CounterNameEnum.CNTR_GET_BILLING_ACCOUNT_FAILURE, CounterNameEnum.CNTR_GET_BILLING_ACCOUNT_REQUEST,
			CounterNameEnum.CNTR_ADD_BILLING_ACCOUNT_SUCCESS, CounterNameEnum.CNTR_ADD_BILLING_ACCOUNT_FAILURE,
			CounterNameEnum.CNTR_UPDATE_BILLING_ACCOUNT_SUCCESS, CounterNameEnum.CNTR_UPDATE_BILLING_ACCOUNT_FAILURE,
			CounterNameEnum.CNTR_UPDATE_BILLING_ACCOUNT_REQUEST, CounterNameEnum.CNTR_DELETE_BILLING_ACCOUNT_SUCCESS,
			CounterNameEnum.CNTR_DELETE_BILLING_ACCOUNT_FAILURE, CounterNameEnum.CNTR_DELETE_BILLING_ACCOUNT_REQUEST,
			CounterNameEnum.CNTR_GET_BILLING_INFO_BY_BILLINGID_SUCCESS,
			CounterNameEnum.CNTR_GET_BILLING_INFO_BY_BILLINGID_FAILURE,
			CounterNameEnum.CNTR_GET_BILLING_INFO_BY_BILLINGIDT_REQUEST,
			CounterNameEnum.CNTR_GET_ACCOUNT_INFO_BY_USERNAME_SUCCESS,
			CounterNameEnum.CNTR_GET_ACCOUNT_INFO_BY_USERNAME_FAILURE,
			CounterNameEnum.CNTR_GET_ACCOUNT_INFO_BY_USERNAME_REQUEST,
			CounterNameEnum.CNTR_GET_ACCOUNT_INFO_BY_EMAIL_SUCCESS,
			CounterNameEnum.CNTR_GET_ACCOUNT_INFO_BY_EMAIL_FAILURE,
			CounterNameEnum.CNTR_GET_ACCOUNT_INFO_BY_EMAIL_REQUEST),
	// CounterNameEnum.CNTR_CREATE_SUBSCRIPTION_ACCOUNT_SUCCESS
	SUBSCRIPTION_DATA("subscription_data", CounterNameEnum.CNTR_INVOICE_DOWNLOAD_REQUEST,
			CounterNameEnum.CNTR_INVOICE_DOWNLOAD_SUCCESS, CounterNameEnum.CNTR_INVOICE_DOWNLOAD_FAILURE,
			CounterNameEnum.CNTR_INVOICE_DOWNLOAD_INVALID, CounterNameEnum.CNTR_VIEW_INVOICE_LIST_REQUEST,
			CounterNameEnum.CNTR_VIEW_INVOICE_LIST_SUCCESS, CounterNameEnum.CNTR_VIEW_INVOICE_LIST_FAILURE,
			CounterNameEnum.CNTR_VIEW_INVOICE_LIST_INVALID, CounterNameEnum.CNTR_VIEW_SUBSCRIBER_SUBSCRIPTION_REQUEST,
			CounterNameEnum.CNTR_VIEW_SUBSCRIBER_SUBSCRIPTION_SUCCESS,
			CounterNameEnum.CNTR_VIEW_SUBSCRIBER_SUBSCRIPTION_FAILURE,
			CounterNameEnum.CNTR_VIEW_SUBSCRIBER_SUBSCRIPTION_INVALID),

	PLANS("plan_data", CounterNameEnum.CNTR_VIEW_PLAN_LIST_REQUEST, CounterNameEnum.CNTR_VIEW_PLAN_LIST_SUCCESS,
			CounterNameEnum.CNTR_VIEW_PLAN_LIST_FAILURE, CounterNameEnum.CNTR_VIEW_PLAN_LIST_INVALID,
			CounterNameEnum.CNTR_VIEW_RECOMMENDED_PLAN_LIST_REQUEST,
			CounterNameEnum.CNTR_VIEW_RECOMMENDED_PLAN_LIST_SUCCESS,
			CounterNameEnum.CNTR_VIEW_RECOMMENDED_PLAN_LIST_FAILURE,
			CounterNameEnum.CNTR_VIEW_RECOMMENDED_PLAN_LIST_INVALID, CounterNameEnum.CNTR_GET_PLANS_LIST_FAILURE,
			CounterNameEnum.CNTR_GET_PLANS_LIST_REQUEST, CounterNameEnum.CNTR_GET_PLANS_LIST_SUCCESS,
			CounterNameEnum.CNTR_GET_PLAN_FAILURE, CounterNameEnum.CNTR_GET_PLAN_REQUEST,
			CounterNameEnum.CNTR_GET_PLAN_SUCCESS, CounterNameEnum.CNTR_GET_PLANS_BY_POPULARITY_FAILURE,
			CounterNameEnum.CNTR_GET_PLANS_BY_POPULARITY_REQUEST, CounterNameEnum.CNTR_GET_PLANS_BY_POPULARITY_SUCCESS,
			CounterNameEnum.CNTR_GET_PLANS_BY_RATINGS_FAILURE, CounterNameEnum.CNTR_GET_PLANS_BY_RATINGS_REQUEST,
			CounterNameEnum.CNTR_GET_PLANS_BY_RATINGS_SUCCESS, CounterNameEnum.CNTR_GET_PLANS_BY_FILTERS_FAILURE,
			CounterNameEnum.CNTR_GET_PLANS_BY_FILTERS_REQUEST, CounterNameEnum.CNTR_GET_PLANS_BY_FILTERS_SUCCESS,
			CounterNameEnum.CNTR_GET_PLAN_COUNT_FAILURE, CounterNameEnum.CNTR_GET_PLAN_COUNT_REQUEST,
			CounterNameEnum.CNTR_GET_PLAN_COUNT_SUCCESS, CounterNameEnum.CNTR_GET_PLAN_CATEGORIES_FAILURE,
			CounterNameEnum.CNTR_GET_PLAN_CATEGORIES_REQUEST, CounterNameEnum.CNTR_GET_PLAN_CATEGORIES_SUCCESS,
			CounterNameEnum.CNTR_CACHE_PLANS_FAILURE, CounterNameEnum.CNTR_CACHE_PLANS_REQUEST,
			CounterNameEnum.CNTR_CACHE_PLANS_SUCCESS, CounterNameEnum.CNTR_GET_PLAN_DETAILS_FAILURE,
			CounterNameEnum.CNTR_GET_PLAN_DETAILS_REQUEST, CounterNameEnum.CNTR_GET_PLAN_DETAILS_SUCCESS,
			CounterNameEnum.CNTR_SET_PLAN_LIST_IN_CACHE_UTIL, CounterNameEnum.CNTR_GET_PLAN_LIST_FROM_CACHE_UTIL,
			CounterNameEnum.CNTR_GET_PLAN_LIST_FROM_CACHE_UTIL_FAILURE,
			CounterNameEnum.CNTR_GET_PLAN_LIST_FROM_CACHE_FAILURE),

	REVIEWS("review_data", CounterNameEnum.CNTR_ADD_REVIEW_BY_PLAN_FAILURE,
			CounterNameEnum.CNTR_ADD_REVIEW_BY_PLAN_REQUEST, CounterNameEnum.CNTR_ADD_REVIEW_BY_PLAN_SUCCESS,
			CounterNameEnum.CNTR_GENERATE_RATINGS_FAILURE, CounterNameEnum.CNTR_GENERATE_RATINGS_REQUEST,
			CounterNameEnum.CNTR_GENERATE_RATINGS_SUCCESS, CounterNameEnum.CNTR_EDIT_REVIEW_BY_CUSTOMER_FAILURE,
			CounterNameEnum.CNTR_EDIT_REVIEW_BY_CUSTOMER_REQUEST, CounterNameEnum.CNTR_EDIT_REVIEW_BY_CUSTOMER_SUCCESS,
			CounterNameEnum.CNTR_GET_ALL_REVIEWS_FAILURE, CounterNameEnum.CNTR_GET_ALL_REVIEWS_REQUEST,
			CounterNameEnum.CNTR_GET_ALL_REVIEWS_SUCCESS, CounterNameEnum.CNTR_GENERATE_GROUP_RATINGS_FAILURE,
			CounterNameEnum.CNTR_GENERATE_GROUP_RATINGS_REQUEST, CounterNameEnum.CNTR_GENERATE_GROUP_RATINGS_SUCCESS),

	WISHLIST("wishlist_data", CounterNameEnum.CNTR_PLAN_SUBSCRIPTION_CHECK_FAILURE,
			CounterNameEnum.CNTR_PLAN_SUBSCRIPTION_CHECK_REQUEST, CounterNameEnum.CNTR_PLAN_SUBSCRIPTION_CHECK_SUCCESS,
			CounterNameEnum.CNTR_ADD_WISHLIST_FAILURE, CounterNameEnum.CNTR_ADD_WISHLIST_REQUEST,
			CounterNameEnum.CNTR_ADD_WISHLIST_SUCCESS, CounterNameEnum.CNTR_DELETE_WISHLIST_FAILURE,
			CounterNameEnum.CNTR_DELETE_WISHLIST_REQUEST, CounterNameEnum.CNTR_DELETE_WISHLIST_SUCCESS,
			CounterNameEnum.CNTR_GET_WISHLIST_WITH_ID_FAILURE, CounterNameEnum.CNTR_GET_WISHLIST_WITH_ID_REQUEST,
			CounterNameEnum.CNTR_GET_WISHLIST_WITH_ID_SUCCESS),

	SUBSCRIPTION("subscription", CounterNameEnum.CNTR_SUBSCRIBE_PLAN_FAILURE,
			CounterNameEnum.CNTR_SUBSCRIBE_PLAN_REQUEST, CounterNameEnum.CNTR_SUBSCRIBE_PLAN_SUCCESS,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_LIST_FAILURE, CounterNameEnum.CNTR_GET_SUBSCRIPTION_LIST_REQUEST,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_LIST_SUCCESS, CounterNameEnum.CNTR_GET_SUBSCRIPTION_FILTERS_FAILURE,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_FILTERS_REQUEST,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_FILTERS_SUCCESS, CounterNameEnum.CNTR_GET_TRIAL_COUNT_FILTER_FAILURE,
			CounterNameEnum.CNTR_GET_TRIAL_COUNT_FILTER_REQUEST, CounterNameEnum.CNTR_GET_TRIAL_COUNT_FILTER_SUCCESS,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_PLAN_DETAILS_FAILURE,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_PLAN_DETAILS_REQUEST,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_PLAN_DETAILS_SUCCESS,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_INVOICE_DETAILS_FAILURE,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_INVOICE_DETAILS_REQUEST,
			CounterNameEnum.CNTR_GET_SUBSCRIPTION_INVOICE_DETAILS_SUCCESS,
			CounterNameEnum.CNTR_PAUSE_SUBSCRIPTION_FAILURE, CounterNameEnum.CNTR_PAUSE_SUBSCRIPTION_REQUEST,
			CounterNameEnum.CNTR_PAUSE_SUBSCRIPTION_SUCCESS, CounterNameEnum.CNTR_CANCEL_PAUSE_SUBSCRIPTION_FAILURE,
			CounterNameEnum.CNTR_CANCEL_PAUSE_SUBSCRIPTION_REQUEST,
			CounterNameEnum.CNTR_CANCEL_PAUSE_SUBSCRIPTION_SUCCESS,
			CounterNameEnum.CNTR_RESUME_PAUSE_SUBSCRIPTION_FAILURE,
			CounterNameEnum.CNTR_RESUME_PAUSE_SUBSCRIPTION_REQUEST,
			CounterNameEnum.CNTR_RESUME_PAUSE_SUBSCRIPTION_SUCCESS, CounterNameEnum.CNTR_CANCEL_SUBSCRIPTION_FAILURE,
			CounterNameEnum.CNTR_CANCEL_SUBSCRIPTION_REQUEST, CounterNameEnum.CNTR_CANCEL_SUBSCRIPTION_SUCCESS,
			CounterNameEnum.CNTR_REACTIVATE_SUBSCRIPTION_FAILURE, CounterNameEnum.CNTR_REACTIVATE_SUBSCRIPTION_REQUEST,
			CounterNameEnum.CNTR_REACTIVATE_SUBSCRIPTION_SUCCESS, CounterNameEnum.CNTR_EDIT_PAUSE_SUBSCRIPTION_FAILURE,
			CounterNameEnum.CNTR_EDIT_PAUSE_SUBSCRIPTION_REQUEST, CounterNameEnum.CNTR_EDIT_PAUSE_SUBSCRIPTION_SUCCESS);

	private CounterNameEnum[] counterNames;
	private String cliName;
	private static HashMap<String, CounterCategoryEnum> cliNameVsEnumMap = new HashMap<>();
	private static final int FORMAT_BORDER = 55;

	static {
		CounterCategoryEnum[] counterCategories = CounterCategoryEnum.values();
		for (CounterCategoryEnum counterCategory : counterCategories)
			cliNameVsEnumMap.put(counterCategory.getCliName(), counterCategory);
	}

	private CounterCategoryEnum(String cliName, CounterNameEnum... counterNames) {
		this.cliName = cliName;
		this.counterNames = counterNames;
	}

	/**
	 * @return all the counters in this category in a map with key as counter name
	 *         and value as its current value
	 */
	HashMap<String, Long> getCounterMap() {
		HashMap<String, Long> cmap = new HashMap<>();
		for (CounterNameEnum counterNameEnum : this.counterNames)
			cmap.put(counterNameEnum.name(), counterNameEnum.getValue());
		return cmap;
	}

	/**
	 * reset all the performance counters that belongs to this category
	 */
	void reset() {
		for (CounterNameEnum counterName : this.counterNames)
			counterName.reset();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder("All performance counters of category '" + this.name() + "' have been reset",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
	}

	/**
	 * @return the name to be used as a CLI argument to fetch/reset counters by
	 *         category
	 */
	String getCliName() {
		return cliName;
	}

	/**
	 * returns the enumeration instance from the name of the CLI argument
	 * 
	 * @param arg name of the CLI argument
	 * @return the enumeration instance from the name of the CLI argument
	 */
	static CounterCategoryEnum getEnumFromCliArg(String arg) {
		return cliNameVsEnumMap.get(arg);
	}

	/**
	 * @return return the counters in a readable format to be displayed in CLI
	 */
	StringBuilder formatCounters() {
		StringBuilder counterDump = new StringBuilder();
		String s;
		String format;
		String key;
		for (CounterNameEnum counterNameEnum : this.counterNames) {
			key = counterNameEnum.name();
			format = key + "%" + (FORMAT_BORDER - key.length()) + "s";
			s = String.format(format, "=   ");
			counterDump.append(s + counterNameEnum.getValue() + "\n");
		}
		counterDump.insert(0, "\n    List of Counters of type = " + this.cliName + "\n")
				.append("######################################\n");
		return counterDump;
	}

}
