
package com.jio.subscriptionengine.batchprocessing.handler;

import static javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST;
import static javax.servlet.http.HttpServletResponse.SC_OK;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.eclipse.jetty.http.HttpMethod;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.atom.OAM.Client.Management.OamClientManager;
import com.jio.subscriptionengine.batchprocessing.alarmManager.HttpParametersAndHeadersIntf;
import com.jio.subscriptionengine.batchprocessing.configurationManager.ConfigParamsEnum;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.ha.DumpEventProcessTask;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;

/**
 * This class handle all the Broadcast messages of other Microservices from OAM.
 * This class also handle the Re- registration of TRM with OAM in case of OAM
 * restart.
 *
 */

public class RegistryBroadcastHandler extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest httpservletrequest, HttpServletResponse response)
			throws IOException, ServletException {
		try {
			if (httpservletrequest.getMethod().equalsIgnoreCase(HttpMethod.POST.asString())) {
				InputStream inputStream = httpservletrequest.getInputStream();
				String msgBody = IOUtils.toString(inputStream, httpservletrequest.getCharacterEncoding());

				DappLoggerService.GENERAL_INFO_LOG
						.getInfoLogBuilder("Registry Broadcast msg body : \n" + msgBody + "\n");

				System.out.println(msgBody);
				JSONObject broadcastObj = new JSONObject(msgBody);

				DappLoggerService.GENERAL_INFO_LOG
						.getInfoLogBuilder("Registry Broadcast broadcastObj : \n" + broadcastObj + "\n");

				// this.elbCacheInformationUpdate(msgBody);

				// Processing ELB Instance Data
				if (broadcastObj.has(Constants.COMPONENT_TYPE_EDGELB)) {
					this.elbCacheInformationUpdate(msgBody);
					return;
				}

				// Processing USER_SUBSCRIPTION_MS Instance Data
				if (broadcastObj.has(Constants.USER_SUBSCRIPTION_MS)) {
					parseBoardCastJson(broadcastObj);
					return;
				}

				BatchProcessingBootStrapper.getInstance().getDappExecutor()
						.submit(() -> this.elbCacheInformationUpdate(msgBody));

			}
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "doPost").writeExceptionLog();
		}
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {

			if (request.getParameter("operation").equals(Constants.RE_REGISTER)) {

				reRegisterWithOam(request, response);

				DappLoggerService.GENERAL_INFO_LOG.getInfoLogBuilder("Re Registaration with OAM done Successfully")
						.writeLog();
			} else {

				response.setStatus(SC_BAD_REQUEST);
			}

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(), "doGet").writeExceptionLog();
		}

	}

	private void reRegisterWithOam(HttpServletRequest request, HttpServletResponse response) throws IOException {

		if (OamClientManager.getInstance().isAlreadyConnectedToOAM()) {
			response.setStatus(SC_BAD_REQUEST);
			return;
		}
		String ip = request.getHeader(Constants.HTTP_IP);
		String port = request.getHeader(Constants.HTTP_PORT);
		String nettyPort = request.getHeader(Constants.NETTY_PORT);

		OamClientManager.getInstance().setOAMDetails(ip, port, nettyPort);
		response.setStatus(SC_OK);
		BatchProcessingBootStrapper.getInstance().registerWithOAM();

	}

	private void elbCacheInformationUpdate(String broadcastJson) {

		try {

			DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Updating EdgeLB's cache information",
					"RegistryBroadcastHandler", "elbCacheInformationUpdate").writeLog();

			Thread.currentThread().setName("MicroservicName_FQDNMapping_Cache_Update_Thread");
			JSONObject broadcastJsonObj = new JSONObject(broadcastJson);

			if (broadcastJsonObj.has(Constants.COMPONENT_TYPE_EDGELB)) {

				DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("COMPONENT_TYPE_EDGELB found in broadcast json ",
						"RegistryBroadcastHandler", "elbCacheInformationUpdate").writeLog();

				JSONArray listOfedgeLBJson = broadcastJsonObj.getJSONArray(Constants.COMPONENT_TYPE_EDGELB);

				for (int edgeLbJson = 0; edgeLbJson < listOfedgeLBJson.length(); edgeLbJson++) {

					JSONObject elbInstanceDetails = listOfedgeLBJson.getJSONObject(edgeLbJson);

					boolean isActiveElb = elbInstanceDetails.getBoolean(Constants.ACTIVE);
					if (!isActiveElb) {
						continue;
					}

					String edgeLBIp = null;
					if (elbInstanceDetails.has(Constants.IP)) {
						edgeLBIp = elbInstanceDetails.getString(Constants.IP);
					} else {
						DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("IP not found in EdgeLB json",
								"RegistryBroadcastHandler", "elbCacheInformationUpdate").writeLog();
					}

					int edgeLBPort = elbInstanceDetails.getInt(Constants.PORT);
					ConfigParamsEnum.ELB_HOSTED_HTTP_PORT.setParamValue(String.valueOf(edgeLBPort));
					ConfigParamsEnum.ELB_HOSTED_IP.setParamValue(edgeLBIp);
					ConfigParamsEnum.ELB_HOSTED_PORT.setParamValue(String.valueOf(edgeLBPort));
					ConfigParamsEnum.ELB_HOSTED_PROTOCOL.setParamValue("http");

					if (elbInstanceDetails.has("optionalfieldname")) {
						JSONArray optionalfieldnameJson = elbInstanceDetails.getJSONArray("optionalfieldname");

						for (int iJson = 0; iJson < optionalfieldnameJson.length(); iJson++) {
							JSONObject optionalFieldJson = optionalfieldnameJson.getJSONObject(iJson);

							if (optionalFieldJson.has(Constants.HTTPS_PROTOCOL)
									&& optionalFieldJson.get(Constants.HTTPS_PROTOCOL) != null) {
								// https
								int edgeLBHttpsPort = optionalFieldJson.getInt(Constants.HTTPS_PROTOCOL);
								ConfigParamsEnum.ELB_HOSTED_PORT.setParamValue(String.valueOf(edgeLBHttpsPort));

								ConfigParamsEnum.ELB_HOSTED_PROTOCOL.setParamValue("https");

							}
						}
					}

					JSONArray subscribeComponentTypeArray = new JSONArray();
					if (elbInstanceDetails.has(Constants.SUBSCRIBE_COMPONENT_TYPE)) {
						subscribeComponentTypeArray = elbInstanceDetails
								.getJSONArray(Constants.SUBSCRIBE_COMPONENT_TYPE);

					} else {
						DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("subscribecomponenttype is not found....",
								"RegistryBroadcastHandler", "elbCacheInformationUpdate").writeLog();
					}

					for (int i = 0; i < subscribeComponentTypeArray.length(); i++) {

						if (subscribeComponentTypeArray.getString(i).equals(Constants.COMPONENT_TYPE_ERM)) {

							BatchProcessingBootStrapper.getInstance().getErmRequestBuilderManager()
									.initialize(edgeLBIp, edgeLBPort, isActiveElb, null);

							DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Storing ERM edgeLb info in cache",
									"RegistryBroadcastHandler", "elbCacheInformationUpdate").writeLog();

						} else if (subscribeComponentTypeArray.getString(i)
								.equals(HttpParametersAndHeadersIntf.COMPONENT_TYPE_CMN)) {

							DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Storing cmn EdgeLb ID in cache",
									"RegistryBroadcastHandler", "elbCacheInformationUpdate").writeLog();

						}

					}

				}

			} else {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG
						.getLogBuilder("COMPONENT_TYPE_EDGELB not found in broadcast json", "RegistryBroadcastHandler",
								"elbCacheInformationUpdate")
						.writeLog();
			}

		} catch (Exception e) {

			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, e.getMessage(), "RegistryBroadcastHandler", "elbCacheInformationUpdate")
					.writeExceptionLog();
		}
	}

	/**
	 * Parsing RMR Broadcast Data
	 * 
	 * @return
	 * @throws JSONException
	 */

	void parseBoardCastJson(JSONObject broadCastJson) throws JSONException {

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder("Inside parseBoardCastJson  : ", this.getClass().getName(), "parseBoardCastJson")
				.writeLog();

		JSONArray msInstanceList = broadCastJson.getJSONArray(Constants.USER_SUBSCRIPTION_MS);

		boolean isCallForInstanceDown = false;

		for (int k = 0; k < msInstanceList.length(); k++) {

			JSONObject eObj = msInstanceList.getJSONObject(k);

			boolean activeInstance = eObj.getBoolean(Constants.ACTIVE);

			if (!activeInstance) {
				isCallForInstanceDown = true;
			}

		}

		if (isCallForInstanceDown) {

			int highestPriority = 0;

			for (int k = 0; k < msInstanceList.length(); k++) {

				JSONObject eObj = msInstanceList.getJSONObject(k);

				boolean activeInstance = eObj.getBoolean(Constants.ACTIVE);

				if (!activeInstance) {
					continue;
				}

				int instancePriority = eObj.getInt(Constants.CMN_PRIORITY_DETAILS);

				if (highestPriority < instancePriority) {
					highestPriority = instancePriority;
				}

			}

			for (int k = 0; k < msInstanceList.length(); k++) {

				JSONObject eObj = msInstanceList.getJSONObject(k);

				boolean activeInstance = eObj.getBoolean(Constants.ACTIVE);

				if (!activeInstance) {
					continue;
				}

				int instancePriority = eObj.getInt(Constants.CMN_PRIORITY_DETAILS);

				if ((highestPriority == instancePriority) && eObj.getString(Constants.PARAMETER_ID)
						.equalsIgnoreCase(BatchProcessingBootStrapper.getInstance().getComponentId())) {

					DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(
							"ID is Processing Dump Queued Event  : " + eObj.getString(Constants.PARAMETER_ID),
							this.getClass().getName(), "parseBoardCastJson").writeLog();

					// Processing Dump Event if Any
					processDumpEvent();
				}

			}

		}

	}

	/**
	 * Method to Process All Dump Event
	 */

	private void processDumpEvent() {

		List<String> eventString = ESConnection.getInstance().getHaOperation().getAllEventData();

		Iterator<String> eventList = eventString.iterator();

		BaseEventBean eventPojo = new BaseEventBean();

		while (eventList.hasNext()) {

			String eventStr = eventList.next();

			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder("Processing Data = " + eventStr, this.getClass().getName(), "processDumpEvent")
					.writeLog();

			BaseEventBean eventData;

			try {

				eventData = eventPojo.getEventPojo(eventStr);
				BatchProcessingBootStrapper.getInstance().getDappExecutor()
						.execute(new DumpEventProcessTask(eventData));

			} catch (JSONException e) {
				DappLoggerService.GENERAL_INFO_LOG
						.getLogBuilder("Error in parsing Event Json to build Event Pojo " + eventStr,
								this.getClass().getName(), "processDumpEvent")
						.writeLog();
			}

		}

	}

}
