package com.jio.subscriptionengine.batchprocessing.clearCodes;

public class ClearCodeLevel {
	public static final String PROTOCOL = "1";
	public static final String PAYLOAD = "2";
	public static final String SUCCESS = "3";
	public static final String INTERNAL ="4";
	public static final String FAILURE = "5";
}
