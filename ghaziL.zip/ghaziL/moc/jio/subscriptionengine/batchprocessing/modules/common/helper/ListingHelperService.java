package com.jio.subscriptionengine.batchprocessing.modules.common.helper;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.elasticsearch.search.sort.SortOrder;

import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;

public class ListingHelperService {
	public DateRange getDateRangeFilterParam(final HttpServletRequest req) {
		final String fromDate = req.getParameter(ListingCommonConstants.FROM_DATE);
		final String toDate = req.getParameter(ListingCommonConstants.TO_END);

		DateRange dateRange = null;
		if (StringUtils.isNotEmpty(fromDate) && StringUtils.isNotEmpty(toDate)) {
			try {
				dateRange = new DateRange(fromDate, toDate, ListingCommonConstants.DATE_FORMAT);
			} catch (final ParseException e) {
				// TODO: handle exception
			}
		}
		return dateRange;
	}

	public OrderBy getOrderByList(final HttpServletRequest req) {
		OrderBy order = null;
		final String sortParam = req.getParameter(ListingCommonConstants.SORT);
		final String orderParam = req.getParameter(ListingCommonConstants.ORDER);

		if (sortParam != null && orderParam != null) {
			if (orderParam.equals(ListingCommonConstants.ASC))
				order = new OrderBy(sortParam, SortOrder.ASC);
			else
				order = new OrderBy(sortParam, SortOrder.DESC);
		}
		return order;
	}
	
	/**
	 * A helper method which will extract the filters provided in request parameters and map them to corresponding field of that class 
	 * @param req
	 * @param clazz
	 * @return
	 */
	public Map<String, Object> getFiltersFromRequest(HttpServletRequest req, Class<?> clazz) {
		
		List<String> fields = Arrays.asList(clazz.getDeclaredFields()).stream().map(Field :: getName).collect(Collectors.toList());
		Enumeration<String> params = req.getParameterNames();
		Map<String, Object> filters = new HashMap<>();
		while(params.hasMoreElements()) {
			String param = params.nextElement();
			if(fields.contains(param)) {
				filters.put(fields.get(fields.indexOf(param)), req.getParameter(param));
			}
		}
		return filters;
	}
}
