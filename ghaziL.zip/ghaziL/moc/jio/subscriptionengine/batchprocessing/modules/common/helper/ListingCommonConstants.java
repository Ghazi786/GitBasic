package com.jio.subscriptionengine.batchprocessing.modules.common.helper;

public class ListingCommonConstants {

	public static String ID = "id";

	public static String FROM_DATE = "from_date";

	public static String TO_END = "to_end";

	public static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static String SORT = "sort";

	public static String ORDER = "order";

	public static String ASC = "ASC";

	public static String PAGE = "page";

	public static String PAGE_SIZE = "page_size";

	public static String q = "q";
}
