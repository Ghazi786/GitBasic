package com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.EmailTemplate;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.service.EmailTemplateService;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.notification.NotificationService;
import com.jio.subscriptionengine.batchprocessing.utils.FtlUtilImpl;

public class EmailHandler {

	private static EmailHandler emailHandler = new EmailHandler();

	private EmailHandler() {

	}

	public static EmailHandler getInstance() {
		if (emailHandler == null) {
			emailHandler = new EmailHandler();
		}
		return emailHandler;
	}

	/**
	 * Trigger Email method to get the email template and send mail
	 * 
	 * @param subscriberSubscription
	 * @param label
	 * @param siteId
	 * @return
	 * @throws Exception
	 */
	public static void triggerEmail(final SubscriberSubscription subscriberSubscription, final String label,
			final String siteId, final Boolean Emailflag,File file) throws Exception {
		final EmailHandler emailHandlerInstance = EmailHandler.getInstance();
		emailHandlerInstance.sendMail(label, siteId, subscriberSubscription, Emailflag,file);

	}

	/**
	 * Send Email method to send mail through notification service
	 * 
	 * @param label
	 * @param siteId
	 * @return
	 */
	public void sendMail(final String label, final String siteId, final SubscriberSubscription subscriberSubscription,
			final Boolean Emailflag,File file) {

		final List<String> toList = new ArrayList<>();
		final List<String> ccList = new ArrayList<>();
		
		File attachement=null;

		final EmailTemplateService emailTemplateService = new EmailTemplateService();
		final EmailTemplate template = emailTemplateService.getEmailTemplateByLabel(label, siteId);

		String buildPojoObj = null;
		try {

			if (template == null) {
				return;
			}
			buildPojoObj = FtlUtilImpl.getInstance().buildPojoObj(template.getHtmlBody(), subscriberSubscription);

		} catch (final Exception e) {
			
			e.printStackTrace();
		}

		
		if(subscriberSubscription.getSubscriber()==null)
		{
			return;
		}
		
		toList.add(subscriberSubscription.getSubscriber().getEmail());
		ccList.add(subscriberSubscription.getSubscriber().getCcEmail());

		
		if(file!=null)
		{
			attachement=file;
		}

		final NotificationService notificationService = NotificationService.getInstance();
		try {
			if (template.getIsEmailEnabled()) {
				if (Emailflag) {
					notificationService.sendMail(toList, ccList, template.getEmailSubject(), buildPojoObj, null, null,
							attachement);
				}
			}
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void sendBulkMail(final String emailTemplateLabel, final List<Map<String, Object>> emailsData) {

		final List<String> toList = new ArrayList<>();
		final List<String> ccList = new ArrayList<>();
		final EmailTemplateService emailTemplateService = new EmailTemplateService();
		final Map<String, EmailTemplate> templateBySiteId = new HashMap<>();

		try {

			final FtlUtilImpl ftlUtilInstance = FtlUtilImpl.getInstance();
			for (final Map<String, Object> data : emailsData) {

				final String site = (String) data.get("siteId");
				if (templateBySiteId.get(site) == null) {
					templateBySiteId.put(site, emailTemplateService.getEmailTemplateByLabel(emailTemplateLabel, site));
				}

				final EmailTemplate template = templateBySiteId.get(site);
				
				if (template == null) {
					return;
				}
				
				final Object toEmail = data.get("to");
				final Object ccEmail = data.get("cc");
				

				if (toEmail != null && StringUtils.isNotEmpty((String) toEmail) && template.getIsEmailEnabled()) {

					final String htmlBody = template.getHtmlBody();

					final Runnable task = () -> {
						try {

							final String buildPojoObj = ftlUtilInstance.buildPojoObj(htmlBody, data.get("contentObj"));

							toList.add((String) toEmail);
							ccList.add((String)ccEmail);

							final NotificationService notificationService = NotificationService.getInstance();

							notificationService.sendMail(toList, ccList, template.getEmailSubject(), buildPojoObj, null,
									null, null);
						} catch (final Exception e) {
							DappLoggerService.GENERAL_ERROR_FAILURE_LOG
									.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(),
											Thread.currentThread().getStackTrace()[1].getMethodName())
									.writeLog();
						}

					};
					BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(task);

				}
			}
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}

	}
	
	/**
	 * Trigger Email with multiple attachments
	 * method to get the email template and send mail
	 * @param subscriberSubscription
	 * @param label
	 * @param siteId
	 * @return
	 * @throws Exception 
	 */
	public static void triggerEmailWithListOfAttachments(final SubscriberSubscription subscriberSubscription, final String label, final String siteId,final Boolean Emailflag, List<File> files) throws Exception {
		final EmailHandler emailHandlerInstance = EmailHandler.getInstance();
		emailHandlerInstance.sendMailWithListOfAttachments(label, siteId,subscriberSubscription,Emailflag, files);
		
	}
	
	/**
	 * Send Email with list of attachments
	 * method to send mail through notification service
	 * @param label
	 * @param siteId
	 * @return
	 */
	public void sendMailWithListOfAttachments(final String label, final String siteId,final SubscriberSubscription subscriberSubscription,final Boolean Emailflag, List<File> files) {
		
		final List<String> toList = new ArrayList<>();
		final List<String> ccList = new ArrayList<>();
		
		final EmailTemplateService emailTemplateService = new EmailTemplateService();
		final EmailTemplate template = emailTemplateService.getEmailTemplateByLabel(label, siteId);
		
		String  buildPojoObj=null;
		try {
			 buildPojoObj = FtlUtilImpl.getInstance().buildPojoObj(template.getHtmlBody().replace("\u200B", ""), subscriberSubscription);
			
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		toList.add("Ashish14.Gupta@ril.com");
		ccList.add(subscriberSubscription.getSubscriber().getCcEmail());

		final NotificationService notificationService = NotificationService.getInstance();
		try {
			if (template.getIsEmailEnabled()) {
				if (Emailflag) {
					notificationService.sendMailWithListOfAttachments(toList, ccList, template.getEmailSubject(), buildPojoObj, null, null,
							files);
				}
			}
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

}
