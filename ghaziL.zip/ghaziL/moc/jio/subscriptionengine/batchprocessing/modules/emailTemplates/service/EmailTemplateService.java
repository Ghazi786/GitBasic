package com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.service;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.bean.SearchResult;
import com.elastic.search.enums.Levels;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
//import com.jio.subscriptionengine.batchprocessing.clearCode.ClearCodeLevel;
//import com.jio.subscriptionengine.batchprocessing.clearCode.ClearCodes;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.EmailTemplate;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.repository.EmailTemplateRepository;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;

public class EmailTemplateService {
	
	private EmailTemplateRepository emailTemplateRepository = new EmailTemplateRepository();
	ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();

	public EmailTemplateService() {
		
	}
	
	/**
	 * returns the email template by id
	 * @param id
	 * @return
	 */
	public BaseResponse<EmailTemplate> getEmailTemplateById(String id) {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
//		ccAsnPojo.addClearCode(ClearCodes.GET_EMAIL_TEMPLATE_BY_ID_START.getValue(),
//				ClearCodeLevel.SUCCESS);
//		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		EmailTemplate emailTemplate;
		try {
			emailTemplate = emailTemplateRepository.getEmailTemplateById(session, id);
			BaseResponse<EmailTemplate> baseResponse = new BaseResponse<>(emailTemplate);
			
//			ccAsnPojo.addClearCode(ClearCodes.GET_EMAIL_TEMPLATE_BY_ID_SUCCESS.getValue(),
//					ClearCodeLevel.SUCCESS);
//			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			
			return baseResponse;

		} catch (ElasticSearchException e) {

			// TODO : check exception
//			ccAsnPojo.addClearCode(ClearCodes.GET_EMAIL_TEMPLATE_BY_ID_FAILURE.getValue(),
//					ClearCodeLevel.FAILURE);
//			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

			e.printStackTrace();
		} finally {
			session.close();

		}

		return null;
	}
	
	/**
	 * returns the email template for the label provided
	 * @param label
	 * @return
	 */
	public EmailTemplate getEmailTemplateByLabel(String label, String siteId) {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		try {
			return emailTemplateRepository.getEmailTemplateByLabel(session, label, siteId);

		} catch (ElasticSearchException e) {

			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		} finally {
			session.close();

		}

		return null;
	}
	
	/**
	 * deletes the email template by id
	 * @param id
	 * @throws Exception
	 */
	public void deleteEmailTemplateById(String id) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		try {

			// get email template
			EmailTemplate emailTemplate = emailTemplateRepository.getEmailTemplateById(session, id);

			// delete email template
			emailTemplateRepository.deleteEmailTemplate(session, emailTemplate);

		} catch (Exception e) {
			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (Exception rollback) {
				rollback.printStackTrace();
			}

			throw e;

		} finally {
			session.close();
		}
	}
	
	/**
	 * deletes the email template by label
	 * @param label
	 * @throws Exception
	 */
	public void deleteEmailTemplateByLabel(String label, String siteId) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		try {

			// get email template
			EmailTemplate emailTemplate = emailTemplateRepository.getEmailTemplateByLabel(session, label, siteId);

			// delete email template
			emailTemplateRepository.deleteEmailTemplate(session, emailTemplate);

		} catch (Exception e) {
			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (Exception rollback) {
				rollback.printStackTrace();
			}

			throw e;

		} finally {
			session.close();
		}
	}
	
	/**
	 * returns the updated email template by id
	 * @param id
	 * @param siteId
	 * @param updatedEmailTemplate
	 * @return
	 * @throws Exception
	 */
	public BaseResponse<EmailTemplate> updateEmailTemplateById(String id, EmailTemplate updatedEmailTemplate) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
//		ccAsnPojo.addClearCode(ClearCodes.UPDATE_EMAIL_TEMPLATE_BY_ID_START.getValue(),
//				ClearCodeLevel.SUCCESS);
//		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		try {
			
			EmailTemplate emailTemplate = session.getObject(EmailTemplate.class, id);
			emailTemplate.setDescription(updatedEmailTemplate.getDescription());	
			emailTemplate.setHtmlBody(updatedEmailTemplate.getHtmlBody());
			emailTemplate.setTextBody(updatedEmailTemplate.getTextBody());
			emailTemplate.setCcEmailId(updatedEmailTemplate.getCcEmailId());
			emailTemplate.setFromEmailId(updatedEmailTemplate.getFromEmailId());
			emailTemplate.setIsHTMLEmailIncluded(updatedEmailTemplate.getIsHTMLEmailIncluded());
			emailTemplate.setIsEmailEnabled(updatedEmailTemplate.getIsEmailEnabled());
			emailTemplate.setNumberOfDaysPriorToRenewal(updatedEmailTemplate.getNumberOfDaysPriorToRenewal());
			emailTemplate.setIsReminderBeforeEachTerm(updatedEmailTemplate.getIsReminderBeforeEachTerm());
			emailTemplate.setIsReminderBeforeEachBillDate(updatedEmailTemplate.getIsReminderBeforeEachBillDate());
			emailTemplate.setEmailSubject(updatedEmailTemplate.getEmailSubject());
			emailTemplate.setCategory(updatedEmailTemplate.getCategory());
			
			session.merge(emailTemplate);
			
//			ccAsnPojo.addClearCode(ClearCodes.UPDATE_EMAIL_TEMPLATE_BY_ID_SUCCESS.getValue(),
//					ClearCodeLevel.SUCCESS);
//			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			
			return getEmailTemplateById(id);
			
		} catch(Exception e) {
			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (Exception rollback) {
				rollback.printStackTrace();
//				ccAsnPojo.addClearCode(ClearCodes.UPDATE_EMAIL_TEMPLATE_BY_ID_FAILURE.getValue(),
//						ClearCodeLevel.FAILURE);
//				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			}

			throw e;

		} finally {
			session.close();
		}
	}
	
	/**
	 * returns the updated email template by label
	 * @param label
	 * @param siteId
	 * @param updatedEmailTemplate
	 * @return
	 * @throws Exception
	 */
	public EmailTemplate updateEmailTemplateByLabel(String label, String siteId, EmailTemplate updatedEmailTemplate) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		Map<String, String> filter = new HashMap<>();
		filter.put("label", label);
		filter.put("siteId", siteId);
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		try {
			
			EmailTemplate emailTemplate = session.getObject(EmailTemplate.class, "filter", filter);
			emailTemplate.setDescription(updatedEmailTemplate.getDescription());	
			emailTemplate.setHtmlBody(updatedEmailTemplate.getHtmlBody());
			emailTemplate.setTextBody(updatedEmailTemplate.getTextBody());
			emailTemplate.setCcEmailId(updatedEmailTemplate.getCcEmailId());
			emailTemplate.setFromEmailId(updatedEmailTemplate.getFromEmailId());
			
			session.merge(emailTemplate);
			
			return getEmailTemplateByLabel(label, siteId);
			
		} catch(Exception e) {
			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (Exception rollback) {
				rollback.printStackTrace();
			}

			throw new BaseException(HttpStatus.BAD_REQUEST_400, EmailTemplateConstants.UPDATE_ERROR);

		} finally {
			session.close();
		}
	}
	
	/**
	 * returns all email templates
	 * @return
	 * @throws ElasticSearchException
	 */
	public BaseResponse<SearchResult<EmailTemplate>> getAllEmailTemplates(String siteId) throws ElasticSearchException {

		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		SearchResult<EmailTemplate> result = emailTemplateRepository.getAllEmailTemplates(session, siteId);
		final BaseResponse<SearchResult<EmailTemplate>> baseResponse = new BaseResponse<SearchResult<EmailTemplate>>(result);
		session.close();

		return baseResponse;
	}
	
	/**
	 * returns the email template based on the label provided 
	 * without wrapping it in BaseResponse
	 * @param label
	 * @return
	 */
	public EmailTemplate getEmailTemplateWithNoBaseResponse(String label, String siteId) {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		EmailTemplate emailTemplate;
		try {
			emailTemplate = emailTemplateRepository.getEmailTemplateByLabel(session, label, siteId);
			return emailTemplate;

		} catch (ElasticSearchException e) {
			e.printStackTrace();
		} finally {
			session.close();

		}

		return null;
	}
	
}
