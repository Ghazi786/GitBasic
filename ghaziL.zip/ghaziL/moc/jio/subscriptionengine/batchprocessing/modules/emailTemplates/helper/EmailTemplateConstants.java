package com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper;

public class EmailTemplateConstants {
	public static final String UPDATE_ERROR = "An error occurred while updating the email template.";
	
	public static final String NEW_SUBSCRIPTION_LABEL = "New Subscription";
	public static final String SUBSCRIPTION_CHANGE_LABEL = "Subscription Change";
	public static final String SUBSCRIPTION_CANCELLED_LABEL = "Subscription Cancelled";
	public static final String SUBSCRIPTION_TERM_END_LABEL = "Subscription Term End";
	public static final String SUBSCRIPTION_TERM_END_EMAIL = "Subscription Term End Email";
	public static final String SUBSCRIPTION_PERIOD_END_EMAIL = "Subscription Period End Email";
	public static final String SUBSCRIPTION_EXPIRED_LABEL = "Subscription Expired";
	public static final String SUBSCRIPTION_EXPIRED_FOR_NON_PAYMENT_LABEL = "Subscription Expired for Non-payment";
	public static final String TRIAL_ENDING_LABEL = "Trial Ending";
	
	public static final String NEW_INVOICE_LABEL = "New Invoice";
	
	public static final String NEW_SUBSCRIPTION = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Thank you for subscribing.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Your subscriptions are now active and will automatically renew. Subscriptions in trial will be billed when the trial ends on their renewal date.\r\n" + 
			"              </p>\r\n" + 
			"              \r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us." +
			"              </p>\r\n" + 
			"              <p>\r\n" + 
			"              </p>\r\n" + 
			"              \r\n" + 
			"\r\n" + 
			"              <p style=\"margin-bottom:0px\">\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"                <br>\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"</body></html>";
	
	public static final String SUBSCRIPTION_CHANGE = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your subscription has been updated.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                This email confirms a recent change to your subscription.\r\n" + 
			"                \r\n" + 
			"                \r\n" + 
			"                \r\n" + 
			"                 You received a prorated credit that has been applied to this invoice. Any remaining credit will automatically be applied to your next invoice.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              \r\n" + 
			"              <p>\r\n" + 
			"                Please contact us to make payment arrangements.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"              \r\n" + 
			"            </div>\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String SUBSCRIPTION_CANCELLED = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your subscription has been canceled.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                We're sorry to see you go, but we thank you for giving us a try.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"               If you didn't mean to cancel or wish to continue your subscription, you can reactivate your subscription at any time.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us." + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String SUBSCRIPTION_EXPIRED = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your subscription has expired.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                We're sorry to see you go, but we thank you for giving us a try. This email confirms that your subscription is now expired.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us."+ 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String SUBSCRIPTION_EXPIRED_FOR_NON_PAYMENT = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" +  
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your subscription has expired.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                We're having trouble processing your payment." +
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Until we are able to resolve this issue, your subscription has been expired. Please update your billing information to resume your subscription.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us." + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String TRIAL_ENDING = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Amazon\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your trial is about to expire.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                If you do not provide a payment method before your trial ends, your subscription will expire.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us." +
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String RENEWAL_REMINDER = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Company\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your subscription is about to renew.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p>\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String SEPA_RENEWAL_REMINDER = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Company\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"\r\n" + 
			"<table id=\"account-info\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#F3F3F3\" style=\"border-top: 3px solid #CCCCCC;border-bottom: 3px solid #CCCCCC;\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td>\r\n" + 
			"            <p style=\"font-size: 12px;\">\r\n" + 
			"            <strong></strong><br>\r\n" + 
			"             </p>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td>\r\n" + 
			"            <h1 style=\"font-size:20px;\">Your upcoming subscription renewal - SEPA Payment.</h1>\r\n" + 
			"\r\n" + 
			"            <p style=\"font-size:14px\">\r\n" + 
			"              If you have any questions, please contact us at <a href=\"mailto:alpeshsonar@gmail.com\">alpeshsonar@gmail.com</a>.\r\n" + 
			"            </p>\r\n" + 
			"            \r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String CREDIT_CARD_EXPIRED = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Company\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"\r\n" + 
			"<table id=\"account-info\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#F3F3F3\" style=\"border-top: 3px solid #CCCCCC;border-bottom: 3px solid #CCCCCC;\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td>\r\n" + 
			"            <p style=\"font-size: 12px;\">\r\n" + 
			"            <strong></strong><br>\r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td>\r\n" + 
			"            <h1 style=\"font-size:20px;\">Your card on file has expired.</h1>\r\n" + 
			"\r\n" + 
			"            <p style=\"font-size:14px\">\r\n" + 
			"              To avoid any interruption, please update your billing information.\r\n" + 
			"            </p>\r\n" + 
			"\r\n" + 
			"            <p style=\"font-size:14px\">\r\n" + 
			"            If you have any questions, please contact us.\r\n" + 
			"            </p>\r\n" + 
			"            \r\n" + 
			"          </td>\r\n" + 
			"        </tr>\r\n" + 
			"      </tbody></table>\r\n" + 
			"    </td>\r\n" + 
			"  </tr>\r\n" + 
			"</tbody></table>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String NEW_INVOICE = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Amazon\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">You have a new invoice.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                Please contact us at <a href=\"mailto:alpeshsonar@gmail.com\">alpeshsonar@gmail.com</a> to make payment arrangements.\r\n" + 
			"              </p>\r\n" + 
			"\r\n" + 
			"              <p style=\"margin-bottom:0px\">\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"         </td>\r\n" + 
			"        </tr></tbody>\r\n" + 
			"  	   </table>\r\n" +
			"    </td>\r\n" + 
			"  </tr></tbody>\r\n" + 
			"</table>\r\n" +
			"\r\n" + 
			"</body></html>";
	
	public static final String NEW_CREDIT_INVOICE = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Amazon\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">You have a new credit.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                The credit will automatically be applied to your next invoice.\r\n" + 
			"              </p>\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us.\r\n" + 
			"              </p>" +
			"              <p style=\"margin-bottom:0px\">\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"         </td>\r\n" + 
			"        </tr></tbody>\r\n" + 
			"  	   </table>\r\n" +
			"    </td>\r\n" + 
			"  </tr></tbody>\r\n" + 
			"</table>\r\n" +
			"\r\n" + 
			"</body></html>";
	
	public static final String PAYMENT_CONFIRMATION = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Amazon\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Thank you for your payment.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                This email confirms your recent payment.\r\n" + 
			"              </p>\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us.\r\n" + 
			"              </p>" +
			"              <p style=\"margin-bottom:0px\">\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" + 
			"         </td>\r\n" + 
			"        </tr></tbody>\r\n" + 
			"  	   </table>\r\n" +
			"    </td>\r\n" + 
			"  </tr></tbody>\r\n" + 
			"</table>\r\n" +
			"\r\n" + 
			"</body></html>";
	
	public static final String PAYMENT_REFUNDED = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Amazon\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"  <tbody><tr>\r\n" + 
			"    <td valign=\"top\" align=\"center\" style=\"padding:0px\">\r\n" + 
			"      <table width=\"600\" cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\r\n" + 
			"        <tbody><tr>\r\n" + 
			"          <td align=\"left\" style=\"padding:0px 50px\">\r\n" + 
			"            <h1 style=\"font-size:16px;line-height:19px;color:#545457;margin-top:0px;margin-bottom:20px;\">Your purchase has been refunded.</h1>\r\n" + 
			"            <div style=\"font-size:13px;line-height:17px;color:#38383A;\">\r\n" + 
			"              <p>\r\n" + 
			"                This refund should appear on your bank statement in 3-5 business days.\r\n" + 
			"              </p>\r\n" + 
			"              <p>\r\n" + 
			"                If you have any questions, please contact us.\r\n" + 
			"              </p>" +
			"              <p style=\"margin-bottom:0px\">\r\n" + 
			"                Thank you,<br>\r\n" + 
			"                Company\r\n" + 
			"              </p>\r\n" + 
			"            </div>\r\n" +
			"         </td>\r\n" + 
			"        </tr></tbody>\r\n" + 
			"  	   </table>\r\n" +
			"    </td>\r\n" + 
			"  </tr></tbody>\r\n" + 
			"</table>\r\n" +
			"\r\n" + 
			"</body></html>";
	
	public static final String EMAIL_HEADER = "\r\n" + 
			"<!DOCTYPE html><html lang=\"en\"><head>\r\n" + 
			"        <meta charset=\"utf-8\">\r\n" + 
			"        <title>Company</title>\r\n" + 
			"        <style type=\"text/css\">\r\n" + 
			"            h1, h2, td, p {\r\n" + 
			"              font-family: helvetica, arial, sans-serif;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"            p {\r\n" + 
			"              margin:0; padding:0; margin-bottom:14px;\r\n" + 
			"            }\r\n" + 
			"            a {\r\n" + 
			"              color: #2676A5;\r\n" + 
			"            }\r\n" + 
			"        </style>\r\n" + 
			"    </head>\r\n" + 
			"    <body style=\"padding: 0; margin: 0;\">\r\n" + 
			"        \r\n" + 
			"        <table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\">\r\n" + 
			"            <tbody><tr>\r\n" + 
			"                <td valign=\"top\" align=\"center\" style=\"margin: 0; padding: 0 0 50px 0;\">\r\n" + 
			"                    \r\n" + 
			"                    <table width=\"600\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
			"                        <tbody><tr>\r\n" + 
			"                            <td style=\"padding: 0 50px;\">\r\n" + 
			"                                <h1 style=\"font-family:helvetica, arial, sans-serif; font-size:28px; line-height: 34px; padding: 30px 0; margin: 0; border-bottom: 1px solid #E8E8E9;\">\r\n" + 
			"                                    <a href=\"http://www.baseurl.com\" title=\"Company\" style=\"text-decoration:none; color:#545457;\">Company</a>\r\n" + 
			"                                </h1>\r\n" + 
			"                            </td>\r\n" + 
			"                        </tr>\r\n" + 
			"                    </tbody></table>\r\n" + 
			"                    \r\n" + 
			"                </td>\r\n" + 
			"            </tr>\r\n" + 
			"        </tbody></table>\r\n" + 
			"        \r\n" + 
			"\r\n" + 
			"</body></html>";
	
	public static final String EMAIL_FOOTER = "</body></html>";
	
	public static final String UPDATED_SUCCESS="Email Template Updated Sucessfully";

}
