package com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.repository;

import java.util.HashMap;
import java.util.Map;

import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
// import com.jio.subscriptionengine.batchprocessing.modules.bean.EmailProcessor;
import com.jio.subscriptionengine.batchprocessing.modules.bean.EmailTemplate;

public class EmailTemplateRepository {
	
	public EmailTemplateRepository() {
		
	}
	
	/**
	 * @param session
	 * @param emailTemplate
	 * @param siteId
	 * @throws Exception
	 */
	public void addEmailTemplate(Session session, EmailTemplate emailTemplate, String siteId) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		session.save(emailTemplate);
	}
	
	/**
	 * @param session
	 * @param siteId
	 * @return
	 * @throws ElasticSearchException
	 */
	public SearchResult<EmailTemplate> getAllEmailTemplates(Session session, String siteId) throws ElasticSearchException {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		Map<String, String> filter = new HashMap<>();
		filter.put("siteId", siteId);
		
		SearchResult<EmailTemplate> result = session.get(EmailTemplate.class, filter);
		return result;
	}
	
	/**
	 * @param session
	 * @param id
	 * @return
	 * @throws ElasticSearchException
	 */
	public EmailTemplate getEmailTemplateById(Session session, String id) throws ElasticSearchException {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		return session.getObject(EmailTemplate.class, id);
	}
	
	/**
	 * @param session
	 * @param label
	 * @param siteId
	 * @return
	 * @throws ElasticSearchException
	 */
	public EmailTemplate getEmailTemplateByLabel(Session session, String label, String siteId) throws ElasticSearchException {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		Map<String, String> filter = new HashMap<>();
		filter.put("label", label);
		filter.put("siteId", siteId);
		
		return session.getObject(EmailTemplate.class, filter);
	}
	
	/**
	 * @param session
	 * @param emailTemplate
	 * @throws Exception
	 */
	public void deleteEmailTemplate(Session session, EmailTemplate emailTemplate) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		session.delete(emailTemplate);
	}
	
	/**
	 * @param session
	 * @param id
	 */
	public void deleteEmailTemplateMapping(Session session, String id) {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		// session.deleteEntityMapping(EmailTemplate.class, EmailProcessor.class, id);
	}
	
	/**
	 * @param session
	 * @param emailTemplate
	 * @throws Exception
	 */
	public void mergeEmailTemplate(Session session, EmailTemplate emailTemplate) throws Exception {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		session.merge(emailTemplate);
	}

}
