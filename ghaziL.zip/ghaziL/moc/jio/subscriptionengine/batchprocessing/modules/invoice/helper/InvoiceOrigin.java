package com.jio.subscriptionengine.batchprocessing.modules.invoice.helper;

/**
 * @author Samrudhi.Gandhe
 *
 */
public enum InvoiceOrigin {

	PURCHASE("Purchase"),
	RENEWING("Renewing");
	
	private String value;  

	private InvoiceOrigin(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
}
