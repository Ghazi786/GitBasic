package com.jio.subscriptionengine.batchprocessing.modules.invoice.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.elastic.search.exception.ElasticSearchException;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.utils.RequestToBeanMapper;
import com.stripe.model.Customer;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class CustomerPaymentHandler extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6635307900557292222L;

	private final InvoiceService invoiceService = new InvoiceService();

	@Override
	protected void service(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final String planId = req.getParameter(SubscriptionConstants.PLAN_ID);
		final String subscriberId = RequestToBeanMapper.getSubscriberId(req);

		try {

			if (planId == null) {
				resp.getWriter().write("planId is Null");
				resp.setStatus(200);
				resp.flushBuffer();
				return;
			}

			final BaseResponse<Customer> response = invoiceService.getInvoiceList(planId, subscriberId);

			final ObjectNode resJson = JsonNodeFactory.instance.objectNode();
			resJson.putPOJO("appData", response);

			resp.getWriter().write(resJson.toString());
			resp.setStatus(200);
			resp.flushBuffer();


		} catch (final ElasticSearchException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}

	}

}
