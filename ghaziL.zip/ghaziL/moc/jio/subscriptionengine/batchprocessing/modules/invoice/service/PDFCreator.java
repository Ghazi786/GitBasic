package com.jio.subscriptionengine.batchprocessing.modules.invoice.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;
import com.jio.subscriptionengine.batchprocessing.modules.bean.AddOn;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;

public class PDFCreator {

	private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
	private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

	private static void addBackgrounMaskImage(Document pdfDocument)
			throws MalformedURLException, IOException, DocumentException {
		String imageFile = "../assets/Mask1.png";
		String jioLogo = "../assets/Mask2.png";
		File maskFile = new File(imageFile);
		//System.out.println(maskFile.exists());
		if (!maskFile.exists()) {
			imageFile = "./assets/Mask1.png";
			jioLogo = "./assets/Mask2.png";
		}
		maskFile = new File(imageFile);

		if (maskFile.exists()) {
			Image img = Image.getInstance(imageFile);
			img.setAbsolutePosition(200, 0);

			Image imgjioLogo = Image.getInstance(jioLogo);
			pdfDocument.add(imgjioLogo);
			pdfDocument.add(img);
		}

	}

	private static void addSubjectContent(Document pdfDocument, Invoice invoice) throws DocumentException {

		Paragraph preface = new Paragraph();

		addEmptyLine(preface, 1);
		preface.add(new Paragraph("Invoice - " + invoice.getInvoiceId(), catFont));

		addEmptyLine(preface, 1);
		preface.add(new Paragraph("Name : " + invoice.getName(), smallBold));

		addEmptyLine(preface, 1);
		preface.add(new Paragraph("Address : " + invoice.getBillingAddress().getAddress1(), smallBold));

		addEmptyLine(preface, 1);
		preface.add(new Paragraph("Phone Number : " + invoice.getBillingAddress().getPhone(), smallBold));

		addEmptyLine(preface, 1);
		preface.add(new Paragraph("Billing Date : " + new Date(), smallBold));

		addEmptyLine(preface, 1);
		preface.add(new Paragraph("Invoice Date : " + invoice.getCreatedBy(), smallBold));

		pdfDocument.add(preface);

		Chunk linebreak = new Chunk(new DottedLineSeparator());
		pdfDocument.add(linebreak);

	}

	private static void addMainContent(Document pdfDocument, Invoice invoice, Plan plan) throws DocumentException {

		Paragraph preface = new Paragraph("Billing Details : ");

		float[] columnWidths = { 5, 2, 2 };
		PdfPTable table = new PdfPTable(columnWidths);
		table.setWidthPercentage(100);

		PdfPCell c1 = new PdfPCell(new Phrase("Plan Details "));
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Amount"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Total"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		table.setHeaderRows(1);

		String planDetails = "";

		if (plan.getName() != null) {
			planDetails = plan.getName();
		}

		if (invoice.getDescription() != null) {
			planDetails = planDetails + "\r\n" + invoice.getDescription();
		}

		table.addCell(planDetails);

		String totalSub = "";

		if (invoice.getSubTotal() != null) {
			totalSub = String.valueOf(invoice.getSubTotal().getUnitAmount());
		}

		c1 = new PdfPCell(new Phrase(totalSub));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase(totalSub));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		addEmptyLine(preface, 1);
		pdfDocument.add(preface);
		addEmptyLine(preface, 2);
		table.setSpacingBefore(15);

		pdfDocument.add(table);

	}

	private static void addEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(""));
		}
	}

	public File createPDFFile(Invoice invoice, Plan plan) {
		Rectangle pageSize = new Rectangle(600, 900);
		pageSize.setBackgroundColor(new BaseColor(242, 243, 253));
		Document pdfDocument = new Document(pageSize);
		File file = null;
		try {
			String path = InvoiceUtility.getInstance().getInvoicePath(invoice.getSubscriberId(), invoice.getPlanId(),
					invoice.getSubscriptionSubscriberId());
			file = new File(path + invoice.getInvoiceId() + ".pdf");
			PdfWriter.getInstance(pdfDocument, new FileOutputStream(file));
			pdfDocument.open();
			addBackgrounMaskImage(pdfDocument);
			pdfDocument.addTitle("Invoice-" + invoice.getInvoiceId());
			pdfDocument.addAuthor("Jio Marketplace Admin");
			pdfDocument.addCreator("Jio Marketplace Admin");
			addSubjectContent(pdfDocument, invoice);
			addMainContent(pdfDocument, invoice, plan);
			if (plan.getAddOns() != null && !plan.getAddOns().isEmpty()) {
				addAddOnContent(pdfDocument, plan.getAddOns());
			}
			pdfDocument.close();
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		}
		return file;
	}

	private void addAddOnContent(Document pdfDocument, List<AddOn> addOns) throws DocumentException {

		Paragraph preface = new Paragraph("Add On Details : ");

		float[] columnWidths = { 5, 2, 2 };
		PdfPTable table = new PdfPTable(columnWidths);
		table.setWidthPercentage(100);

		PdfPCell c1 = new PdfPCell(new Phrase("AddOn Detail "));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Amount"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Total"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		table.setHeaderRows(1);

		Iterator<AddOn> addOnlist = addOns.iterator();

		while (addOnlist.hasNext()) {
			AddOn addOn = (AddOn) addOnlist.next();
			table.addCell(addOn.getName() + "\r\n" + addOn.getAddOnCode());
			table.addCell(String.valueOf(addOn.getCurrencies().getUnitAmount()));
			table.addCell(String.valueOf(addOn.getCurrencies().getUnitAmount()));
		}

		addEmptyLine(preface, 1);
		pdfDocument.add(preface);
		addEmptyLine(preface, 2);
		table.setSpacingBefore(15);

		pdfDocument.add(table);

	}

}
