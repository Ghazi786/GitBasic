package com.jio.subscriptionengine.batchprocessing.modules.invoice.service;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.time.DateUtils;

import com.elastic.search.enums.Levels;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.blockchain.sdk.util.UniqueUUIDGenerator;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Address;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.helper.InvoiceOrigin;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.helper.InvoiceStatus;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.repository.InvoiceRepository;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.constants.ReviewConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscriptionDetailsHelperService;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Customer;

/**
 * this class provides services for generating invoice, create invoice pdf and
 * associate invoice with subscriber subscription
 * 
 * @author Kiran.Jangid
 *
 */

public class InvoiceService {

	public BaseResponse<Map<String, String>> addInvoice(final Invoice invoice) throws Exception {

		associateInvoiceToSubscriber(invoice);

		final BaseResponse<Map<String, String>> baseResponse = new BaseResponse<>();
		final Map<String, String> responseData = new HashMap<>();
		baseResponse.setData(responseData);
		baseResponse.setMessage(ReviewConstants.ACCEPTED);
		baseResponse.setStatus(202);

		return baseResponse;

	}

	/**
	 * This class define service to get invoice data for particular subscription id
	 * 
	 * @param customerId
	 * @param planId
	 * @param invoiceId
	 * @return
	 * @throws ElasticSearchException
	 */

	public Invoice getInvoiceOfCustomer(final String customerId, final String planId, final String invoiceId)
			throws ElasticSearchException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		return InvoiceRepository.getInstance().getInvoiceOfCustomerAsPerPlan(session, invoiceId);

	}

	public File createInvoiceFile(final Invoice invoice, final Plan plan) {
		final PDFCreator creator = new PDFCreator();
		return creator.createPDFFile(invoice, plan);
	}

	public BaseResponse<Customer> getInvoiceList(final String planId, final String subscriberId)
			throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		Stripe.apiKey = "sk_test_51Mqb3zSEux284pDqk3y45XMoX9XSzodgfBKfKdUe9O4ysAIZLkFyz4WNoTL8ZLEToCbdzSaaCjFoLvVaRnz3l8mN00PgMkrAzw";

		Map<String, Object> params = new HashMap<>();
		params.put(
		  "description",
		  "My First Test Customer (created for API docs at https://www.stripe.com/docs/api)"
		);
		params.put("email", "ghazi@gmail.com");

		Customer customer=null;
		try {
			customer = Customer.create(params);
		} catch (StripeException e) {
			e.printStackTrace();
		}
		return new BaseResponse<Customer>(customer);
	}

	/**
	 * This method will associate invoice with subscriber subscriptions
	 * 
	 * @param invoice
	 * @return
	 * 
	 * @author Kiran.Jangid
	 */

	public boolean associateInvoiceToSubscriber(final Invoice invoice) {

		final SessionFactory factory = SessionFactory.getSessionFactory();

		final Session session = factory.getSession();

		session.setSearchLevel(Levels.NONE);

		try {
			InvoiceRepository.getInstance().addInvoice(session, invoice);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			return false;
		}

		return true;
	}

	/**
	 * this method will create invoice data for particular Subscription subscribed
	 * by customer or subscriber
	 * 
	 * @param subscriptionData
	 * @return true or false
	 * 
	 * @author Kiran.Jangid
	 */

	public Invoice createPlanInvoice(final SubscriberSubscription subscriptionData) {

		final Plan plan = subscriptionData.getPlan();
		final Invoice invoice = getInvoice(subscriptionData);
		final Currency totalAmount = new SubscriptionDetailsHelperService().calculateBillingAmount(plan, subscriptionData.getQnt(), 1);
		invoice.setSubTotal(totalAmount);
		subscriptionData.setId(UniqueUUIDGenerator.getInstance().getUniqueUUID());
		//associateInvoiceToSubscriber(invoice);
		return invoice;
	}

	/**
	 * This method will generate invoice number
	 * 
	 * @return
	 * 
	 * @author Kiran.Jangid
	 */

	private String generateInvoiceID() {
		return UUID.randomUUID().toString();
	}

	/**
	 * @param subscriptionData
	 * @return
	 * @author Samrudhi.Gandhe
	 */
	public Invoice getInvoice(final SubscriberSubscription subscriptionData) {
		final Invoice invoice = new Invoice();

		final Plan plan = subscriptionData.getPlan();
		// set created by
		final String subscriberId = subscriptionData.getSubscriberId();
		invoice.setCreatedBy(subscriberId);
		invoice.setPostedOn(new Date());
		
		// set invoice id assuming invoice id and number are same
		invoice.setInvoiceId(generateInvoiceID());

		// set invoice origin
		invoice.setInvoiceOrigin(InvoiceOrigin.PURCHASE.getValue());

		// set subscriber name
		final Subscriber subscriber = subscriptionData.getSubscriber();
		final String firstName = subscriber.getFirstName();
		final String lastName = subscriber.getLastName();
		invoice.setName(firstName + " " + lastName);

		// set billing address
		final Address address = subscriber.getAddress();
		invoice.setBillingAddress(address);

		// set invoice creation date
		invoice.setCreatedOn(new Date());

		// set invoice order date or due date
		invoice.setDueOn(DateUtils.addDays(new Date(),1));

		// set payment status
		invoice.setStatus(InvoiceStatus.PENDING.getValue());
		invoice.setQnt(subscriptionData.getQnt());

		// set subscriber subscription id
		invoice.setSubscriptionSubscriberId(subscriptionData.getId());

		// set subscriber id
		invoice.setSubscriberId(subscriberId);

		// set plan id
		invoice.setPlanId(plan.getId());
		
		invoice.setDescription(plan.getName());
		invoice.setSiteId(plan.getSiteId());

		return invoice;
		
	}

	/**
	 * @param subscriptionData
	 * @return
	 * @author Samrudhi.Gandhe
	 */
	public Invoice createSetupFeeInvoice(final SubscriberSubscription subscriptionData) {

		final Plan plan = subscriptionData.getPlan();
		
		final double amount = plan.getSetupFeeAttributes().getUnitAmount();
		if(amount > 0) {
			final Invoice invoice = getInvoice(subscriptionData);
			invoice.setDescription("Setup Fee: "+plan.getName());
			invoice.setSubTotal(plan.getSetupFeeAttributes());
			invoice.setPrice(plan.getSetupFeeAttributes());
			invoice.setInvoiceOrigin(InvoiceOrigin.PURCHASE.getValue());
			invoice.setQnt(1);
			invoice.setId(UniqueUUIDGenerator.getInstance().getUniqueUUID());
			//associateInvoiceToSubscriber(invoice);
			
		return invoice;
		}
		return null;

	}
	/**
	 * @param subscriptionData
	 * @return
	 * @author Nageswar.Nandyala
	 */
	public boolean createRenewFeeInvoice(final SubscriberSubscription subscriptionData) {
		final Invoice invoice = getInvoice(subscriptionData);
		final Plan plan = subscriptionData.getPlan();
		invoice.setDescription("Renew Fee : " + plan.getName());
		invoice.setSubTotal(subscriptionData.getPricePerBillingPeriod());
		invoice.setPrice(subscriptionData.getPricePerBillingPeriod());
		invoice.setInvoiceOrigin(InvoiceOrigin.RENEWING.toString());
		invoice.setQnt(subscriptionData.getQnt());
		return associateInvoiceToSubscriber(invoice);
		
	}
	
	
}
