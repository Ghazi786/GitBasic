package com.jio.subscriptionengine.batchprocessing.modules.invoice.controller;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceUtility;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;
import com.jio.subscriptionengine.batchprocessing.utils.MarketplaceCommonMethod;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class InvoiceDownloadHandler extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6635307900557292222L;

	private final InvoiceService invoiceService = new InvoiceService();

	@Override
	protected void service(final HttpServletRequest req, final HttpServletResponse resp)
			throws ServletException, IOException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final String invoiceId = req.getParameter(SubscriptionConstants.SUBSCRIPTION_ID);

		try {

			Invoice invoiceData = invoiceService.getInvoiceOfCustomer(null, null, invoiceId);

			SubscriptionService subService = new SubscriptionService();
			SubscriberSubscription subCr = subService.getSubscription(null, invoiceData.getSubscriptionSubscriberId());

			Plan plan = subCr.getPlan();

			String path = InvoiceUtility.getInstance().getInvoicePath(invoiceData.getSubscriberId(),
					invoiceData.getPlanId(), invoiceData.getSubscriptionSubscriberId());

			File file = new File(path + invoiceData.getInvoiceId() + ".pdf");

			if (!file.exists()) {
				file = invoiceService.createInvoiceFile(invoiceData, plan);
			}

			MarketplaceCommonMethod.sendFileStreamAsResponse(resp, file, 200, null, null);

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			e.printStackTrace();
			resp.sendError(500, "Internal Service Error");
		}

	}

}
