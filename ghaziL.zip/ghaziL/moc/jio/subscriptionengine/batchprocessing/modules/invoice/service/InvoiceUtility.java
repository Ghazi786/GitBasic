package com.jio.subscriptionengine.batchprocessing.modules.invoice.service;

import java.io.File;

/**
 * This class is used to configuration
 * 
 * @author Kiran.Jangid
 *
 */

public class InvoiceUtility {

	private static InvoiceUtility invoiceUtility = new InvoiceUtility();

	private InvoiceUtility() {

	}

	public static InvoiceUtility getInstance() {
		if (invoiceUtility == null) {
			invoiceUtility = new InvoiceUtility();
		}
		return invoiceUtility;
	}
	
	public String getInvoicePath(String subscriberId, String planId, String subscriptionId) {
		
		String path = "./invoice/" + subscriberId + "/" + planId + "/" + subscriptionId + "/";
		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
		}
		
		return path;
		
	}

}
