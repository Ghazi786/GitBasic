package com.jio.subscriptionengine.batchprocessing.modules.invoice.helper;

/**
 * @author Samrudhi.Gandhe
 *
 */
public enum InvoiceStatus {
	
	PAID("Paid"),
	PENDING("Pending"),
	FAILED("Failed"),
	CLOSED("Closed");
	
	private String value;  

	private InvoiceStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
