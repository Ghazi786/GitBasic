package com.jio.subscriptionengine.batchprocessing.modules.invoice.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.controller.CustomerPayment;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.constants.ReviewConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;

/**
 * This Class is used to operate payment related operations. Methods
 * addPayment(), getPaymentHistoryOfCustomer(), change invoice status to payment
 * done.
 * 
 * @author Kiran.Jangid
 *
 */

public class InvoiceRepository {

	private static InvoiceRepository paymentRepository = new InvoiceRepository();

	private InvoiceRepository() {

	}

	public static InvoiceRepository getInstance() {
		return paymentRepository;
	}

	/**
	 * 
	 * @param session
	 * @param payment
	 * @throws Exception
	 */

	public void addPayment(Session session, CustomerPayment payment) throws Exception {

		try {
			session.beginTransaction();
			session.save(payment);
		} catch (ElasticSearchException e) {

			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString())
					.writeLog();

		} finally {
			session.close();
		}

	}

	public SearchResult<CustomerPayment> getPaymentHistoryOfCustomer(Session session, String customerId)
			throws ElasticSearchException {
		Map<String, String> filters = new HashMap<>();
		filters.put("customerId", customerId);
		return session.get(CustomerPayment.class, filters);
	}

	public void updatePaymentStatus(Session session, String id, String status) {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			session.beginTransaction();
			CustomerPayment customerPayment = session.getObject(CustomerPayment.class, id);
			customerPayment.setPaymentStatus(status);
			session.merge(customerPayment);
		} catch (Exception e) {
			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString())
					.writeLog();
		} finally {
			session.close();
		}
	}

	public Invoice getInvoiceOfCustomerAsPerPlan(Session session, String id) throws ElasticSearchException {
		Invoice invoice = session.getObject(Invoice.class, id);
		return invoice;
	}

	public void addInvoice(Session session, Invoice invoice) {
		try {
			session.beginTransaction();
			session.save(invoice);
		} catch (ElasticSearchException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString())
					.writeLog();
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		} finally {
			session.close();
		}
	}

	public SearchResult<Invoice> getInvoiceByPlanId(Session session, String planId, String subscriberId)
			throws ElasticSearchException {
		Map<String, String> filters = new HashMap<>();
		filters.put(SubscriptionConstants.PLAN_ID, planId);
		filters.put(SubscriptionConstants.SUBSCRIBER_ID, subscriberId);
		return session.get(Invoice.class, filters);
	}
	
	public void bulkAddInvoice(Session session, List<Invoice> invoice) {
		try {
			session.bulk(invoice,false);
		} catch (ElasticSearchException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString())
					.writeLog();
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		} finally {
			session.close();
		}
	}

}
