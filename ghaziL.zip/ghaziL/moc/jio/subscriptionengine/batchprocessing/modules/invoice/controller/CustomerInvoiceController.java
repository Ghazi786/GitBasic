package com.jio.subscriptionengine.batchprocessing.modules.invoice.controller;

import java.io.File;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.exception.ElasticSearchException;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherServletBaseHandler;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.countermanager.CounterNameEnum;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.exceptions.InvalidRequestParamValueException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceUtility;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.constants.ReviewConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;
import com.jio.subscriptionengine.batchprocessing.utils.MarketplaceCommonMethod;
import com.jio.subscriptionengine.batchprocessing.utils.RequestToBeanMapper;

/**
 * The Class is for Subscriber Payment Controller. where we define api of
 * payment, invoice and receipt
 * 
 * @author Kiran.Jangid
 * 
 */

@Controller
@RequestMapping(name = "/invoices")
public class CustomerInvoiceController extends DispatcherServletBaseHandler implements DispatcherBaseController {

	private static final long serialVersionUID = 1L;

	private final InvoiceService invoiceService = new InvoiceService();

	@EventName("STRIPE_CREATE_CUSTOMER")
	@RequestMapping(name = "/invoice-list", type = HttpRequestMethod.POST)
	public BaseResponse<?> getInvoiceList(HttpServletRequest req, HttpServletResponse resp)
			throws InvalidRequestParamValueException, ElasticSearchException {
		CounterNameEnum.CNTR_VIEW_INVOICE_LIST_REQUEST.increment();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final String planId = req.getParameter(SubscriptionConstants.PLAN_ID);
		final String subscriberId = RequestToBeanMapper.getSubscriberId(req);

		final BaseResponse<?> response = invoiceService.getInvoiceList(planId, subscriberId);

		return response;
	}

	@EventName("GET_INVOICE")
	@RequestMapping(name = "/invoice", type = HttpRequestMethod.GET)
	public void getSubscriberPlansById(HttpServletRequest req, HttpServletResponse resp)
			throws ElasticSearchException, BaseException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final String invoiceId = req.getParameter(SubscriptionConstants.SUBSCRIPTION_ID);
		
		CounterNameEnum.CNTR_INVOICE_DOWNLOAD_REQUEST.increment();

		try {

			Invoice invoiceData = invoiceService.getInvoiceOfCustomer(null, null, invoiceId);

			SubscriptionService subService = new SubscriptionService();
			SubscriberSubscription subCr = subService.getSubscription(null, invoiceData.getSubscriptionSubscriberId());

			Plan plan = subCr.getPlan();

			String path = InvoiceUtility.getInstance().getInvoicePath(invoiceData.getSubscriberId(),
					invoiceData.getPlanId(), invoiceData.getSubscriptionSubscriberId());

			File file = new File(path + invoiceData.getInvoiceId() + ".pdf");

			if (!file.exists()) {
				file = invoiceService.createInvoiceFile(invoiceData, plan);
			}

			MarketplaceCommonMethod.sendFileStreamAsResponse(resp, file, 200, null, null);

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw e;
		}

	}

	@EventName("ADD_INVOICE")
	@RequestMapping(name = "/add-invoice", type = HttpRequestMethod.POST)
	public BaseResponse<?> addInvoice(final HttpServletRequest req, final HttpServletResponse resp) throws Exception {

		BaseResponse<Map<String, String>> response = null;

		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(),
				ReviewConstants.POST_REVIEW).writeLog();

		Invoice invoice = RequestToBeanMapper.getBeanFromRequest(req, Invoice.class);

		if (invoice == null) {
			throw new BaseException(HttpStatus.BAD_REQUEST_400, ReviewConstants.POST_REVIEW__FAILURE);
		}

		response = invoiceService.addInvoice(invoice);

		return response;

	}

}
