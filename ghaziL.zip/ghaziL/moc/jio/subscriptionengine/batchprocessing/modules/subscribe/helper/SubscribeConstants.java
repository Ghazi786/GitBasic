package com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper;

/**
 * @author Samrudhi.Gandhe
 *
 */
public class SubscribeConstants {

	private SubscribeConstants() {
	}

	public static final String NON_AUTOMATIC = "Non-Automatic";
	public static final String AUTOMATIC = "Automatic";
	public static final String NON_AUTO_RENEW = "Non-Auto-renew";
	public static final String AUTO_RENEW = "Auto-Renew";
	public static final String PLAN_SUBSCRIPTION_FAILURE = "Error Occured while adding plan subscription";
	public static final String SUBSCRIBER_ID = "subscriberId";
	public static final String PLAN_ID = "plan.id";
}
