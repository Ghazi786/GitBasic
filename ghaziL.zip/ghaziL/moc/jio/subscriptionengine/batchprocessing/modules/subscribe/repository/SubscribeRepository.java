package com.jio.subscriptionengine.batchprocessing.modules.subscribe.repository;

import java.util.List;
import java.util.Map;

import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;

public class SubscribeRepository {

	/**
	 * Create subscription of plan
	 * @param session
	 * @param subscriptionDetails
	 * @throws Exception
	 */
	public void saveSubscription(Session session, SubscriberSubscription subscriptionDetails) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Executing [ "+ this.getClass().getName()+"."+ Thread.currentThread().getStackTrace()[1].getMethodName() +" ]",  this.getClass().getName(),
				Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		session.save(subscriptionDetails);
	}


	/**
	 * Checking whether subscriber subscribed to the plan or not
	 * @param session
	 * @param filters
	 * @throws ElasticSearchException
	 */
	public SearchResult<SubscriberSubscription> isSubscriptionExist(Session session,Map<String, String> filters) throws ElasticSearchException {
		
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Executing [ "+ this.getClass().getName()+"."+ Thread.currentThread().getStackTrace()[1].getMethodName() +" ]",  this.getClass().getName(),
				Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
	
		
	    SearchResult<SubscriberSubscription> result = session.get(SubscriberSubscription.class, filters);
	   
	   
	    
	    return result;
	}
	
	/**
	 * Create subscription of plan
	 * @param session
	 * @param subscriptionDetails
	 * @throws Exception
	 */
	public void saveBulkSubscription(Session session, List<SubscriberSubscription> subscriptionDetails) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Executing [ "+ this.getClass().getName()+"."+ Thread.currentThread().getStackTrace()[1].getMethodName() +" ]",  this.getClass().getName(),
				Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		session.bulk(subscriptionDetails,false);
	}

}
