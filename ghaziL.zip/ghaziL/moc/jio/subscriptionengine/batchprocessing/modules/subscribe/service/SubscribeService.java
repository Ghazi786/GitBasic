package com.jio.subscriptionengine.batchprocessing.modules.subscribe.service;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jetty.http.HttpStatus;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.metrics.ParsedValueCount;

import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.fasterxml.jackson.databind.JsonNode;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailHandler;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.plan.helper.PlanConstant;
import com.jio.subscriptionengine.batchprocessing.modules.plan.service.PlanService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscribeConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscriptionDetailsHelperService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.repository.SubscribeRepository;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.redis.RedisOperationImpl;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;

/**
 * This is service used to peform subscription of plan subscribed by user.
 * 
 * @author Samrudhi.Gandhe
 * 
 */
public class SubscribeService {

	private static SubscribeRepository subscribeRepository;
	static {
		subscribeRepository = new SubscribeRepository();
	}

	/**
	 * Create SubscriberSubscription of plan
	 * 
	 * @param planId
	 * @param subscriberId
	 * @param qnt
	 * @param requestParams
	 * @param baseEventBean
	 * @return
	 * @throws BaseException
	 * 
	 * @author Samrudhi.Gandhe
	 */
	public SubscriberSubscription subscribePlan(final String planId, final String subscriberId, final int qnt,
			final JsonNode requestParams, final BaseEventBean baseEventBean) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();

		SubscriberSubscription subscriptionDetails;

		try {

			final PlanService planService = new PlanService();
			final Plan plan = planService.getPlan(planId);
			if (plan == null) {
				throw new BaseException(HttpStatus.NOT_FOUND_404, PlanConstant.INVALID_PLAN);

			}

			final SubscriptionDetailsHelperService detailsHelperService = new SubscriptionDetailsHelperService();

			// Add Subscription of plan
			detailsHelperService.setPlanAddonsDetails(requestParams, plan);
			subscriptionDetails = detailsHelperService.getSubscriptionDetails(plan, subscriberId, qnt);

			session.beginTransaction();

			subscribeRepository.saveSubscription(session, subscriptionDetails);

			// Add Webhook Activity
			addSubscriptionWebhookActivity(baseEventBean, session, subscriptionDetails);
			// Add invoice to subscription
			final InvoiceService invoiceService = new InvoiceService();

			invoiceService.createSetupFeeInvoice(subscriptionDetails);
			if (!(plan.getTrialInterval() != null && plan.getTrialInterval().getValue() > 0)) {
				invoiceService.createPlanInvoice(subscriptionDetails);
			}

			session.flush();
			// send mail and sms to subscriber after successfully subscription
			// if (subscriptionDetails.getSubscriber().getEmail() != null) {
			// List<String> toList = new ArrayList<>();
			// toList.add(subscriptionDetails.getSubscriber().getEmail());
			// String subject = "Jio Marketplace Admin - Plan Subscribed - " +
			// plan.getName();
			// String content = generateMailBody(plan, subscriptionDetails.getSubscriber());
			// NotificationService.getInstance().sendMail(toList, null, subject, content,
			// null, null, null);
			// }

			// send email to inform user about subscription's cancellation

			final Runnable emailTask = () -> {
				try {
					EmailHandler.triggerEmail(subscriptionDetails, EmailTemplateConstants.NEW_SUBSCRIPTION_LABEL,
							subscriptionDetails.getSiteId(),
							subscriptionDetails.getPlan().getEmailSettingAttributes().isNewSubscriptionNotification(),
							null);
				} catch (Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeExceptionLog();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

		} catch (final BaseException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw e;
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500, SubscribeConstants.PLAN_SUBSCRIPTION_FAILURE);
		} finally {
			session.close();
		}

		return subscriptionDetails;

	}

	/**
	 * This method will generate mail body using plan details and subscriber details
	 * 
	 * @param plan
	 * @param subscriber
	 * @return
	 * 
	 * @author Kiran.Jangid
	 */

	private String generateMailBody(Plan plan, Subscriber subscriber) {
		String mailBody = "<p>Hi " + subscriber.getFirstName() + ",</p>\r\n"
				+ "<p>&nbsp; &nbsp; &nbsp; You are subscribed for plan - " + plan.getName() + ".</p>\r\n"
				+ "<p><span style=\"color: #ff0000;\">&nbsp; &nbsp; &nbsp; Do not reply.</span></p>\r\n"
				+ "<p>Regards</p>\r\n" + "<p>Marketplace Admin</p>";
		return mailBody;
	}

	/**
	 * pass control to the repository to check whether subscriber has subscription
	 * 
	 * @param subscriberId
	 * @param planId
	 * @return
	 */

	public boolean isSubscriptionExist(final String subscriberId, final String planId) {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final Map<String, String> filters = new HashMap<>();
		SearchResult<SubscriberSubscription> result;
		boolean isSubscriptionExist = false;

		if (subscriberId != null && !subscriberId.isEmpty()) {
			filters.put(SubscribeConstants.SUBSCRIBER_ID, subscriberId);
		}

		if (planId != null && !planId.isEmpty()) {
			filters.put(SubscribeConstants.PLAN_ID, planId);
		}
		try {
			session.beginTransaction();
			// fetch subscription details by subsciberId & planId
			result = subscribeRepository.isSubscriptionExist(session, filters);
			final long count = result.getDocumentsCount();
			if (count != 0) {
				isSubscriptionExist = true;
			}
		} catch (final ElasticSearchException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		} finally {
			session.close();
		}
		return isSubscriptionExist;

	}

	public void addSubscriptionWebhookActivity(final BaseEventBean baseEventBean, final Session session,
			final SubscriberSubscription subscriptionDetails) {
		// @formatter:off
		final Subscriber subscriberById = subscriptionDetails.getSubscriber();

		final String name = subscriberById != null ? subscriberById.getFirstName() + " " + subscriberById.getLastName()
				: Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME;

		final String siteId = subscriptionDetails.getPlan().getSiteId();

		Runnable task = () -> {
			ServiceCommunicator.triggerWebHook(baseEventBean, siteId, subscriptionDetails,
					subscriptionDetails.getCreatedBy(), SubscriptionConstants.EVENT_CREATE_SUBSCRIPTION);
		};
		BatchProcessingBootStrapper.getInstance().getThreadPoolService().submit(task);

		// @formatter:on
	}

	public void setSubscriberCountIntoRedis(String planId) {
		setSubscriberCountByPlanIntoRedis(planId, calculateSubscriptionCount(planId));
	}

	public long calculateSubscriptionCount(String planId) {
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		Map<String, Object> filters = new HashMap<>();
		filters.put("plan.id", planId);
		final AggregationBuilder aggs = AggregationBuilders.count("subscriberCount").field("plan.id.keyword");
		ParsedValueCount aggregation = null;
		try {
			aggregation = (ParsedValueCount) session.aggregation(SubscriberSubscription.class, aggs, filters);
			return aggregation.getValue();
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return 0;
	}

	public void setSubscriberCountByPlanIntoRedis(final String planId, final long value) {
		final RedisOperationImpl operationImpl = new RedisOperationImpl();
		operationImpl.setMapKeyField(PlanConstant.REDIS_SUBSCRIPTION_COUNT_KEY, planId, String.valueOf(value));
	}

}
