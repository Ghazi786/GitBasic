package com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.jio.subscriptionengine.batchprocessing.modules.accounts.service.AccountsService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.AddOn;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.IntervalUnit;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Item;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionStatusEnum;
import com.jio.subscriptionengine.batchprocessing.utils.DateUtil;

/**
 * @author Samrudhi.Gandhe
 *
 *         This is helper class to set subscription details as per business
 *         requirement
 */
public class SubscriptionDetailsHelperService {

	/**
	 * Create SubscriberSubscription info with required info
	 * 
	 * @param planId
	 * @param subscriberId
	 * @return
	 * @throws Exception
	 */
	public SubscriberSubscription getSubscriptionDetails(final Plan plan, final String subscriberId, final int qnt)
			throws Exception {

		final SubscriberSubscription subscription = new SubscriberSubscription();
		final Date currentDate = new Date();

		// get Plan by id
		final String siteId = plan.getSiteId();
		subscription.setPlan(plan);

		// set site id in SubscriberSubscription
		subscription.setSiteId(siteId);

		// get subscriber info by id
		final AccountsService accountsService = new AccountsService();
		final Subscriber subscriber = accountsService.getSubscriberById(subscriberId);

		// set subscriber
		subscription.setSubscriber(subscriber);
		// set subscriberId
		subscription.setSubscriberId(subscriber.getId());

		setSubscriptionDates(subscription);

		// calculate term Balance
		final boolean isPaymentDone = true;

		final Currency termBalance = calculateTermBalance(plan, isPaymentDone, qnt);
		subscription.setTermBalance(termBalance);

		// set termBehavior
		subscription.setTermBehavior(
				plan.isAutoRenew() ? SubscribeConstants.AUTO_RENEW : SubscribeConstants.NON_AUTO_RENEW);

		// set collectionType
		subscription.setCollectionType(
				plan.isAutoRenew() ? SubscribeConstants.AUTOMATIC : SubscribeConstants.NON_AUTOMATIC);

		// set renewsOn
		subscription.setRenewsOn(subscription.getTermEndDate());

		// set startedOn
		subscription.setStartedOn(currentDate);
		subscription.setQnt(qnt);

		// calculate nextBillingDate as per trial Info
		if (plan.getTrialInterval() != null) {
			subscription.setNextBillingDate(subscription.getPeriodStartDate());
			subscription.setRemainingBillingCount(plan.getTotalBillingCycles());
		} else if (isPaymentDone && plan.getTrialInterval() == null) {
			subscription.setNextBillingDate(subscription.getPeriodEndDate());
			subscription.setRemainingBillingCount(plan.getTotalBillingCycles() - 1);
		}

		// set pricePerBillingPeriod
		subscription.setPricePerBillingPeriod(plan.getBaseFeeAttributes());

		// set status
		subscription.setStatus(SubscriptionStatusEnum.RENEWING.getValue());

		// set createdOn, createdBy, updatedOn, updatedBy
		subscription.setCreatedOn(currentDate);
		subscription.setUpdatedOn(currentDate);
		return subscription;
	}

	/**
	 * Calculate pending term balance amount depending on trial and payment status
	 * 
	 * @param plan
	 * @param isPaymentDone
	 * @param qnt
	 * @return
	 */
	private Currency calculateTermBalance(final Plan plan, final boolean isPaymentDone, final int qnt) {

		// calculate pending amount depending on trial & paid status of invoices
		final int totalBillingCycles = plan.getTotalBillingCycles();
		final int pendingBillingCycle = isPaymentDone & plan.getTrialInterval() == null ? (totalBillingCycles - 1)
				: totalBillingCycles;
		final Currency termBalance = calculateBillingAmount(plan, qnt, pendingBillingCycle);
		return termBalance;
	}

	/**
	 * Calculate periodStartDate , periodEndDate, termStartDate, termEndDate
	 * 
	 * @param subscription
	 */
	private void setSubscriptionDates(final SubscriberSubscription subscription) {

		final Plan plan = subscription.getPlan();
		final Date currentDate = new Date();
		Date endTrialDate = null;

		// If Trial Period exists
		if (plan.getTrialInterval() != null) {
			final String trialIntervalUnit = plan.getTrialInterval().getType();
			final int trialIntervalLength = plan.getTrialInterval().getValue();
			endTrialDate = DateUtil.getDateByType(currentDate, trialIntervalUnit, trialIntervalLength);
		}
		// calculate periodStartDate , periodEndDate
		final Date periodStartDate = endTrialDate != null ? endTrialDate : currentDate;

		final IntervalUnit intervalUnit = plan.getIntervalUnit();
		final String type = intervalUnit.getType();

		final int intervalValue = intervalUnit.getValue();
		final Date periodEndDate = DateUtil.getDateByType(periodStartDate, type, intervalValue);

		subscription.setPeriodStartDate(periodStartDate);
		subscription.setTrialEndDate(periodStartDate);
		subscription.setPeriodEndDate(periodEndDate);

		// calculate termStartDate, termEndDate
		subscription.setTermStartDate(periodStartDate);

		final int termValue = intervalUnit.getValue() * plan.getTotalBillingCycles();
		final Date termEndDate = DateUtil.getDateByType(periodStartDate, type, termValue);
		subscription.setTermEndDate(termEndDate);
	}

	public void setPlanAddonsDetails(final JsonNode requestParams, final Plan plan) throws Exception {
		ArrayNode selectedItems = JsonNodeFactory.instance.arrayNode();
		ArrayNode selectedAddons = JsonNodeFactory.instance.arrayNode();
		if(requestParams != null && requestParams.hasNonNull("items")) {
			selectedItems = (ArrayNode) requestParams.get("items");
		}
		if(requestParams != null && requestParams.hasNonNull("addons")) {
			selectedAddons = (ArrayNode) requestParams.get("addons");
		}
		// @formatter:off
		if(plan.getItems() != null) {
			final Map<String, Integer> itemsCodeWithSize = getQunatityByCode(selectedItems); 
			final List<Item> items = plan.getItems().stream()
					.filter(item -> (!item.isOptionalAdOns()) || itemsCodeWithSize.containsKey(item.getItemCode()))
					.collect(Collectors.toList());
			items.stream().forEach(item -> {
				final Integer count = itemsCodeWithSize.get(item.getItemCode());
				item.setQnt(count == null || count < 1 ? 1 : count);
			});
			plan.setItems(items);
			
		}
		if(plan.getAddOns() != null) {
			final Map<String, Integer> addonCodeWithSize = getQunatityByCode(selectedAddons); 
			final List<AddOn> addOns = plan.getAddOns().stream()
					.filter(addOn -> (!addOn.isOptionalAdOns()) || addonCodeWithSize.containsKey(addOn.getAddOnCode()))
					.collect(Collectors.toList());
			addOns.stream().forEach(addOn -> {
				final Integer count = addonCodeWithSize.get(addOn.getAddOnCode());
				addOn.setQnt(count == null || count < 1 ? 1 : count);
			});
			plan.setAddOns(addOns);
			
		}
		// @formatter:on
	}

	private Map<String, Integer> getQunatityByCode(final ArrayNode items) {
		final Map<String, Integer> itemsCodeWithSize = new HashMap<String, Integer>();
		for (final JsonNode item : items) {
			final String code = item.get("code").asText();
			final int qnt = item.get("quantity").asInt(1);
			itemsCodeWithSize.put(code, qnt);
		}
		return itemsCodeWithSize;
	}

	/**
	 * @param plan
	 * @param qnt
	 * @param billingCycle
	 * @return
	 */
	public Currency calculateBillingAmount(final Plan plan, final int qnt, final int billingCycle) {
		
		final double unitAmount = plan.getBaseFeeAttributes().getUnitAmount();
		final double planTotalAmount = unitAmount * billingCycle * qnt;

		// @formatter:off
		double itemTotalAmount = 0;
		if (plan.getItems() != null) {
			itemTotalAmount = plan.getItems().stream()
					.mapToDouble(x -> x.getQnt() * x.getCurrencyAttribute().getUnitAmount() * billingCycle)
					.sum();
		}
		double addonsTotalAmount = 0;
		if (plan.getItems() != null) {
			addonsTotalAmount = plan.getAddOns().stream()
					.mapToDouble(x -> x.getQnt() * x.getCurrencies().getUnitAmount() * billingCycle).sum();
		}
		// @formatter:on

		final Currency termBalance = new Currency();
		termBalance.setCode(plan.getBaseFeeAttributes().getCode());
		termBalance.setType(plan.getBaseFeeAttributes().getType());
		termBalance.setUnitAmount(planTotalAmount + addonsTotalAmount + itemTotalAmount);
		return termBalance;
	}

}
