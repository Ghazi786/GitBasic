package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "payment_link")
@PrimaryKey({ "planId", "subscriberId", "createdOn" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentLink implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String planId;
	private String subscriberId;
	private String callbackRedirectUrl;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;
	
	private boolean active;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getCallbackRedirectUrl() {
		return callbackRedirectUrl;
	}

	public void setCallbackRedirectUrl(String callbackRedirectUrl) {
		this.callbackRedirectUrl = callbackRedirectUrl;
	}


}
