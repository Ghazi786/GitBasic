package com.jio.subscriptionengine.batchprocessing.modules.bean;
import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
@Entity(name = "wishlist")
@PrimaryKey({ "subscriberId", "planId" })
public class Wishlist implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	private String userName;
	private String subscriberId;
	private Date createdOn;
	private String description;
	private String planCode;
	private String planId;
	private String planName;
	 private Date updatedOn;
	 private Plan plan;
	 
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}



	public String getPlanCode() {
		return planCode;
	}



	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}



	public String getPlanId() {
		return planId;
	}



	public void setPlanId(String planId) {
		this.planId = planId;
	}




	public String getPlanName() {
		return planName;
	}




	public void setPlanName(String planName) {
		this.planName = planName;
	}

}
