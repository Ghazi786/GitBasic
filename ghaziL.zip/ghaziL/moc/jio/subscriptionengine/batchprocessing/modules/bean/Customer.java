package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "customer")
@PrimaryKey({ "email" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class Customer  implements Serializable{

	@Id
	private String id;

	private String name;

	private String email;

	public String getName() {
		return name;
	}

	public Customer() {
		
	}
	
	public void setName(final String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
