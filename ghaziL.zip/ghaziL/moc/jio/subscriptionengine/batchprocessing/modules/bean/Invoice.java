package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Samrudhi.Gandhe
 *
 */
@Entity(name = "invoice")
@PrimaryKey({ "subscriberId", "invoiceId", "planId" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class Invoice implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String subscriberId;

	private String siteId;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date postedOn;

	private String term;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date dueOn;

	private String status;

	// total amount
	private Currency amountPaid;

	private String description;

	private int qnt;

	private Currency price;

	private Currency subTotal;

	private boolean refund;

	private BillingInfo billingInfo;

	private String customerNotes;

	private String termsAndConditions;

	private String poNumber;

	private int netTerms;

	private String name;

	private String siteName;

	private String planId;

	private Subscriber subscriber;

	private String invoiceId;

	private String company;

	private String createdBy;

	private Site site;

	private String invoiceOrigin;

	private String subscriptionSubscriberId;
	
	private Address billingAddress;

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public String getInvoiceOrigin() {
		return invoiceOrigin;
	}

	public void setInvoiceOrigin(String invoiceOrigin) {
		this.invoiceOrigin = invoiceOrigin;
	}

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	private String updatedBy;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Subscriber getSubscriber() {
		return subscriber;
	}

	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public int getNetTerms() {
		return netTerms;
	}

	public void setNetTerms(int netTerms) {
		this.netTerms = netTerms;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public Date getPostedOn() {
		return postedOn;
	}

	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public Date getDueOn() {
		return dueOn;
	}

	public void setDueOn(Date dueOn) {
		this.dueOn = dueOn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Currency getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(Currency amountPaid) {
		this.amountPaid = amountPaid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQnt() {
		return qnt;
	}

	public void setQnt(int qnt) {
		this.qnt = qnt;
	}

	public Currency getPrice() {
		return price;
	}

	public void setPrice(Currency price) {
		this.price = price;
	}

	public Currency getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(Currency subTotal) {
		this.subTotal = subTotal;
	}

	public boolean isRefund() {
		return refund;
	}

	public void setRefund(boolean refund) {
		this.refund = refund;
	}

	public BillingInfo getBillingInfo() {
		return billingInfo;
	}

	public void setBillingInfo(BillingInfo billingInfo) {
		this.billingInfo = billingInfo;
	}

	public String getCustomerNotes() {
		return customerNotes;
	}

	public void setCustomerNotes(String customerNotes) {
		this.customerNotes = customerNotes;
	}

	public String getTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getSubscriptionSubscriberId() {
		return subscriptionSubscriberId;
	}

	public void setSubscriptionSubscriberId(String subscriptionSubscriberId) {
		this.subscriptionSubscriberId = subscriptionSubscriberId;
	}

	public Invoice() {
		super();
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

}
