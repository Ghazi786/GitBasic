package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.HashMap;
import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "email_template")
@PrimaryKey({ "label", "siteId" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailTemplate implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String siteId;
	
	private String label;
	
	private String description;
	
	private String htmlBody;
	
	private String textBody;
	
	private String fromEmailId;
	
	private String ccEmailId;
	
	private Boolean isEmailEnabled;
	
	private Boolean isHTMLEmailIncluded;

	private Boolean isReminderBeforeEachTerm;
	
	private Boolean isReminderBeforeEachBillDate;
	
	private int numberOfDaysPriorToRenewal;
	
	private String category;
	
	private String emailSubject;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHtmlBody() {
		return htmlBody;
	}

	public void setHtmlBody(String htmlBody) {
		this.htmlBody = htmlBody;
	}

	public String getTextBody() {
		return textBody;
	}

	public void setTextBody(String textBody) {
		this.textBody = textBody;
	}

	public String getFromEmailId() {
		return fromEmailId;
	}

	public void setFromEmailId(String fromEmailId) {
		this.fromEmailId = fromEmailId;
	}

	public String getCcEmailId() {
		return ccEmailId;
	}

	public void setCcEmailId(String ccEmailId) {
		this.ccEmailId = ccEmailId;
	}

	

	public Boolean getIsEmailEnabled() {
		return isEmailEnabled;
	}

	public void setIsEmailEnabled(Boolean isEmailEnabled) {
		this.isEmailEnabled = isEmailEnabled;
	}

	public int getNumberOfDaysPriorToRenewal() {
		return numberOfDaysPriorToRenewal;
	}

	public Boolean getIsHTMLEmailIncluded() {
		return isHTMLEmailIncluded;
	}

	public void setIsHTMLEmailIncluded(Boolean isHTMLEmailIncluded) {
		this.isHTMLEmailIncluded = isHTMLEmailIncluded;
	}

	public Boolean getIsReminderBeforeEachTerm() {
		return isReminderBeforeEachTerm;
	}

	public void setIsReminderBeforeEachTerm(Boolean isReminderBeforeEachTerm) {
		this.isReminderBeforeEachTerm = isReminderBeforeEachTerm;
	}

	public Boolean getIsReminderBeforeEachBillDate() {
		return isReminderBeforeEachBillDate;
	}

	public void setIsReminderBeforeEachBillDate(Boolean isReminderBeforeEachBillDate) {
		this.isReminderBeforeEachBillDate = isReminderBeforeEachBillDate;
	}

	public void setNumberOfDaysPriorToRenewal(int numberOfDaysPriorToRenewal) {
		this.numberOfDaysPriorToRenewal = numberOfDaysPriorToRenewal;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	public EmailTemplate() {
		
	}
	
	

}
