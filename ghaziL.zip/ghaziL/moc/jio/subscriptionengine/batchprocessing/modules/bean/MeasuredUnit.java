package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Annasamudram.H
 * 
 * This is entity class for Measured Unit
 *
 */
@Entity(name = "measured_unit")
@PrimaryKey({ "siteId", "measuredUnitName" })
@JsonIgnoreProperties(ignoreUnknown=true)
public class MeasuredUnit  implements Serializable {

	@Id
	private String id;

	private String measuredUnitName; // - present

	private String measuredUnitDisplayName;

	private String measuredUnitDescription;

	private String siteId;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;
	
	private String createdBy;
	
	private String updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMeasuredUnitName() {
		return measuredUnitName;
	}

	public void setMeasuredUnitName(String measuredUnitName) {
		this.measuredUnitName = measuredUnitName;
	}

	public String getMeasuredUnitDisplayName() {
		return measuredUnitDisplayName;
	}

	public void setMeasuredUnitDisplayName(String measuredUnitDisplayName) {
		this.measuredUnitDisplayName = measuredUnitDisplayName;
	}

	public String getMeasuredUnitDescription() {
		return measuredUnitDescription;
	}

	public void setMeasuredUnitDescription(String measuredUnitDescription) {
		this.measuredUnitDescription = measuredUnitDescription;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public MeasuredUnit(String measuredUnitName, String measuredUnitDisplayName, String measuredUnitDescription,
			String siteId) {
		this.measuredUnitName = measuredUnitName;
		this.measuredUnitDisplayName = measuredUnitDisplayName;
		this.measuredUnitDescription = measuredUnitDescription;
		this.siteId = siteId;
	}

	public MeasuredUnit() {

	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
