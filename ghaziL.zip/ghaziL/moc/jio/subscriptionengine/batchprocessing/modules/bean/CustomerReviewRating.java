package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;

@Entity(name = "review")
@PrimaryKey({ "planId", "customerEmail" })
public class CustomerReviewRating implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5923987977048642645L;

	@Id
	private String id;
	
	private String username;

	private String firstName;

	private String lastName;
	
	private String customerEmail;
	
	private String planId;
	
	private String subscriberId;
	
	private String description;
	
	 private Date updatedOn;
	
	
	private int rating;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}
	
	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
