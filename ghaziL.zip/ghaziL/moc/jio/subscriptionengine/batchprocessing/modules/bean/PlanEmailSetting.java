package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class PlanEmailSetting  implements Serializable {

	private boolean newSubscriptionNotification;
	
	private boolean changesubscriptionNotification;
	
	private boolean expiredsubscriptionNotification;
	
	private boolean canceledsubscriptionNotification;
	
	private boolean newInvoiceNotification;
	
	private boolean receiptInvoiceNotification;

	private boolean byPassJioConfirmation;

	public boolean isNewSubscriptionNotification() {
		return newSubscriptionNotification;
	}

	public void setNewSubscriptionNotification(boolean newSubscriptionNotification) {
		this.newSubscriptionNotification = newSubscriptionNotification;
	}

	public boolean isChangesubscriptionNotification() {
		return changesubscriptionNotification;
	}

	public void setChangesubscriptionNotification(boolean changesubscriptionNotification) {
		this.changesubscriptionNotification = changesubscriptionNotification;
	}

	public boolean isExpiredsubscriptionNotification() {
		return expiredsubscriptionNotification;
	}

	public void setExpiredsubscriptionNotification(boolean expiredsubscriptionNotification) {
		this.expiredsubscriptionNotification = expiredsubscriptionNotification;
	}

	public boolean isCanceledsubscriptionNotification() {
		return canceledsubscriptionNotification;
	}

	public void setCanceledsubscriptionNotification(boolean canceledsubscriptionNotification) {
		this.canceledsubscriptionNotification = canceledsubscriptionNotification;
	}

	public boolean isNewInvoiceNotification() {
		return newInvoiceNotification;
	}

	public void setNewInvoiceNotification(boolean newInvoiceNotification) {
		this.newInvoiceNotification = newInvoiceNotification;
	}

	public boolean isReceiptInvoiceNotification() {
		return receiptInvoiceNotification;
	}

	public void setReceiptInvoiceNotification(boolean receiptInvoiceNotification) {
		this.receiptInvoiceNotification = receiptInvoiceNotification;
	}

	public boolean isByPassJioConfirmation() {
		return byPassJioConfirmation;
	}

	public void setByPassJioConfirmation(boolean byPassJioConfirmation) {
		this.byPassJioConfirmation = byPassJioConfirmation;
	}

	public PlanEmailSetting(boolean newSubscriptionNotification, boolean changesubscriptionNotification,
			boolean expiredsubscriptionNotification, boolean canceledsubscriptionNotification,
			boolean newInvoiceNotification, boolean receiptInvoiceNotification) {
		this.newSubscriptionNotification = newSubscriptionNotification;
		this.changesubscriptionNotification = changesubscriptionNotification;
		this.expiredsubscriptionNotification = expiredsubscriptionNotification;
		this.canceledsubscriptionNotification = canceledsubscriptionNotification;
		this.newInvoiceNotification = newInvoiceNotification;
		this.receiptInvoiceNotification = receiptInvoiceNotification;
	}

	public PlanEmailSetting() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (canceledsubscriptionNotification ? 1231 : 1237);
		result = prime * result + (changesubscriptionNotification ? 1231 : 1237);
		result = prime * result + (expiredsubscriptionNotification ? 1231 : 1237);
		result = prime * result + (newInvoiceNotification ? 1231 : 1237);
		result = prime * result + (newSubscriptionNotification ? 1231 : 1237);
		result = prime * result + (receiptInvoiceNotification ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlanEmailSetting other = (PlanEmailSetting) obj;
		if (canceledsubscriptionNotification != other.canceledsubscriptionNotification)
			return false;
		if (changesubscriptionNotification != other.changesubscriptionNotification)
			return false;
		if (expiredsubscriptionNotification != other.expiredsubscriptionNotification)
			return false;
		if (newInvoiceNotification != other.newInvoiceNotification)
			return false;
		if (newSubscriptionNotification != other.newSubscriptionNotification)
			return false;
		if (receiptInvoiceNotification != other.receiptInvoiceNotification)
			return false;
		return true;
	}

}