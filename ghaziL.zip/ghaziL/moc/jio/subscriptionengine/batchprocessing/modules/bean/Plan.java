package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.elastic.search.annotation.CompositeKey;
import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "plan")
@PrimaryKey({ "planCode", "siteId" })
@CompositeKey({ "name", "siteId" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class Plan implements Serializable {

	@Id
	private String id;

	private String siteId;

	private String name; // -- present

	private String planCode; // -- present

	private String description; // -- present

	private String categoryName; // -- present

	private String categoryDescription; // -- present

	private boolean quantityEditable; // -- present

	private IntervalUnit intervalUnit; // -- present

	private Currency baseFeeAttributes; // -- present

	private Accounting accounting; // -- present

	private int totalBillingCycles; // -- present

	private boolean autoRenew; // -- present

	private List<AddOn> addOns = new ArrayList<>(); // -- present

	private List<Item> items = new ArrayList<>(); // -- present

	private IntervalUnit trialInterval; // -- present

	private boolean trialRequiresBillingInfo; // -- present

	private Currency setupFeeAttributes; // -- present

	private PlanEmailSetting emailSettingAttributes;

	private String billingCycleType; // -- present

	private String logo; // -- present

	private List<String> descriptionImages; // -- present

	private Accounting setupAccounting; // -- present

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;

	private String createdBy;

	private String updatedBy;

	private Currency marketPlacePricePerUnit;

	private Currency marketPlacePricePerTerm;

	private boolean hidden;
	
	private List<String> webHookEndPointIds = new ArrayList<>();

	
	public List<String> getWebHookEndPointIds() {
		return webHookEndPointIds;
	}

	public void setWebHookEndPointIds(List<String> webHookEndPointIds) {
		this.webHookEndPointIds = webHookEndPointIds;
	}

	public boolean isHidden() {
		return hidden;
	}

	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public IntervalUnit getIntervalUnit() {
		return intervalUnit;
	}

	public void setIntervalUnit(IntervalUnit intervalUnit) {
		this.intervalUnit = intervalUnit;
	}

	public Accounting getAccounting() {
		return accounting;
	}

	public void setAccounting(Accounting accounting) {
		this.accounting = accounting;
	}

	public boolean isQuantityEditable() {
		return quantityEditable;
	}

	public void setQuantityEditable(boolean quantityEditable) {
		this.quantityEditable = quantityEditable;
	}

	public int getTotalBillingCycles() {
		return totalBillingCycles;
	}

	public void setTotalBillingCycles(int totalBillingCycles) {
		this.totalBillingCycles = totalBillingCycles;
	}

	public boolean isAutoRenew() {
		return autoRenew;
	}

	public void setAutoRenew(boolean autoRenew) {
		this.autoRenew = autoRenew;
	}

	public String getBillingCycleType() {
		return billingCycleType;
	}

	public void setBillingCycleType(String billingCycleType) {
		this.billingCycleType = billingCycleType;
	}

	public Currency getBaseFeeAttributes() {
		return baseFeeAttributes;
	}

	public void setBaseFeeAttributes(Currency baseFeeAttributes) {
		this.baseFeeAttributes = baseFeeAttributes;
	}

	public boolean isTrialRequiresBillingInfo() {
		return trialRequiresBillingInfo;
	}

	public void setTrialRequiresBillingInfo(boolean trialRequiresBillingInfo) {
		this.trialRequiresBillingInfo = trialRequiresBillingInfo;
	}

	public Currency getSetupFeeAttributes() {
		return setupFeeAttributes;
	}

	public void setSetupFeeAttributes(Currency setupFeeAttributes) {
		this.setupFeeAttributes = setupFeeAttributes;
	}

	public PlanEmailSetting getEmailSettingAttributes() {
		return emailSettingAttributes;
	}

	public void setEmailSettingAttributes(PlanEmailSetting emailSettingAttributes) {
		this.emailSettingAttributes = emailSettingAttributes;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public List<AddOn> getAddOns() {
		return addOns;
	}

	public void setAddOns(List<AddOn> addOns) {
		this.addOns = addOns;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public List<String> getDescriptionImages() {
		return descriptionImages;
	}

	public void setDescriptionImages(List<String> descriptionImages) {
		this.descriptionImages = descriptionImages;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public Currency getMarketPlacePricePerUnit() {
		return marketPlacePricePerUnit;
	}

	public void setMarketPlacePricePerUnit(Currency marketPlacePricePerUnit) {
		this.marketPlacePricePerUnit = marketPlacePricePerUnit;
	}

	public Currency getMarketPlacePricePerTerm() {
		return marketPlacePricePerTerm;
	}

	public void setMarketPlacePricePerTerm(Currency marketPlacePricePerTerm) {
		this.marketPlacePricePerTerm = marketPlacePricePerTerm;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public IntervalUnit getTrialInterval() {
		return trialInterval;
	}

	public void setTrialInterval(IntervalUnit trialInterval) {
		this.trialInterval = trialInterval;
	}

	public Accounting getSetupAccounting() {
		return setupAccounting;
	}

	public void setSetupAccounting(Accounting setupAccounting) {
		this.setupAccounting = setupAccounting;
	}

	public Plan() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accounting == null) ? 0 : accounting.hashCode());
		result = prime * result + ((addOns == null) ? 0 : addOns.hashCode());
		result = prime * result + (autoRenew ? 1231 : 1237);
		result = prime * result + ((baseFeeAttributes == null) ? 0 : baseFeeAttributes.hashCode());
		result = prime * result + ((billingCycleType == null) ? 0 : billingCycleType.hashCode());
		result = prime * result + ((categoryDescription == null) ? 0 : categoryDescription.hashCode());
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((createdOn == null) ? 0 : createdOn.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((descriptionImages == null) ? 0 : descriptionImages.hashCode());
		result = prime * result + ((emailSettingAttributes == null) ? 0 : emailSettingAttributes.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((intervalUnit == null) ? 0 : intervalUnit.hashCode());
		result = prime * result + ((items == null) ? 0 : items.hashCode());
		result = prime * result + ((logo == null) ? 0 : logo.hashCode());
		result = prime * result + ((marketPlacePricePerTerm == null) ? 0 : marketPlacePricePerTerm.hashCode());
		result = prime * result + ((marketPlacePricePerUnit == null) ? 0 : marketPlacePricePerUnit.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((planCode == null) ? 0 : planCode.hashCode());
		result = prime * result + (quantityEditable ? 1231 : 1237);
		result = prime * result + ((setupAccounting == null) ? 0 : setupAccounting.hashCode());
		result = prime * result + ((setupFeeAttributes == null) ? 0 : setupFeeAttributes.hashCode());
		result = prime * result + ((siteId == null) ? 0 : siteId.hashCode());
		result = prime * result + totalBillingCycles;
		result = prime * result + ((trialInterval == null) ? 0 : trialInterval.hashCode());
		result = prime * result + (trialRequiresBillingInfo ? 1231 : 1237);
		result = prime * result + ((updatedBy == null) ? 0 : updatedBy.hashCode());
		result = prime * result + ((updatedOn == null) ? 0 : updatedOn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Plan other = (Plan) obj;
		if (accounting == null) {
			if (other.accounting != null)
				return false;
		} else if (!accounting.equals(other.accounting))
			return false;
		if (addOns == null) {
			if (other.addOns != null)
				return false;
		} else if (!addOns.equals(other.addOns))
			return false;
		if (autoRenew != other.autoRenew)
			return false;
		if (baseFeeAttributes == null) {
			if (other.baseFeeAttributes != null)
				return false;
		} else if (!baseFeeAttributes.equals(other.baseFeeAttributes))
			return false;
		if (billingCycleType == null) {
			if (other.billingCycleType != null)
				return false;
		} else if (!billingCycleType.equals(other.billingCycleType))
			return false;
		if (categoryDescription == null) {
			if (other.categoryDescription != null)
				return false;
		} else if (!categoryDescription.equals(other.categoryDescription))
			return false;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdOn == null) {
			if (other.createdOn != null)
				return false;
		} else if (!createdOn.equals(other.createdOn))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (descriptionImages == null) {
			if (other.descriptionImages != null)
				return false;
		} else if (!descriptionImages.equals(other.descriptionImages))
			return false;
		if (emailSettingAttributes == null) {
			if (other.emailSettingAttributes != null)
				return false;
		} else if (!emailSettingAttributes.equals(other.emailSettingAttributes))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (intervalUnit == null) {
			if (other.intervalUnit != null)
				return false;
		} else if (!intervalUnit.equals(other.intervalUnit))
			return false;
		if (items == null) {
			if (other.items != null)
				return false;
		} else if (!items.equals(other.items))
			return false;
		if (logo == null) {
			if (other.logo != null)
				return false;
		} else if (!logo.equals(other.logo))
			return false;
		if (marketPlacePricePerTerm == null) {
			if (other.marketPlacePricePerTerm != null)
				return false;
		} else if (!marketPlacePricePerTerm.equals(other.marketPlacePricePerTerm))
			return false;
		if (marketPlacePricePerUnit == null) {
			if (other.marketPlacePricePerUnit != null)
				return false;
		} else if (!marketPlacePricePerUnit.equals(other.marketPlacePricePerUnit))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (planCode == null) {
			if (other.planCode != null)
				return false;
		} else if (!planCode.equals(other.planCode))
			return false;
		if (quantityEditable != other.quantityEditable)
			return false;
		if (setupAccounting == null) {
			if (other.setupAccounting != null)
				return false;
		} else if (!setupAccounting.equals(other.setupAccounting))
			return false;
		if (setupFeeAttributes == null) {
			if (other.setupFeeAttributes != null)
				return false;
		} else if (!setupFeeAttributes.equals(other.setupFeeAttributes))
			return false;
		if (siteId == null) {
			if (other.siteId != null)
				return false;
		} else if (!siteId.equals(other.siteId))
			return false;
		if (totalBillingCycles != other.totalBillingCycles)
			return false;
		if (trialInterval == null) {
			if (other.trialInterval != null)
				return false;
		} else if (!trialInterval.equals(other.trialInterval))
			return false;
		if (trialRequiresBillingInfo != other.trialRequiresBillingInfo)
			return false;
		if (updatedBy == null) {
			if (other.updatedBy != null)
				return false;
		} else if (!updatedBy.equals(other.updatedBy))
			return false;
		if (updatedOn == null) {
			if (other.updatedOn != null)
				return false;
		} else if (!updatedOn.equals(other.updatedOn))
			return false;
		return true;
	}

}
