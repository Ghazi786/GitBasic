package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "billing_info")
@PrimaryKey({ "subscriberId", "siteId"})
@JsonIgnoreProperties(ignoreUnknown=true)
public class BillingInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String subscriberId;

	private String siteId;

	private String name;	
	
	private String type;
	
	private String expiration;	
	
	private String cardLastFourDigits;	
	
	private String serviceProvider;	
	
	private String ipAddress;
	
	private Address address;

	private String createdBy;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getExpiration() {
		return expiration;
	}

	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}

	public String getCardLastFourDigits() {
		return cardLastFourDigits;
	}

	public void setCardLastFourDigits(String cardLastFourDigits) {
		this.cardLastFourDigits = cardLastFourDigits;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public BillingInfo() {
		super();
	}
}
