package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.elastic.search.annotation.RelatedEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity(name = "site")
@PrimaryKey({ "name" })
@JsonIgnoreProperties(ignoreUnknown=true)
public class Site  implements Serializable{
	
	@Id
	private String id;
	
	private String name;
	
	private String siteDbaName;
	
	private Address address;
	
	private String clientWebUrl;
	
	private String timeZone;
	
	private String vatNumber;
	
	private String resgistrationNumber;
	
	private String industryTypeId;
	
	private String estimatedAnnualRevenue;
	
	private String billingContactEmail;
	
	private String billingContactPhone;
	
	private String technicalContactEmail;
	
	private String technicalContactPhone;
	
	private String bccEmails;
	
	private String addressRequirement;
	
	private String orderNumberprefix;
	
	@RelatedEntity
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private IndustryType industryType;
	
	private HostedAccountManagement hostedAccountManagement;
	
	private HostedPageSetting hostedPageSetting;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;
	
	private String createdBy;
	
	private String updatedBy;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSiteDbaName() {
		return siteDbaName;
	}
	public void setSiteDbaName(String siteDbaName) {
		this.siteDbaName = siteDbaName;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public IndustryType getIndustryType() {
		return industryType;
	}
	public void setIndustryType(IndustryType industryType) {
		this.industryType = industryType;
	}
	public HostedAccountManagement getHostedAccountManagement() {
		return hostedAccountManagement;
	}
	public void setHostedAccountManagement(HostedAccountManagement hostedAccountManagement) {
		this.hostedAccountManagement = hostedAccountManagement;
	}
	public HostedPageSetting getHostedPageSetting() {
		return hostedPageSetting;
	}
	public void setHostedPageSetting(HostedPageSetting hostedPageSetting) {
		this.hostedPageSetting = hostedPageSetting;
	}
	public String getClientWebUrl() {
		return clientWebUrl;
	}
	public void setClientWebUrl(String clientWebUrl) {
		this.clientWebUrl = clientWebUrl;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getVatNumber() {
		return vatNumber;
	}
	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}
	public String getResgistrationNumber() {
		return resgistrationNumber;
	}
	public void setResgistrationNumber(String resgistrationNumber) {
		this.resgistrationNumber = resgistrationNumber;
	}
	public String getIndustryTypeId() {
		return industryTypeId;
	}
	public void setIndustryTypeId(String industryTypeId) {
		this.industryTypeId = industryTypeId;
	}
	public String getEstimatedAnnualRevenue() {
		return estimatedAnnualRevenue;
	}
	public void setEstimatedAnnualRevenue(String estimatedAnnualRevenue) {
		this.estimatedAnnualRevenue = estimatedAnnualRevenue;
	}
	public String getBillingContactEmail() {
		return billingContactEmail;
	}
	public void setBillingContactEmail(String billingContactEmail) {
		this.billingContactEmail = billingContactEmail;
	}
	public String getBillingContactPhone() {
		return billingContactPhone;
	}
	public void setBillingContactPhone(String billingContactPhone) {
		this.billingContactPhone = billingContactPhone;
	}
	public String getTechnicalContactEmail() {
		return technicalContactEmail;
	}
	public void setTechnicalContactEmail(String technicalContactEmail) {
		this.technicalContactEmail = technicalContactEmail;
	}
	public String getTechnicalContactPhone() {
		return technicalContactPhone;
	}
	public void setTechnicalContactPhone(String technicalContactPhone) {
		this.technicalContactPhone = technicalContactPhone;
	}
	public String getBccEmails() {
		return bccEmails;
	}
	public void setBccEmails(String bccEmails) {
		this.bccEmails = bccEmails;
	}
	public String getAddressRequirement() {
		return addressRequirement;
	}
	public void setAddressRequirement(String addressRequirement) {
		this.addressRequirement = addressRequirement;
	}
	public String getOrderNumberprefix() {
		return orderNumberprefix;
	}
	public void setOrderNumberprefix(String orderNumberprefix) {
		this.orderNumberprefix = orderNumberprefix;
	}
	public Site(String name, String siteDbaName, Address address, String clientWebUrl, String timeZone,
			String vatNumber, String resgistrationNumber, String industryTypeId, String estimatedAnnualRevenue,
			String billingContactEmail, String billingContactPhone, String technicalContactEmail,
			String technicalContactPhone, String bccEmails, String addressRequirement, String orderNumberprefix,
			IndustryType industryType, HostedAccountManagement hostedAccountManagement,
			HostedPageSetting hostedPageSetting) {
		super();
		this.name = name;
		this.siteDbaName = siteDbaName;
		this.address = address;
		this.clientWebUrl = clientWebUrl;
		this.timeZone = timeZone;
		this.vatNumber = vatNumber;
		this.resgistrationNumber = resgistrationNumber;
		this.industryTypeId = industryTypeId;
		this.estimatedAnnualRevenue = estimatedAnnualRevenue;
		this.billingContactEmail = billingContactEmail;
		this.billingContactPhone = billingContactPhone;
		this.technicalContactEmail = technicalContactEmail;
		this.technicalContactPhone = technicalContactPhone;
		this.bccEmails = bccEmails;
		this.addressRequirement = addressRequirement;
		this.orderNumberprefix = orderNumberprefix;
		this.industryType = industryType;
		this.hostedAccountManagement = hostedAccountManagement;
		this.hostedPageSetting = hostedPageSetting;
	}
		
	public Site() {
		
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
