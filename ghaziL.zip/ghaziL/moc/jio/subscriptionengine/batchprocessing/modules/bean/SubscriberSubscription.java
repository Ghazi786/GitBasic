package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "subscriber_subscription")
@JsonIgnoreProperties(ignoreUnknown=true)
public class SubscriberSubscription implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String subscriberId;

	private String siteId;

	private Plan plan;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date periodStartDate;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date periodEndDate;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date termStartDate;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date termEndDate;

	private Currency termBalance;

	private String termBehavior;

	private String collectionType;
	private String cancellationTimeFrame;
	private int pausedCycleCount;
	private int remainingBillingCount;
	private boolean paused;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date renewsOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date startedOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date nextBillingDate;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date trialEndDate;

	private Currency pricePerBillingPeriod;

	private String status;

	private Subscriber subscriber;
	
	private int qnt;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	private String createdBy;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;

	private String updatedBy;
		
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public Date getPeriodStartDate() {
		return periodStartDate;
	}

	public void setPeriodStartDate(Date periodStartDate) {
		this.periodStartDate = periodStartDate;
	}

	public Date getPeriodEndDate() {
		return periodEndDate;
	}

	public void setPeriodEndDate(Date periodEndDate) {
		this.periodEndDate = periodEndDate;
	}

	public Date getTermStartDate() {
		return termStartDate;
	}

	public void setTermStartDate(Date termStartDate) {
		this.termStartDate = termStartDate;
	}

	public Date getTermEndDate() {
		return termEndDate;
	}

	public void setTermEndDate(Date termEndDate) {
		this.termEndDate = termEndDate;
	}

	public Currency getTermBalance() {
		return termBalance;
	}

	public void setTermBalance(Currency termBalance) {
		this.termBalance = termBalance;
	}

	public String getTermBehavior() {
		return termBehavior;
	}

	public void setTermBehavior(String termBehavior) {
		this.termBehavior = termBehavior;
	}

	public String getCollectionType() {
		return collectionType;
	}

	public void setCollectionType(String collectionType) {
		this.collectionType = collectionType;
	}

	public Date getRenewsOn() {
		return renewsOn;
	}

	public void setRenewsOn(Date renewsOn) {
		this.renewsOn = renewsOn;
	}

	public Date getStartedOn() {
		return startedOn;
	}

	public void setStartedOn(Date startedOn) {
		this.startedOn = startedOn;
	}

	public Date getNextBillingDate() {
		return nextBillingDate;
	}

	public void setNextBillingDate(Date nextBillingDate) {
		this.nextBillingDate = nextBillingDate;
	}

	public Currency getPricePerBillingPeriod() {
		return pricePerBillingPeriod;
	}

	public void setPricePerBillingPeriod(Currency pricePerBillingPeriod) {
		this.pricePerBillingPeriod = pricePerBillingPeriod;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Subscriber getSubscriber() {
		return subscriber;
	}

	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}
	
	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public SubscriberSubscription() {
		super();
	}

	public Date getTrialEndDate() {
		return trialEndDate;
	}

	public void setTrialEndDate(Date trialEndDate) {
		this.trialEndDate = trialEndDate;
	}

	public int getPausedCycleCount() {
		return pausedCycleCount;
	}

	public void setPausedCycleCount(int pausedCycleCount) {
		this.pausedCycleCount = pausedCycleCount;
	}

	public boolean isPaused() {
		return paused;
	}

	public void setPaused(boolean paused) {
		this.paused = paused;
	}

	public int getRemainingBillingCount() {
		return remainingBillingCount;
	}

	public void setRemainingBillingCount(int remainingBillingCount) {
		this.remainingBillingCount = remainingBillingCount;
	}
	public int getQnt() {
		return qnt;
	}

	public void setQnt(int qnt) {
		this.qnt = qnt;
	}

	public String getCancellationTimeFrame() {
		return cancellationTimeFrame;
	}

	public void setCancellationTimeFrame(String cancellationTimeFrame) {
		this.cancellationTimeFrame = cancellationTimeFrame;
	}

}
