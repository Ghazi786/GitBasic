package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class HostedPageSetting implements Serializable {

	private String enabled;

	private String defaultTheme;

	private String showShippingAddress;

	private String showOrganizationName;

	private String showEmail;

	private String showPhoneNumber;

	private String showVatNumber;

	private String quantitiesEditable;

	private String showCouponCode;

	private String showGiftCardCode;

	private String allowAchPayment;

	private String logoUpload;

	private String backgroundColor;

	private String accentColor;

	private String signupButtonText;

	private String privacyPolicyUrl;

	private String termsOfServiceUrl;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;
	
	private String createdBy;
	
	private String updatedBy;

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	private Site site;

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public String getDefaultTheme() {
		return defaultTheme;
	}

	public void setDefaultTheme(String defaultTheme) {
		this.defaultTheme = defaultTheme;
	}

	public String getShowShippingAddress() {
		return showShippingAddress;
	}

	public void setShowShippingAddress(String showShippingAddress) {
		this.showShippingAddress = showShippingAddress;
	}

	public String getShowOrganizationName() {
		return showOrganizationName;
	}

	public void setShowOrganizationName(String showOrganizationName) {
		this.showOrganizationName = showOrganizationName;
	}

	public String getShowEmail() {
		return showEmail;
	}

	public void setShowEmail(String showEmail) {
		this.showEmail = showEmail;
	}

	public String getShowPhoneNumber() {
		return showPhoneNumber;
	}

	public void setShowPhoneNumber(String showPhoneNumber) {
		this.showPhoneNumber = showPhoneNumber;
	}

	public String getShowVatNumber() {
		return showVatNumber;
	}

	public void setShowVatNumber(String showVatNumber) {
		this.showVatNumber = showVatNumber;
	}

	public String getQuantitiesEditable() {
		return quantitiesEditable;
	}

	public void setQuantitiesEditable(String quantitiesEditable) {
		this.quantitiesEditable = quantitiesEditable;
	}

	public String getShowCouponCode() {
		return showCouponCode;
	}

	public void setShowCouponCode(String showCouponCode) {
		this.showCouponCode = showCouponCode;
	}

	public String getShowGiftCardCode() {
		return showGiftCardCode;
	}

	public void setShowGiftCardCode(String showGiftCardCode) {
		this.showGiftCardCode = showGiftCardCode;
	}

	public String getAllowAchPayment() {
		return allowAchPayment;
	}

	public void setAllowAchPayment(String allowAchPayment) {
		this.allowAchPayment = allowAchPayment;
	}

	public String getLogoUpload() {
		return logoUpload;
	}

	public void setLogoUpload(String logoUpload) {
		this.logoUpload = logoUpload;
	}

	public String getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public String getAccentColor() {
		return accentColor;
	}

	public void setAccentColor(String accentColor) {
		this.accentColor = accentColor;
	}

	public String getSignupButtonText() {
		return signupButtonText;
	}

	public void setSignupButtonText(String signupButtonText) {
		this.signupButtonText = signupButtonText;
	}

	public String getPrivacyPolicyUrl() {
		return privacyPolicyUrl;
	}

	public void setPrivacyPolicyUrl(String privacyPolicyUrl) {
		this.privacyPolicyUrl = privacyPolicyUrl;
	}

	public String getTermsOfServiceUrl() {
		return termsOfServiceUrl;
	}

	public void setTermsOfServiceUrl(String termsOfServiceUrl) {
		this.termsOfServiceUrl = termsOfServiceUrl;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public HostedPageSetting() {

	}

	public HostedPageSetting(String enabled, String defaultTheme, String showShippingAddress,
			String showOrganizationName, String showEmail, String showPhoneNumber, String showVatNumber,
			String quantitiesEditable, String showCouponCode, String showGiftCardCode, String allowAchPayment,
			String logoUpload, String backgroundColor, String accentColor, String signupButtonText,
			String privacyPolicyUrl, String termsOfServiceUrl, Site site) {
		super();
		this.enabled = enabled;
		this.defaultTheme = defaultTheme;
		this.showShippingAddress = showShippingAddress;
		this.showOrganizationName = showOrganizationName;
		this.showEmail = showEmail;
		this.showPhoneNumber = showPhoneNumber;
		this.showVatNumber = showVatNumber;
		this.quantitiesEditable = quantitiesEditable;
		this.showCouponCode = showCouponCode;
		this.showGiftCardCode = showGiftCardCode;
		this.allowAchPayment = allowAchPayment;
		this.logoUpload = logoUpload;
		this.backgroundColor = backgroundColor;
		this.accentColor = accentColor;
		this.signupButtonText = signupButtonText;
		this.privacyPolicyUrl = privacyPolicyUrl;
		this.termsOfServiceUrl = termsOfServiceUrl;
		this.site = site;
	}

	@Override
	public String toString() {
		return "HostedPageSetting [enabled=" + enabled + ", defaultTheme=" + defaultTheme + ", showShippingAddress="
				+ showShippingAddress + ", showOrganizationName=" + showOrganizationName + ", showEmail=" + showEmail
				+ ", showPhoneNumber=" + showPhoneNumber + ", showVatNumber=" + showVatNumber + ", quantitiesEditable="
				+ quantitiesEditable + ", showCouponCode=" + showCouponCode + ", showGiftCardCode=" + showGiftCardCode
				+ ", allowAchPayment=" + allowAchPayment + ", logoUpload=" + logoUpload + ", backgroundColor="
				+ backgroundColor + ", accentColor=" + accentColor + ", signupButtonText=" + signupButtonText
				+ ", privacyPolicyUrl=" + privacyPolicyUrl + ", termsOfServiceUrl=" + termsOfServiceUrl + ", site="
				+ site + "]";
	}

}
