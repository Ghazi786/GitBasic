package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Samrudhi.Gandhe
 *
 */
@Entity(name = "item")
@PrimaryKey({ "itemCode", "siteId" })
@JsonIgnoreProperties(ignoreUnknown=true)
public class Item  implements Serializable {

	@Id
	private String id;

	private String siteId;

	private String name;

	private String itemCode; // -- present

	private String externalSku;

	private Accounting accounting;

	private String description;

	private boolean taxExempt;

	private String taxCode;

	private Currency currencyAttribute;

	private boolean itemBackedAddOn;

	private boolean enabled;

	private boolean optionalAdOns; // -- present

	private boolean displayQuantity; // -- present
	private int qnt; 

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;
	
	private String createdBy;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;
	
	private String updatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getExternalSku() {
		return externalSku;
	}

	public void setExternalSku(String externalSku) {
		this.externalSku = externalSku;
	}

	public Accounting getAccounting() {
		return accounting;
	}

	public void setAccounting(Accounting accounting) {
		this.accounting = accounting;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isTaxExempt() {
		return taxExempt;
	}

	public void setTaxExempt(boolean taxExempt) {
		this.taxExempt = taxExempt;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public Currency getCurrencyAttribute() {
		return currencyAttribute;
	}

	public void setCurrencyAttribute(Currency currencyAttribute) {
		this.currencyAttribute = currencyAttribute;
	}

	public boolean isItemBackedAddOn() {
		return itemBackedAddOn;
	}

	public void setItemBackedAddOn(boolean itemBackedAddOn) {
		this.itemBackedAddOn = itemBackedAddOn;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	public boolean isOptionalAdOns() {
		return optionalAdOns;
	}

	public void setOptionalAdOns(boolean optionalAdOns) {
		this.optionalAdOns = optionalAdOns;
	}

	public boolean isDisplayQuantity() {
		return displayQuantity;
	}

	public void setDisplayQuantity(boolean displayQuantity) {
		this.displayQuantity = displayQuantity;
	}

	public Item(String siteId, String name, String itemCode, String externalSku, Accounting accounting,
			String description, boolean taxExempt, String taxCode, Currency currencyAttribute, boolean itemBackedAddOn,
			boolean enabled,int qnt) {
		this.siteId = siteId;
		this.name = name;
		this.itemCode = itemCode;
		this.externalSku = externalSku;
		this.accounting = accounting;
		this.description = description;
		this.taxExempt = taxExempt;
		this.taxCode = taxCode;
		this.currencyAttribute = currencyAttribute;
		this.itemBackedAddOn = itemBackedAddOn;
		this.enabled = enabled;
		this.qnt = qnt;
	}

	public Item() {

	}
	
	public int getQnt() {
		return qnt;
	}

	public void setQnt(int qnt) {
		this.qnt = qnt;
	}
	
}
