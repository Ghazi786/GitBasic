package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class HostedAccountManagement implements Serializable {

	private String enabled;

	private String guestViewOnly;

	private String allowPayInvoice;

	private String allowAchPayment;

	private String showCancelSubscription;

	private String allowUpdateEmail;

	private String redeemGiftCard;

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public String getGuestViewOnly() {
		return guestViewOnly;
	}

	public void setGuestViewOnly(String guestViewOnly) {
		this.guestViewOnly = guestViewOnly;
	}

	public String getAllowPayInvoice() {
		return allowPayInvoice;
	}

	public void setAllowPayInvoice(String allowPayInvoice) {
		this.allowPayInvoice = allowPayInvoice;
	}

	public String getAllowAchPayment() {
		return allowAchPayment;
	}

	public void setAllowAchPayment(String allowAchPayment) {
		this.allowAchPayment = allowAchPayment;
	}

	public String getShowCancelSubscription() {
		return showCancelSubscription;
	}

	public void setShowCancelSubscription(String showCancelSubscription) {
		this.showCancelSubscription = showCancelSubscription;
	}

	public String getAllowUpdateEmail() {
		return allowUpdateEmail;
	}

	public void setAllowUpdateEmail(String allowUpdateEmail) {
		this.allowUpdateEmail = allowUpdateEmail;
	}

	public String getRedeemGiftCard() {
		return redeemGiftCard;
	}

	public void setRedeemGiftCard(String redeemGiftCard) {
		this.redeemGiftCard = redeemGiftCard;
	}

	public HostedAccountManagement() {

	}

	public HostedAccountManagement(String enabled, String guestViewOnly, String allowPayInvoice, String allowAchPayment,
			String showCancelSubscription, String allowUpdateEmail, String redeemGiftCard) {
		super();
		this.enabled = enabled;
		this.guestViewOnly = guestViewOnly;
		this.allowPayInvoice = allowPayInvoice;
		this.allowAchPayment = allowAchPayment;
		this.showCancelSubscription = showCancelSubscription;
		this.allowUpdateEmail = allowUpdateEmail;
		this.redeemGiftCard = redeemGiftCard;
	}
}
