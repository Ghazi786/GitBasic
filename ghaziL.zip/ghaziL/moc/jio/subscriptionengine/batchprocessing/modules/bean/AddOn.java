package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "addOn")
@PrimaryKey({ "siteId", "addOnCode" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddOn  implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String siteId;

	private String name;

	private String addOnCode;

	private Accounting accounting;

	private String addOnType;
	
	private boolean optionalAdOns;
	
	private String tierType;

	private Currency currencies; //  -- present

	private boolean displayQuantity;

	private String usageType;

	private int usagePercentage;

	private MeasuredUnit measuredUnit;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;
	
	private String createdBy;
	
	private String updatedBy;
	private int qnt;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddOnCode() {
		return addOnCode;
	}

	public void setAddOnCode(String addOnCode) {
		this.addOnCode = addOnCode;
	}

	public Accounting getAccounting() {
		return accounting;
	}

	public void setAccounting(Accounting accounting) {
		this.accounting = accounting;
	}

	public String getTierType() {
		return tierType;
	}

	public void setTierType(String tierType) {
		this.tierType = tierType;
	}

	public Currency getCurrencies() {
		return currencies;
	}

	public void setCurrencies(Currency currencies) {
		this.currencies = currencies;
	}

	public boolean isOptionalAdOns() {
		return optionalAdOns;
	}

	public void setOptionalAdOns(boolean optionalAdOns) {
		this.optionalAdOns = optionalAdOns;
	}

	public boolean isDisplayQuantity() {
		return displayQuantity;
	}

	public void setDisplayQuantity(boolean displayQuantity) {
		this.displayQuantity = displayQuantity;
	}

	public String getAddOnType() {
		return addOnType;
	}

	public void setAddOnType(String addOnType) {
		this.addOnType = addOnType;
	}

	public String getUsageType() {
		return usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}

	public MeasuredUnit getMeasuredUnit() {
		return measuredUnit;
	}

	public void setMeasuredUnit(MeasuredUnit measuredUnit) {
		this.measuredUnit = measuredUnit;
	}

	public int getUsagePercentage() {
		return usagePercentage;
	}

	public void setUsagePercentage(int usagePercentage) {
		this.usagePercentage = usagePercentage;
	}

	public AddOn(String siteId, String name, String addOnCode, Accounting accounting, String tierType,
			Currency currencies, boolean optionalAdOns, boolean displayQuantity, String addOnType, String usageType,
			MeasuredUnit measuredUnit, int usagePercentage, int qnt) {
		this.siteId = siteId;
		this.name = name;
		this.addOnCode = addOnCode;
		this.accounting = accounting;
		this.tierType = tierType;
		this.currencies = currencies;
		this.optionalAdOns = optionalAdOns;
		this.displayQuantity = displayQuantity;
		this.addOnType = addOnType;
		this.usageType = usageType;
		this.measuredUnit = measuredUnit;
		this.usagePercentage = usagePercentage;
		this.qnt = qnt;
	}

	public AddOn() {

	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public int getQnt() {
		return qnt;
	}

	public void setQnt(int qnt) {
		this.qnt = qnt;
	}
	
}