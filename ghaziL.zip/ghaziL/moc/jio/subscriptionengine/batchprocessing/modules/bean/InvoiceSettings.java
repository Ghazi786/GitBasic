package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;

import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Annasamudram.H
 * 
 *         This is entity class for Invoice Setting
 *
 */
@Entity(name = "invoice_settings")
@PrimaryKey({ "siteId" })
@JsonIgnoreProperties(ignoreUnknown=true)
public class InvoiceSettings implements Serializable {

	@Id
	private String id;

	private String siteId;

	private String customerNotes;

	private String termsAndConditions;

	private String netTerms;
	
	private boolean attachPdfToEmails;
	
	private boolean failUpgradeOnFailedTransaction;
	
	private boolean failDowngradeOnPastDueInvoice;
	
	private boolean blockOnDeclinedRefunds;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;
	
	private String createdBy;
	
	private String updatedBy;

	public String getCustomerNotes() {
		return customerNotes;
	}

	public void setCustomerNotes(String customerNotes) {
		this.customerNotes = customerNotes;
	}

	public String getTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public String getNetTerms() {
		return netTerms;
	}

	public void setNetTerms(String netTerms) {
		this.netTerms = netTerms;
	}

	public boolean getAttachPdfToEmails() {
		return attachPdfToEmails;
	}

	public void setAttachPdfToEmails(boolean attachPdfToEmails) {
		this.attachPdfToEmails = attachPdfToEmails;
	}

	public boolean getFailUpgradeOnFailedTransaction() {
		return failUpgradeOnFailedTransaction;
	}

	public void setFailUpgradeOnFailedTransaction(boolean failUpgradeOnFailedTransaction) {
		this.failUpgradeOnFailedTransaction = failUpgradeOnFailedTransaction;
	}

	public boolean getFailDowngradeOnPastDueInvoice() {
		return failDowngradeOnPastDueInvoice;
	}

	public void setFailDowngradeOnPastDueInvoice(boolean failDowngradeOnPastDueInvoice) {
		this.failDowngradeOnPastDueInvoice = failDowngradeOnPastDueInvoice;
	}

	public boolean getBlockOnDeclinedRefunds() {
		return blockOnDeclinedRefunds;
	}

	public void setBlockOnDeclinedRefunds(boolean blockOnDeclinedRefunds) {
		this.blockOnDeclinedRefunds = blockOnDeclinedRefunds;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
}
