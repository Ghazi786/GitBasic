package com.jio.subscriptionengine.batchprocessing.modules.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.elastic.search.annotation.CompositeKey;
import com.elastic.search.annotation.Entity;
import com.elastic.search.annotation.Id;
import com.elastic.search.annotation.PrimaryKey;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity(name = "subscriber")
@PrimaryKey({ "email" })
@CompositeKey({ "username" })
@JsonIgnoreProperties(ignoreUnknown=true)
public class Subscriber implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String username;

	private String firstName;

	private String lastName;

	private String companyName;

	private String email;

	private String ccEmail;

	private Address address;
	
	private List<Address> additionalAddress;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date createdOn;

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date updatedOn;

	private String createdBy;

	private String updatedBy;

	private String status;
	
	private String subscriberName;
	
	private String password;
	
	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCcEmail() {
		return ccEmail;
	}

	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Subscriber() {
		super();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Address> getAdditionalAddress() {
		return additionalAddress;
	}

	public void setAdditionalAddress(List<Address> additionalAddress) {
		this.additionalAddress = additionalAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}	
	
	
}
