package com.jio.subscriptionengine.batchprocessing.modules.reviewrating.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jetty.http.HttpStatus;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;

import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.bean.WildCardSearch;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.CustomerReviewRating;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.constants.ReviewConstants;
import com.jio.subscriptionengine.batchprocessing.modules.wishlists.helper.WishlistConstant;


/**
 * Customer review repository to connect with elastic search
 *  @author Karthik.Goud
 *
 */
public class CustomerReviewRespository {
	
	
	private static CustomerReviewRespository service = new CustomerReviewRespository();

	private CustomerReviewRespository() {

	}

	public static CustomerReviewRespository getInstance() {
		return service;
	}


	/**
	 * add new review to the review entity
	 * 
	 * @param planId
	 * @param session
	 * @return 
	 * @throws Exception
	 */
	public void addReview(Session session, CustomerReviewRating review) throws Exception  {
		
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Executing [ " + this.getClass().getName() + "."
				+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
		this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		
		try {
			session.beginTransaction();
			session.save(review);
		} catch (ElasticSearchException e) {
			
			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString()).writeLog();
			throw new BaseException(HttpStatus.CONFLICT_409, ReviewConstants.ADDING_REVIEW__FAILURE);
			
		}finally {
			session.close();
		}
		
		
		
	}
	

	/**
	 * fetch rating by planId
	 * 
	 * @param planId
	 * @param session
	 * @return SearchResult<CustomerReviewRating>
	 * @throws Exception
	 */
	public SearchResult<CustomerReviewRating> getRatingByPlanId(Session session,String planId) throws ElasticSearchException {
		Map<String, String> filters = new HashMap<>();
		filters.put(ReviewConstants.PLAN_ID, planId);
		return session.get(CustomerReviewRating.class, filters);
		
	}
	
	

	/**
	 * fetch rating by planId
	 * 
	 * @param planId
	 * @param session
	 * @return SearchResult<CustomerReviewRating>
	 * @throws Exception
	 */
	public SearchResult<CustomerReviewRating> getRatingByPlanIdPagination(Session session,String planId ,String q, DateRange dateRange,
			OrderBy order, int page, int pageSize) throws ElasticSearchException {
		Map<String, Object> filters = new HashMap<>();
		filters.put(ReviewConstants.PLAN_ID, planId);
		if (q != null) {

			// fields on which we will perform wildcard search
			List<String> fields = new ArrayList<>();

			fields.add(WishlistConstant.DESCRIPTION);

			WildCardSearch search = new WildCardSearch(q, fields);
			filters.put(ReviewConstants.WILDCARD, search);
		}

		if (dateRange != null) {
			filters.put(ReviewConstants.CREATED_ON, dateRange);
		}

		List<OrderBy> orders = new ArrayList<>();
		// order by check
		if (order != null) {
			orders.add(order);
		}

		// page related
		Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}
		
		SearchResult<CustomerReviewRating> result = session.get(CustomerReviewRating.class,orders, filters, qPage);
		return result;
		
	}
	
	/**
	 * update review existing review in in review entity
	 * 
	 * @param CustomerReviewRating
	 * @param session
	 * @return SearchResult<CustomerReviewRating>
	 * @throws Exception
	 */
	public void updateReview(Session session,CustomerReviewRating review)  {
				
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
			   try {
					     session.beginTransaction();
				         CustomerReviewRating customerReviewFromDB = session.getObject(CustomerReviewRating.class ,review.getId());
				         customerReviewFromDB.setDescription(review.getDescription());
				         customerReviewFromDB.setRating(review.getRating());
				         session.merge(customerReviewFromDB);
					}catch (Exception e) {
						DappLoggerService.GENERAL_INFO_LOG
						.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString()).writeLog();
					}finally {
						session.close();
					}
					
				}
	
	/**
	 * fetch group rating from review entity
	 * 
	 * @param Map<String, Object
	 * @param session
	 * @return SearchResult<CustomerReviewRating>
	 * @throws Exception
	 */
	public Terms getGroupRating(Session session, Map<String, Object> filters) {
		
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Executing [ " + this.getClass().getName() + "."
				+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
		this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		
		Terms terms = null;
		  try {
			session.beginTransaction();
			terms = session.aggregation(CustomerReviewRating.class, ReviewConstants.RATING, filters);
		} catch (Exception e) {
			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder(ReviewConstants.REVIEW_API_INVOKED, this.getClass().getName(), e.toString()).writeLog();
			
		} finally {
			session.close();
		}
		
		return terms;
		
	}

}
