package com.jio.subscriptionengine.batchprocessing.modules.reviewrating.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.math.NumberUtils;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;

import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.enums.Levels;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.CustomerReviewRating;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.plan.bean.PlanResource;
import com.jio.subscriptionengine.batchprocessing.modules.plan.helper.PlanConstant;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.constants.ReviewConstants;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.repository.CustomerReviewRespository;
import com.jio.subscriptionengine.batchprocessing.redis.RedisOperationImpl;



/**
 *This is Customer review Service  @author Karthik.Goud
 *
 */
public class CustomerReviewService {
	
	private static  CustomerReviewService service = new  CustomerReviewService();

	private  CustomerReviewService() {

	}

	public static CustomerReviewService getInstance() {
		return service;
	}
	
	
	/**
	 * Add reviews associated with CustomerReviewRating entity
	 * 
	 * @param CustomerReviewRating
	 * @return BaseResponse<Map<String, String>>
	 * @throws Exception
	 */
	public BaseResponse<Map<String, String>> addReview(CustomerReviewRating review) throws Exception{
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		CustomerReviewRespository.getInstance().addReview(session, review);
		
		BaseResponse<Map<String, String>> baseResponse = new BaseResponse<>();
		Map<String, String> responseData = new HashMap<>();
		baseResponse.setData(responseData);
		baseResponse.setMessage(ReviewConstants.ACCEPTED);
		baseResponse.setStatus(202);
		
		return baseResponse;
		
	}
	
	/**
	 * Get ratingsfrom review entity  By planId 
	 * 
	 * @param planId
	 * @return BaseResponse<SearchResult<CustomerReviewRating>>
	 * @throws Exception
	 */
    public BaseResponse<SearchResult<CustomerReviewRating>> getRatingsByPlanId(String planId) throws Exception{
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		SearchResult<CustomerReviewRating> ratings = CustomerReviewRespository.getInstance().getRatingByPlanId(session, planId);
		BaseResponse<SearchResult<CustomerReviewRating>> baseResponse = new BaseResponse<>(ratings);

		
		return baseResponse;
		
	}
    
    
    /**
	 * update  review entity with CustomerReviewRating  
	 * 
	 * @param planId
	 * @return  BaseResponse<Map<String, String>>
	 * @throws Exception
	 */
    public BaseResponse<Map<String, String>> updateReview(CustomerReviewRating rating) throws Exception{
	
	    
        SessionFactory factory = SessionFactory.getSessionFactory();
	    Session session = factory.getSession();
	    session.setSearchLevel(Levels.NONE);
	    CustomerReviewRespository.getInstance().updateReview(session, rating);
	    BaseResponse<Map<String, String>> baseResponse = new BaseResponse<>();
		baseResponse.setMessage(ReviewConstants.RESPONSE_MSG_UPDATE_REVIEW);
		baseResponse.setStatus(201);
			
		return baseResponse;
    }

    
    
    /**
	 * fetch Group rating by planId
	 * 
	 * @param planId
	 * @return  BaseResponse<Map<String, String>>
	 * @throws Exception
	 */
	public Map<String, Long> fetchRatingByGroup(String planId) throws Exception {
		
		Map<String, Long> ratingCount = new HashMap<>();
		Map<String, Object> filters = new HashMap<>();
        filters.put(ReviewConstants.PLAN_ID, planId);
        
        SessionFactory factory = SessionFactory.getSessionFactory();
	    Session session = factory.getSession();
	    session.setSearchLevel(Levels.NONE);
	    Terms ratingTerms = CustomerReviewRespository.getInstance().getGroupRating(session, filters);
	    for(Terms.Bucket bucket :ratingTerms.getBuckets()) {
	    	
			long count = bucket.getDocCount();
	    	  ratingCount.put(bucket.getKeyAsString(), count);
	    }
	    
		return ratingCount;
		
	}
	
	/**
	 * fetch  reviews by planId
	 * 
	 * @param planId
	 * @return BaseResponse<SearchResult<CustomerReviewRating>>
	 * @throws Exception
	 */
	public BaseResponse<SearchResult<CustomerReviewRating>>  fetchReviewsByPlanId(String planId) throws ElasticSearchException {
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		SearchResult<CustomerReviewRating> ratings = CustomerReviewRespository.getInstance().getRatingByPlanId(session, planId);
		SearchResult<CustomerReviewRating> resposne = new SearchResult<>();
		resposne.setResult(ratings.getResult());
		resposne.setPage(ratings.getPage());
		resposne.setDocumentsCount(ratings.getDocumentsCount());
		
		BaseResponse<SearchResult<CustomerReviewRating>> baseResponse = new BaseResponse<>(resposne);
		return baseResponse ;
		
		
	}
	
	/**
	 * fetch  reviews by planId
	 * 
	 * @param planId
	 * @return BaseResponse<SearchResult<CustomerReviewRating>>
	 * @throws Exception
	 */
	public BaseResponse<SearchResult<CustomerReviewRating>>  fetchReviewsByPlanIdPagination(String planId , String q, DateRange dateRange, OrderBy order,
			int page, int pageSize) throws ElasticSearchException {
		
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		SearchResult<CustomerReviewRating> ratings = CustomerReviewRespository.getInstance().getRatingByPlanIdPagination(session, planId , q, dateRange, order, page,
				pageSize );
		SearchResult<CustomerReviewRating> resposne = new SearchResult<>();
		resposne.setResult(ratings.getResult());
		resposne.setPage(ratings.getPage());
		resposne.setDocumentsCount(ratings.getDocumentsCount());
		
		BaseResponse<SearchResult<CustomerReviewRating>> baseResponse = new BaseResponse<>(resposne);
		return baseResponse ;
		
		
	}

	/**
	 * @param planId
	 * @throws Exception
	 */
	public void setPlanReviewAndRatingIntoRedis(final String planId)
			throws Exception {
		final Map<String, Long> ratingCount = CustomerReviewService.getInstance().fetchRatingByGroup(planId);

		long totalRatingCount = 0;
		long ratingSum = 0;
		for (final Entry<String, Long> rating : ratingCount.entrySet()) {
			final String ratingKey = rating.getKey();
			final long count = rating.getValue();
			ratingSum += count * NumberUtils.toLong(ratingKey, 0);
			if (!"0".equalsIgnoreCase(ratingKey)) {
				totalRatingCount += count;
			}
		}
		final double avgRating = totalRatingCount ==0 ? 0: ratingSum / totalRatingCount;
		long value = ratingCount.get("0") == null ? 0:ratingCount.get("0");
		final long totalReviewCount = totalRatingCount + value;
		
		try {
			final RedisOperationImpl operationImpl = new RedisOperationImpl();
			operationImpl.setMapKeyField(PlanConstant.REDIS_RATINGS_KEY, planId, String.valueOf(avgRating));
			operationImpl.setMapKeyField(PlanConstant.REDIS_REVIEW_COUNT_KEY, planId, String.valueOf(totalReviewCount));
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
	}
	/**
	 * @param planId
	 * @throws Exception
	 */
	public void setPlanReviewAndRating(final PlanResource plan)
			throws Exception {
		final Map<String, Long> ratingCount = CustomerReviewService.getInstance().fetchRatingByGroup(plan.getId());
		
		long totalRatingCount = 0;
		long ratingSum = 0;
		for (final Entry<String, Long> rating : ratingCount.entrySet()) {
			final String ratingKey = rating.getKey();
			final long count = rating.getValue();
			ratingSum += count * NumberUtils.toLong(ratingKey, 0);
			if (!"0".equalsIgnoreCase(ratingKey)) {
				totalRatingCount += count;
			}
		}
		final double avgRating = totalRatingCount ==0 ? 0: ratingSum / totalRatingCount;
		long value = ratingCount.get("0") == null ? 0:ratingCount.get("0");
		final long totalReviewCount = totalRatingCount + value;
		
		plan.setReviewsCount((int) totalReviewCount);
		plan.setRating(avgRating);
		
	}

}
