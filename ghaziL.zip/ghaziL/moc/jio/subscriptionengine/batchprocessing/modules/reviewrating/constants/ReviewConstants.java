package com.jio.subscriptionengine.batchprocessing.modules.reviewrating.constants;

public class ReviewConstants {

	public static final String GENERATE_RATINGS = "generate ratings";
	public static final String NOT_AUTHORIZED = "you are not subscribed to this plan";
	public static final String ACCEPTED = "Accepted";
	public static final String RATING = "rating";
	public static final String FETCH_ALL_REVIEW__FAILURE = "fetching all reviews failure";
	public static final String GROUP_RATING = "group rating";
	public static final String ALL_REVIEW = "all reviews api";
	public static final String FETCH_GROUP_RATING__FAILURE = "fetching group rating is failure";
	public static final String UPDATE_REVIEW_FAILURE = "update review failure";
	public static final String POST_REVIEW__FAILURE = "post review is failure";
	public static final String ADDING_REVIEW__FAILURE = "adding review  failure";
	public static final String REVIEW_API_INVOKED = "review api is invoked";
	public static final String UPDATE_REVIEW = "edit review";
	public static final String INVALID_DATA  = "Invalid request/content data.";
	public static final String INTERNAL_SERVER_ERROR = "Internal server error occured please contact administrator.";
	public static final String POST_REVIEW  = "postReview";
	public static final String PLAN_ID = "planId";
	public static final String Message = "grouping rating data fetched successfully";
	public static final String RESPONSE_MSG_UPDATE_REVIEW = "updated";

	public static String SORT = "sort";

	public static String ORDER = "order";

	public static String ASC = "ASC";

	public static String PAGE = "page";

	public static String PAGE_SIZE = "page_size";

	public static String q = "q";
	public static final String WILDCARD = "wildcard";
	public static final String CREATED_ON = "createdOn";
	

}
