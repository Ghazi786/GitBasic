package com.jio.subscriptionengine.batchprocessing.modules.subscription.service;

import java.util.Collection;
import java.util.Date;

import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.enums.Levels;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailHandler;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionPauseHelper;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionStatusEnum;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.repository.SubscriptionRepository;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;

/**
 * This is helper class to perform all business logic on subscription while
 * pause/resume actions
 * 
 * @author Samrudhi.Gandhe
 *
 */
public class SubscriptionPauseService {

	private static final SubscriptionPauseService pauseService = new SubscriptionPauseService();

	private SubscriptionPauseService() {
	}

	public static final SubscriptionPauseService getInstance() {
		return pauseService;
	}

	// @formatter:off
	/**
	 * @param subscriptionId
	 * @param subscriberId
	 * @param cycleToSkip
	 * @param baseEventBean
	 * @throws Exception
	 */
	public void pauseSubscriptionPlan(final String subscriptionId, final String subscriberId, final int cycleToSkip,
			final BaseEventBean baseEventBean) throws Exception {

		// @formatter:on
		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();
		final Session session = getSession(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);
			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);
			final SubscriptionPauseHelper pauseHelperService = new SubscriptionPauseHelper();
			pauseHelperService.setPauseDetails(cycleToSkip, subscriberSubscription);

			subscriptionRepository.update(session, subscriberSubscription);

			final Runnable emailTask = () -> {
				try {
					// send email to inform user about subscription's cancellation
					EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
							subscriberSubscription.getSiteId(), subscriberSubscription.getPlan()
									.getEmailSettingAttributes().isChangesubscriptionNotification(),null);
					
					// @formatter:off
					String messageLog = "Scheduled pause for subscription to " + subscriberSubscription.getPlan().getName();
					SubscriptionCommonService.getInstance().addWebhookActivity(baseEventBean, session, subscriberSubscription,
							SubscriptionConstants.EVENT_SCHEDULED_PAUSE_SUBSCRIPTION, messageLog);
					// @formatter:on

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

			

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.UPDATE_FAILED);
		} finally {
			session.close();
		}
	}

	// @formatter:off
	/**
	 * @param subscriptionId
	 * @param subscriberId
	 * @param baseEventBean
	 * @throws Exception
	 */
	public void cancelPausedSubscription(final String subscriptionId, final String subscriberId,
			final BaseEventBean baseEventBean) throws Exception {
		// @formatter:on
		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();

		final Session session = getSession(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);
			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);

			final SubscriptionPauseHelper pauseHelperService = new SubscriptionPauseHelper();
			pauseHelperService.setCancelPausedDetails(subscriberSubscription);

			subscriptionRepository.update(session, subscriberSubscription);

			
			final Runnable emailTask = () -> {
				try {
					// send email to inform user about subscription's cancellation
					EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
							subscriberSubscription.getSiteId(), subscriberSubscription.getPlan()
									.getEmailSettingAttributes().isChangesubscriptionNotification(),null);
					
					// @formatter:off
					String messageLog = "Canceled scheduled pause for subscription to "
							+ subscriberSubscription.getPlan().getName();
					SubscriptionCommonService.getInstance().addWebhookActivity(baseEventBean, session, subscriberSubscription,
							SubscriptionConstants.EVENT_CANCEL_PAUSE_SUBSCRIPTION, messageLog);
					// @formatter:on

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.UPDATE_FAILED);

		} finally {
			session.close();

		}
	}

	/**
	 * @param subscriptionId
	 * @param subscriberId
	 * @param baseEventBean
	 * @return
	 * @throws Exception
	 */
	public void resumePausedSubscription(final String subscriptionId, final String subscriberId,
			final BaseEventBean baseEventBean) throws Exception {

		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();
		final Session session = getSession(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);

			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);

			// initiate payment for current cycle, if it is successfull update next billing
			// period & remaining cycle count

			// TODO Call payment flow
			// Invoice creation
			final InvoiceService invoiceService = new InvoiceService();
			invoiceService.createPlanInvoice(subscriberSubscription);

			final SubscriptionPauseHelper pauseHelperService = new SubscriptionPauseHelper();
			pauseHelperService.setResumeDetails(subscriberSubscription);

			subscriptionRepository.update(session, subscriberSubscription);

			

			final Runnable emailTask = () -> {
				try {
					// send email to inform user about subscription's cancellation
					EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
							subscriberSubscription.getSiteId(), subscriberSubscription.getPlan()
									.getEmailSettingAttributes().isNewInvoiceNotification(),null);
					
					// @formatter:off
					String messageLog = "Resumed subscription to " + subscriberSubscription.getPlan().getName();
					SubscriptionCommonService.getInstance().addWebhookActivity(baseEventBean, session, subscriberSubscription,
							SubscriptionConstants.EVENT_CANCEL_PAUSE_SUBSCRIPTION, messageLog);
					// @formatter:on

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.UPDATE_FAILED);

		} finally {
			session.close();
		}
	}

	/**
	 * @param subscriptionId
	 * @param subscriberId
	 * @param cycleToSkip
	 * @param baseEventBean
	 * @return
	 * @throws ElasticSearchException
	 */
	// @formatter:off
	public void editPausedSubscription(final String subscriptionId, final String subscriberId, final int cycleToSkip,
			final BaseEventBean baseEventBean) throws ElasticSearchException {

		// @formatter:on
		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();
		final Session session = getSession(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		final SubscriptionPauseHelper pauseHelperService = new SubscriptionPauseHelper();
		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);

			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);

			if (SubscriptionStatusEnum.RENEWING.getValue().equalsIgnoreCase(subscriberSubscription.getStatus())) {
				pauseHelperService.setPauseDetails(cycleToSkip, subscriberSubscription);
				subscriptionRepository.update(session, subscriberSubscription);

			} else if (SubscriptionStatusEnum.PAUSED.getValue().equalsIgnoreCase(subscriberSubscription.getStatus())) {
				pauseHelperService.recalculatePauseCycle(cycleToSkip, subscriberSubscription);
				subscriptionRepository.update(session, subscriberSubscription);
			}

			final Runnable emailTask = () -> {
				try {
					// send email to inform user about subscription's cancellation
					EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
							subscriberSubscription.getSiteId(), subscriberSubscription.getPlan()
									.getEmailSettingAttributes().isChangesubscriptionNotification(),null);

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		} finally {
			session.close();
		}
	}

	/**
	 * @param subscriptions
	 */
	public void updateBulkPauseStatus(final Collection<SubscriberSubscription> subscriptions) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();
		final Session session = getSession(Levels.COMPLETE);
		try {

			for (final SubscriberSubscription subscriberSubscription : subscriptions) {
				subscriberSubscription.setStatus(SubscriptionStatusEnum.PAUSED.getValue());
				subscriberSubscription.setUpdatedOn(new Date());
				subscriberSubscription.setUpdatedBy(Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME);
				try {
					subscriptionRepository.update(session, subscriberSubscription);
					
					final Runnable emailTask = () -> {
						try {
							// send email to inform user about subscription's cancellation
							EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
									subscriberSubscription.getSiteId(), subscriberSubscription.getPlan()
											.getEmailSettingAttributes().isChangesubscriptionNotification(),null);
							
							// @formatter:off
							String messageLog = "Paused for subscription to " + subscriberSubscription.getPlan().getName();
							SubscriptionCommonService.getInstance().addWebhookActivity(new BaseEventBean(), session,
									subscriberSubscription, SubscriptionConstants.EVENT_PAUSE_SUBSCRIPTION, messageLog);
							// @formatter:on

						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					};
					BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

					
					
				} catch (final Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeExceptionLog();
				}
			}
		} finally {
			session.close();
		}
	}

	/**
	 * @param subscriptionId
	 * @param subscriberId
	 * @param baseEventBean
	 * @return
	 * @throws Exception
	 */
	public void reactivateSubscription(String subscriptionId, String subscriberId, BaseEventBean baseEventBean)
			throws Exception {

		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();

		final Session session = getSession(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);
			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);

			final SubscriptionPauseHelper pauseHelperService = new SubscriptionPauseHelper();
			pauseHelperService.setReactivateSubscription(subscriberSubscription);

			subscriptionRepository.update(session, subscriberSubscription);

			

			final Runnable emailTask = () -> {
				try {
					// send email to inform user about subscription's cancellation
					EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
							subscriberSubscription.getSiteId(), subscriberSubscription.getPlan()
									.getEmailSettingAttributes().isChangesubscriptionNotification(),null);
					
					// @formatter:off
					String messageLog = "Reactivate subscription to " + subscriberSubscription.getPlan().getName();
					SubscriptionCommonService.getInstance().addWebhookActivity(baseEventBean, session, subscriberSubscription,
							SubscriptionConstants.EVENT_REACTIVATE_SUBSCRIPTION, messageLog);
					// @formatter:on

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.UPDATE_FAILED);

		} finally {
			session.close();

		}

	}

	private Session getSession(final Levels level) {
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(level);
		return session;
	}

}
