package com.jio.subscriptionengine.batchprocessing.modules.subscription.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;

import com.elastic.search.bean.BasicOperations;
import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.bean.SubscriptionResource;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
/**
 * @author : Dipti.Mehendale
 * 
 */
public class SubscriptionRepository {

	public SearchResult<SubscriptionResource> getSubscriberPlansById(Session session, String subscriberId,
			OrderBy order, int page, int pageSize, String q, String status, DateRange dateRange, String Trial)
			throws ElasticSearchException {
		// TODO Auto-generated method stub
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		Map<String, Object> filters = new HashMap<>();
		// set site id
		// filters.put(SubscribedplansConstants.SITE_ID, siteId);
		filters.put(SubscriptionConstants.SUBSCRIBER_ID, subscriberId);
		if (q != null) {
			filters.put(SubscriptionConstants.SUB_PLAN_NAME, q);
		}
		if (status != null) {
			filters.put(SubscriptionConstants.STATUS, status);
		}
		if (dateRange != null) {
			filters.put(SubscriptionConstants.STARTED_ON, dateRange);
		}
		List<OrderBy> orders = new ArrayList<>();
		// order by check
		if (order != null) {
			/*
			 * OrderBy ord = new OrderBy("subscriber." + order.getField(), order.getOrder(),
			 * order.getField().contains("createdOn") ? null : "String");
			 */
			// orders.add(ord);

			orders.add(order);
		}

		// page related
		Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}
		if (Trial != null && Trial.equalsIgnoreCase("Y")) {

			BasicOperations o = new BasicOperations();
			o.gt(new Date().getTime());
			filters.put("trialEndDate", o);

		} else if (Trial != null && Trial.equalsIgnoreCase("N")) {

			BasicOperations o = new BasicOperations();
			o.lte(new Date().getTime());
			// o.equals(null);
			filters.put("trialEndDate", o);

		}
		SearchResult<SubscriberSubscription> searchResult = session.get(SubscriberSubscription.class, orders, filters,
				qPage);
		SearchResult<SubscriptionResource> resposne = new SearchResult<>();
		resposne.setDocumentsCount(searchResult.getDocumentsCount());
		resposne.setPage(searchResult.getPage());
		resposne.setTime(searchResult.getTime());

		List<SubscriptionResource> dto = new ArrayList<>();
		Iterator<SubscriberSubscription> itr = searchResult.getResult().iterator();
		// storing the current date
		// Date currentDate = new Date();

		while (itr.hasNext()) {

			SubscriberSubscription sub = itr.next();
			// Fields required by ui from large data
			SubscriptionResource pdto = new SubscriptionResource();
			pdto.setId(sub.getId());
			pdto.setPlanName(sub.getPlan().getName());
			pdto.setStartedOn(sub.getStartedOn());
			pdto.setStatus(sub.getStatus());
			pdto.setNextBillingDate(sub.getNextBillingDate());
			pdto.setLogo(sub.getPlan().getLogo());
			pdto.setTrialEndDate(sub.getTrialEndDate());
			if (sub.getTrialEndDate() != null) {
				if (new Date().after(sub.getTrialEndDate())) {
					pdto.setInTrial(false);
				} else {
					pdto.setInTrial(true);
				}

			}

			// if(Trial.equalsIgnoreCase("Y")) {
			// filters.put("inTrial",true);
			// }
			// else if (Trial.equalsIgnoreCase("N")) {
			// filters.put("inTrial",false);
			// }

			dto.add(pdto);
		}

		resposne.setResult(dto);

		return resposne;
	}

	public Terms getSubscriptionStatusFilters(DateRange dateRange, String q, String subscriberId, Session session)
			throws Exception, SecurityException {
		// TODO Auto-generated method stub
		// logger

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		Map<String, Object> filters = new HashMap<>();

		filters.put(SubscriptionConstants.SUBSCRIBER_ID, subscriberId);
		// check date range
		if (dateRange != null) {
			filters.put(SubscriptionConstants.STARTED_ON, dateRange);
		}

		return session.aggregation(SubscriberSubscription.class,
		SubscriptionConstants.STATUS, filters);
		
	}

	/**
	 * @param session
	 * @param subscriberSubscription
	 * @throws Exception
	 */
	public void update(final Session session, final SubscriberSubscription subscriberSubscription) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.merge(subscriberSubscription);

	}

	public SubscriberSubscription getSubscriptionById(Session session, String subscriptionId)
			throws ElasticSearchException {
		// TODO Auto-generated method stub
		return session.getObject(SubscriberSubscription.class, subscriptionId);
	}

	public SearchResult<Invoice> getInvoiceDetails(final Session session, String subscriberId, String subscriptionId,int page, int pageSize)
			throws ElasticSearchException {
		// TODO Auto-generated method stub
		Map<String, Object> filters = new HashMap<>();
		// set site id
		// filters.put(SubscribedplansConstants.SITE_ID, siteId);
		// page related
		Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}
		filters.put(SubscriptionConstants.SUBSCRIBER_ID, subscriberId);
		filters.put(SubscriptionConstants.SUBSCRIPTION_SUBSCRIBERID, subscriptionId);
		

		SearchResult<Invoice> searchResult = session.get(Invoice.class, filters,qPage);
		return searchResult;
	}

	public Terms getTrialCount(DateRange dateRange, String q, String subscriberId, Session session)
			throws NoSuchFieldException, SecurityException {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		Map<String, Object> filters = new HashMap<>();

		filters.put(SubscriptionConstants.SUBSCRIBER_ID, subscriberId);
		// check date range
		if (dateRange != null) {
			filters.put(SubscriptionConstants.STARTED_ON, dateRange);
		}
		BasicOperations o = new BasicOperations();
		o.gt(new Date().getTime());
		filters.put("trialEndDate", o);
		// BasicOperations o1 = new BasicOperations() ;
		// o1.lte(new Date().getTime());
		// filters.put("trialEndDate",o1);

		// return session.aggregation(SubscriberSubscription.class,
		// SubscriptionConstants.STATUS, filters);
		return session.aggregation(SubscriberSubscription.class, "trialEndDate", filters);
	}

	public Terms getnonTrialCount(DateRange dateRange, String q, String subscriberId, Session session)
			throws NoSuchFieldException, SecurityException {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		Map<String, Object> filters = new HashMap<>();

		filters.put(SubscriptionConstants.SUBSCRIBER_ID, subscriberId);
		// check date range
		if (dateRange != null) {
			filters.put(SubscriptionConstants.STARTED_ON, dateRange);
		}
		BasicOperations o = new BasicOperations();
		o.gt(new Date().getTime());
		filters.put("trialEndDate", o);
		BasicOperations o1 = new BasicOperations();
		o1.lte(new Date().getTime());
		filters.put("trialEndDate", o1);

		return session.aggregation(SubscriberSubscription.class, "trialEndDate", filters);
	}

	/**
	 * @param filters
	 * @param session
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public SearchResult<SubscriberSubscription> getSubscriptionsByFilters(final Map<String, Object> filters, final Session session, Page page)
			throws Exception {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();


		return session.get(SubscriberSubscription.class,  filters, page);
	}

}
