package com.jio.subscriptionengine.batchprocessing.modules.subscription.service;

import java.util.HashMap;
import java.util.Map;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.enums.Levels;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Invoice;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.bean.SubscriptionResource;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.repository.SubscriptionRepository;

/**
 * @author : Dipti.Mehendale
 * 
 */
public class SubscriptionService {
	private SubscriptionRepository subscriptionRepository = new SubscriptionRepository();

	/**
	 * @param subscriberId
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public BaseResponse<SearchResult<SubscriptionResource>> getSubscriberPlansById(final String subscriberId,
			final OrderBy order, final int page, final int pageSize, final String q, final String status,
			final DateRange dateRange, final String Trial) throws ElasticSearchException {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);
		final SearchResult<SubscriptionResource> result = subscriptionRepository.getSubscriberPlansById(session,
				subscriberId, order, page, pageSize, q, status, dateRange, Trial);
		final BaseResponse<SearchResult<SubscriptionResource>> baseResponse = new BaseResponse<SearchResult<SubscriptionResource>>(
				result);
		return baseResponse;
	}

	public BaseResponse<Map<String, Object>> getSubscriptionFilters(DateRange dateRange, String q, String subscriberId)
			throws Exception {
		// TODO Auto-generated method stub
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		Map<String, Object> responseFilters = new HashMap<>();

		// Subscription status filter
		Terms subscriptionTerm = subscriptionRepository.getSubscriptionStatusFilters(dateRange, q, subscriberId,
				session);

		Map<String, Long> subscriptionStatus = new HashMap<>();

		long total = 0;
		for (Terms.Bucket bucket : subscriptionTerm.getBuckets()) {
			total += bucket.getDocCount();
			if (!subscriptionStatus.containsKey(bucket.getKeyAsString())) {
				subscriptionStatus.put(bucket.getKeyAsString(), 0l);
			}
			subscriptionStatus.put(bucket.getKeyAsString(),
					(subscriptionStatus.get(bucket.getKeyAsString()) + bucket.getDocCount()));
		}

		subscriptionStatus.put("TOTAL", total);
		responseFilters.put("SUBSCRIPTION_STATUS", subscriptionStatus);

		BaseResponse<Map<String, Object>> response = new BaseResponse<>(responseFilters);
		return response;
	}

	public SubscriberSubscription getSubscription(final String subscriberId, final String subscriptionId)
			throws ElasticSearchException {
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);
		final SubscriberSubscription result = subscriptionRepository.getSubscriptionById(session, subscriptionId);
		return result;
	}

	public BaseResponse<SearchResult<Invoice>> getInvoiceDetails(final String subscriberId, final String subscriptionId,
			final int page, final int pageSize) throws ElasticSearchException {
		// TODO Auto-generated method stub
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);
		final SearchResult<Invoice> result = subscriptionRepository.getInvoiceDetails(session, subscriberId,
				subscriptionId, page, pageSize);
		final BaseResponse<SearchResult<Invoice>> baseResponse = new BaseResponse<SearchResult<Invoice>>(result);
		return baseResponse;
	}

	public BaseResponse<Map<String, Object>> getTrialCountFilters(final DateRange dateRange, final String q,
			final String subscriberId) throws NoSuchFieldException, SecurityException {
		// TODO Auto-generated method stub
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final Map<String, Object> responseFilters = new HashMap<>();

		// Subscription status filter
		final Terms subscriptionTerm = subscriptionRepository.getTrialCount(dateRange, q, subscriberId, session);
		final Terms subscriptionTerm1 = subscriptionRepository.getnonTrialCount(dateRange, q, subscriberId, session);

		final Map<String, Long> subscriptionStatus = new HashMap<>();

		long total = 0;
		for (final Terms.Bucket bucket : subscriptionTerm.getBuckets()) {
			total += bucket.getDocCount();
		}

		long total1 = 0;
		for (final Terms.Bucket bucket : subscriptionTerm1.getBuckets()) {
			total1 += bucket.getDocCount();
		}

		subscriptionStatus.put("trial", total);
		subscriptionStatus.put("nonTrial", total1);
		responseFilters.put("count", subscriptionStatus);

		final BaseResponse<Map<String, Object>> response = new BaseResponse<>(responseFilters);
		return response;
	}

	/**
	 * @param filters
	 * @param level
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public SearchResult<SubscriberSubscription> findSubscriptionsByFilters(final Map<String, Object> filters,
			final Levels level, final Page page) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(level);
		final SearchResult<SubscriberSubscription> result = subscriptionRepository.getSubscriptionsByFilters(filters,
				session, page);
		return result;
	}

	public SearchResult<SubscriberSubscription> getSubscriptions(final QueryBuilder queryBuilder, final Page page) throws ElasticSearchException {
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);
		try {

			final SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
			searchSourceBuilder.query(queryBuilder);

			final SearchRequest builder = session.getSearchRequestBuilder(SubscriberSubscription.class);
			builder.source(searchSourceBuilder);

			return session.get(SubscriberSubscription.class, builder, page);

		} catch (final ElasticSearchException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw e;
		} finally {
			session.close();
		}
	}

}
