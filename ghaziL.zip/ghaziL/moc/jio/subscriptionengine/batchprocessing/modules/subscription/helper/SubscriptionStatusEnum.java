package com.jio.subscriptionengine.batchprocessing.modules.subscription.helper;

public enum SubscriptionStatusEnum {
	
	CANCELED("Canceled"),
	TERMINATED("Terminated"),
	EXPIRED("Expired"),
	PAUSED("Paused"),
	RENEWING("Renewing");
	
	private String value;  

	private SubscriptionStatusEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
