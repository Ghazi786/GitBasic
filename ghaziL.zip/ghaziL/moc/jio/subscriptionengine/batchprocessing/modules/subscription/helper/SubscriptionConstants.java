package com.jio.subscriptionengine.batchprocessing.modules.subscription.helper;

public class SubscriptionConstants {

	public static final String SUBSCRIBER_ID = "subscriberId";
	public static final String SUBSCRIPTION_ID = "id";
	public static final String SUBSCRIPTION_SUBSCRIBERID ="subscriptionSubscriberId";
	public static final String CYCLE_TO_SKIP = "cycle_to_skip";
	public static final String BILLING_DATE = "billing_date";
	public static final String ALREADY_CANCELLED = "Plan Is Already Cancelled";
	public static final String PLAN_NAME = "name";
	public static final String PLAN_ID = "planId";
	public static final String SITE_ID = "siteId";
	public static final String ID = "id";

	public static final String STATUS = "status";
	public static final Object TRUE = "true";
	public static final Object FALSE = "false";

	public static final String PERIOD_START_DATE = "periodStartDate";

	public static final String q = "q";

	public static final  String FROM_DATE = "from_date";

	public static final String TO_END = "to_end";

	public static final  String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static final String SORT = "sort";

	public static final String ORDER = "order";

	public static final String ASC = "ASC";

	public static final String PAGE = "page";

	public static final String PAGE_SIZE = "page_size";

	public static final String WILDCARD = "wildcard";

	public static final String SUBSCRIBER_NAME = "subscriberName";

	public static final String STARTED_ON = "startedOn";

	public static final String NEXT_INVOIVE = "nextBillingDate";
	public static final String CREATED_ON = "createdOn";
	public static final String TRIAL_STATUS = "subscriber.status";

	public static final String SUBSCRIPTION_STATUS = "subscription_status";

	public static final String FIRST_NAME = "subscriber.firstName";

	public static final String LAST_NAME = "subscriber.lastName";

	public static final String SUB_CREATED_ON = "subscriber.createdOn";
	public static final String SUB_PLAN_NAME = "plan.name";

	public static final String ENABLED_KEY = "plan.autoRenew";
	public static final String PAYMENT_STATUS = "payment_status";
	public static final String AUTOMATIC = "AUTOMATIC";
	public static final String MANUAL = "MANUAL";

	public static final String CANCEL_TIME_FRAME_TYPE_TERM_END = "termEnd";
	public static final String CANCEL_TIME_FRAME_TYPE_PERIOD_END = "periodEnd";
	public static final String CANCEL_TIME_FRAME_TYPE_TERMINATE = "terminate";
	public static final String Trial = "trial";

	public static final String EVENT_CANCEL_SUBSCRIPTION = "cancel-subscription";
	public static final String EVENT_TERMINATE_SUBSCRIPTION = "terminate-subscription";
	public static final String EVENT_PAUSE_SUBSCRIPTION = "pause-subscription";
	public static final String EVENT_CANCEL_PAUSE_SUBSCRIPTION = "cancel-pause-subscription";
	public static final String EVENT_UPDATE_BILLING_DATE = "update-billing-date-subscription";
	public static final String EVENT_CANCEL_REACTIVE_SUBSCRIPTION = "reactive-subscription";
	public static final String EVENT_CREATE_SUBSCRIPTION = "create-subscription";
	public static final String EVENT_SCHEDULED_PAUSE_SUBSCRIPTION = "scheduled-pause-subscription";

	public static final String INVALID_ACCESS = "Invalid subscribtion access";
	public static final String UPDATE_FAILED = "Unable to update Subscription info";
	public static final String UNABLE_TO_CANCEL_SUBSCRIPTION = "Unable to cancel subscription";
	public static final String EVENT_REACTIVATE_SUBSCRIPTION = "reactivate-subscription";
	
	//Email
	public static final String CANCEL_EMAIL = "cancel";
	public static final String RENEW_EMAIL = "renew";
	public static final String EXPIRE_TERMEND_EMAIL = "expire-term-end-subscription";
	public static final String EXPIRE_PERIODEND_EMAIL = "expire-period-end-subscription";
	
	//
	public static final String RENEW_EMAIL_MESSAGE = "Renew Subscription";
	public static final String EXPIRE_TERMEND_EMAIL_MESSAGE = "Expiring Term End  Subscription";
	public static final String CANCEL_EMAIL_MESSAGE = "Canceled Subscription";
	public static final String EXPIRE_PERIOD_END_MESSAGE = "Expiring Period End  Subscription";
	
	public static final String EVENT_TERMINATE_SUBSCRIPTIONS = "terminate-subscriptions";
	public static final String EVENT_RENEWING_SUBSCRIPTIONS = "renewing-subscriptions";
	
	//Webhook activity
	public static final String CANCELLATION_TIME_FRAME = "cancellationTimeFrame";
	public static final String PERIOD_ENDT_DATE = "periodEndDate";
	public static final String TERM_END_DATE = "termEndDate";
	
	
}
