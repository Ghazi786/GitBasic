package com.jio.subscriptionengine.batchprocessing.modules.subscription.service;

import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;

/**
 * This is common helper service 
 * @author Samrudhi.Gandhe
 *
 */
public class SubscriptionCommonService {
	private static final SubscriptionCommonService subscriptionCommonService = new SubscriptionCommonService();
	
	private  SubscriptionCommonService() {
	}
	
	public static final SubscriptionCommonService getInstance(){
		return subscriptionCommonService;
	}

	public void addWebhookActivity( final BaseEventBean baseEventBean, final Session session,
			final SubscriberSubscription subscriberSubscription, final String evenName, final String messageLog) {
		
//		final AccountsService accountsService = new AccountsService();
//		final Subscriber subscriberById = accountsService.getSubscriberById(subscriberId);
		
		final Subscriber subscriber = subscriberSubscription.getSubscriber();
		
		final String siteId = subscriberSubscription.getPlan().getSiteId();

		ServiceCommunicator.triggerWebHook(baseEventBean, session, SubscriberSubscription.class,
				subscriberSubscription.getId(), siteId, subscriber.getId(), evenName);
		addLogActivity(baseEventBean, subscriberSubscription, messageLog);
	}

	//@formatter:off
	public void addLogActivity( final BaseEventBean baseEventBean, 
								final SubscriberSubscription subscriberSubscription, 
								final String messageLog) {
	//@formatter:on
		final Subscriber subscriberById = subscriberSubscription.getSubscriber();
		final String siteId = subscriberSubscription.getPlan().getSiteId();

		//@formatter:off
		final String name = subscriberById   != null
							? subscriberById.getFirstName() + " " + subscriberById.getLastName()
							: Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME;
		//@formatter:on
		ServiceCommunicator.logActivity(baseEventBean, siteId, subscriberSubscription.getSubscriberId(),
				name + " " + Constants.DEFAULT_LOG_PLATFORM, messageLog);
	}

	
	public void checkSubscriberAccess(final String subscriberId, final SubscriberSubscription subscriberSubscription)
			throws BaseException {
		if (!subscriberSubscription.getSubscriberId().equals(subscriberId)) {
			throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.INVALID_ACCESS);
		}
	}


}
