package com.jio.subscriptionengine.batchprocessing.modules.subscription.service;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.eclipse.jetty.http.HttpStatus;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

import com.elastic.search.enums.Levels;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailHandler;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionStatusEnum;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.repository.SubscriptionRepository;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionCancellationService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionCommonService;

/**
 * This is helper class to perform all business logic on subscription while
 * cancel/terminate actions
 * 
 * @author Samrudhi.Gandhe
 *
 */
public class SubscriptionCancellationService {

	private static final SubscriptionCancellationService cancellationService = new SubscriptionCancellationService();
	private static final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();

	private SubscriptionCancellationService() {
	}

	public static final SubscriptionCancellationService getInstance() {
		return cancellationService;
	}

	/**
	 * Cancel Subscription
	 * 
	 * @param subscriptionId
	 * @param subscriberId
	 * @param timeFrame
	 * @param baseEventBean
	 * @return
	 * @throws Exception
	 */
	public void cancelSubscription(final String subscriptionId, final String subscriberId, final String timeFrame,
			final BaseEventBean baseEventBean) throws Exception {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);

			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);

			if (!SubscriptionStatusEnum.CANCELED.getValue().equals(subscriberSubscription.getStatus())) {
				subscriberSubscription.setStatus(SubscriptionStatusEnum.CANCELED.getValue());
				subscriberSubscription.setUpdatedBy(subscriberSubscription.getSubscriberId());
				subscriberSubscription.setUpdatedOn(new Date());
				subscriberSubscription.setPaused(false);
				subscriberSubscription.setCancellationTimeFrame(timeFrame);

				subscriptionRepository.update(session, subscriberSubscription);

				final Runnable emailTask = () -> {
					try {
						// send email to inform user about subscription's cancellation
						EmailHandler.triggerEmail(subscriberSubscription,
								EmailTemplateConstants.SUBSCRIPTION_CANCELLED_LABEL, subscriberSubscription.getSiteId(),
								subscriberSubscription.getPlan().getEmailSettingAttributes()
										.isCanceledsubscriptionNotification(),null);
						
						// @formatter:off
						final String messageLog = "Scheduled Cancelled subscription to "
								+ subscriberSubscription.getPlan().getName();
						SubscriptionCommonService.getInstance().addWebhookActivity(baseEventBean, session,
								subscriberSubscription, SubscriptionConstants.EVENT_CANCEL_SUBSCRIPTION, messageLog);
						// @formatter:on
						
					} catch (final Exception e) {
						// TODO Auto-generated catch block
						DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
								this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
								.writeExceptionLog();
					}

				};
				BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);

				

			} else {
				throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.ALREADY_CANCELLED);
			}
		} catch (final BaseException e) {
			throw e;
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw e;
		} finally {
			session.close();
		}
	}

	/**
	 * Terminate
	 * 
	 * @param subscriptionId
	 * @param subscriberId
	 * @param baseEventBean
	 * @return
	 * @throws Exception
	 */
	public void terminate(final String subscriptionId, final String subscriberId, final BaseEventBean baseEventBean)
			throws Exception {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		SubscriberSubscription subscriberSubscription;

		try {
			subscriberSubscription = subscriptionRepository.getSubscriptionById(session, subscriptionId);

			SubscriptionCommonService.getInstance().checkSubscriberAccess(subscriberId, subscriberSubscription);

			if (!SubscriptionStatusEnum.CANCELED.getValue().equals(subscriberSubscription.getStatus())) {
				subscriberSubscription.setUpdatedBy(subscriberSubscription.getSubscriberId());

				performTermination(baseEventBean, session, subscriberSubscription);
			} else {
				throw new BaseException(HttpStatus.BAD_REQUEST_400, SubscriptionConstants.ALREADY_CANCELLED);
			}
		} catch (final BaseException e) {
			throw e;
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw e;
		} finally {
			session.close();
		}
	}


	public void updateBulkExpireStatus(final Collection<SubscriberSubscription> subscriptions) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);
		try {

			for (final SubscriberSubscription subscriberSubscription : subscriptions) {

				subscriberSubscription.setUpdatedBy(Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME);
				try {
					performTermination(new BaseEventBean(), session, subscriberSubscription);
				} catch (final Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeExceptionLog();
				}
			}
		} finally {
			session.close();
		}
	}
	
	public QueryBuilder cancelQuery(final Date sdate, final Date edate) throws Exception	{
		
		final BoolQueryBuilder q1 = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(SubscriptionConstants.STATUS, SubscriptionStatusEnum.CANCELED.getValue()));
		final BoolQueryBuilder q2 = QueryBuilders.boolQuery()
				.must(QueryBuilders.matchQuery(SubscriptionConstants.CANCELLATION_TIME_FRAME, SubscriptionConstants.CANCEL_TIME_FRAME_TYPE_PERIOD_END))
				.must(QueryBuilders.rangeQuery(SubscriptionConstants.PERIOD_ENDT_DATE).gte(sdate.getTime()).lte(edate.getTime()));

		final BoolQueryBuilder q3 = QueryBuilders.boolQuery()
				.must(QueryBuilders.matchQuery(SubscriptionConstants.CANCELLATION_TIME_FRAME, SubscriptionConstants.CANCEL_TIME_FRAME_TYPE_TERM_END))
				.must(QueryBuilders.rangeQuery(SubscriptionConstants.TERM_END_DATE).gte(sdate.getTime()).lte(edate.getTime()));

		final BoolQueryBuilder q4 = QueryBuilders.boolQuery().should(q2).should(q3);

		final QueryBuilder query1 = QueryBuilders.boolQuery()

				.must(q1).must(q4);

		
		return query1;
		
	}
	
	public void postWebhookCancelSubscriptionData(final Collection<SubscriberSubscription> result, final BaseEventBean baseEventBean) {
		final Map<String, List<SubscriberSubscription>> subBySiteId = result.stream()
				.collect(Collectors.groupingBy(SubscriberSubscription::getSiteId));
		
		final Map<String,Object> subMap=new HashMap<String, Object>();

		for (final Entry<String, List<SubscriberSubscription>> sub : subBySiteId.entrySet()) {
			final Runnable webHookTask = () -> {
				try {

					// @formatter:off
					
					subMap.clear();
					
					subMap.put("subscriberSubscriptions", sub.getValue());

					ServiceCommunicator.triggerWebHook(baseEventBean, sub.getKey(), subMap,
							Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME,
							SubscriptionConstants.EVENT_TERMINATE_SUBSCRIPTIONS);

					// @formatter:on

				} catch (final Exception e) {

					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeExceptionLog();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(webHookTask);
		}
		
	}
	
	//@formatter:off
	public void performTermination(final BaseEventBean baseEventBean,
									final Session session, 
									final SubscriberSubscription subscriberSubscription) throws Exception {
	//@formatter:on
		
		subscriberSubscription.setStatus(SubscriptionStatusEnum.TERMINATED.getValue());
		subscriberSubscription.setUpdatedOn(new Date());
		subscriberSubscription.setPaused(false);
		subscriberSubscription.setCancellationTimeFrame(null);

		subscriptionRepository.update(session, subscriberSubscription);
		
		final Runnable emailTask = () -> {
			try {
				// @formatter:off
				final String messageLog = "Terminate subscription to " + subscriberSubscription.getPlan().getName();
				SubscriptionCommonService.getInstance().addWebhookActivity(baseEventBean, session,
						subscriberSubscription, SubscriptionConstants.EVENT_TERMINATE_SUBSCRIPTION, messageLog);
				// @formatter:on

				// send email to inform user about subscription's cancellation
				EmailHandler.triggerEmail(subscriberSubscription, EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
						subscriberSubscription.getSiteId(), subscriberSubscription.getPlan().getEmailSettingAttributes()
								.isExpiredsubscriptionNotification(),null);
				
			} catch (final Exception e) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
			}

		};
		BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(emailTask);
	}


}
