package com.jio.subscriptionengine.batchprocessing.modules.subscription.service;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

import com.elastic.search.enums.Levels;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.IntervalUnit;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.invoice.service.InvoiceService;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.ChecksumHelper;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.ChecksumRequestFlowTypes;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.PaymentResponseTypes;
import com.jio.subscriptionengine.batchprocessing.modules.payment.service.PaymentChecksumService;
import com.jio.subscriptionengine.batchprocessing.modules.payment.service.PaymentService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscriptionDetailsHelperService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionStatusEnum;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.repository.SubscriptionRepository;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.DateUtil;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;
import com.jio.subscriptions.modules.bean.PaymentLink;
import com.jio.subscriptions.modules.bean.PaymentTransactionInfo;

public class SubscriptionRenewService {

	private static final SubscriptionRenewService pauseService = new SubscriptionRenewService();

	private SubscriptionRenewService() {
	}

	public static final SubscriptionRenewService getInstance() {
		return pauseService;
	}

	public void updateBulkRenewStatus(final Collection<SubscriberSubscription> subscriptions) {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		final SubscriptionRepository subscriptionRepository = new SubscriptionRepository();
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);
		InvoiceService invoiceService = new InvoiceService();
		boolean result = false;

		try {
			for (SubscriberSubscription subscription : subscriptions) {
				final Plan plan = subscription.getPlan();
				Date renewsOn = subscription.getRenewsOn();

				int subscriptionCycle = subscription.getRemainingBillingCount();
				if (subscriptionCycle < 1) {
					subscription.setUpdatedBy(Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME);
					try {
						SubscriptionCancellationService.getInstance().performTermination(new BaseEventBean(), session,
								subscription);//
					} catch (final Exception e) {
						DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
								this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
								.writeExceptionLog();
					}
				}

				double marketPlacePricePerUnit = plan.getMarketPlacePricePerUnit().getUnitAmount();
				if (marketPlacePricePerUnit != 0) {
					//// ----TODO
					if (plan.isAutoRenew() || subscription.getId() != null) {
						// TODO Payment auto renew call
						/// ------TODO
						if (subscription.getId() != null) {
							// Calculate Subscription billing amount

							com.jio.subscriptionengine.batchprocessing.modules.payment.service.PaymentChecksumService paymentService = PaymentChecksumService
									.getInstance();
							ChecksumHelper checksumHelper = ChecksumHelper.getInstance();

							final SubscriptionDetailsHelperService detailsHelperService = new SubscriptionDetailsHelperService();
							final Currency currency = detailsHelperService.calculateBillingAmount(plan,
									subscription.getQnt(), 1);

							final double totalTxnAmount = currency.getUnitAmount();
							// final String totalTxCurrency = currency.getCode();
							// final BigDecimal price = new BigDecimal(totalTxnAmount).setScale(2);

							// will get madateId from subscription but field not yet available??
							/// -------TODO
							String mandateId = subscription.getId();

							final ObjectNode checkSumInfo = checksumHelper.getSICardDebitCheckSumInfo(totalTxnAmount,
									mandateId);
							// String checksumString = checksumHelper.setChecksum(checkSumInfo);

							final PaymentTransactionInfo transactionInfo = checksumHelper
									.getTransactionInfoForAutoRenew(checkSumInfo, subscription.getSubscriberId());
							transactionInfo.setRequestFlowType(ChecksumRequestFlowTypes.AUTO_RENEW_PLAN.getValue());
							transactionInfo.setSubscriptionId(subscription.getSubscriberId());
//							transactionInfo.setChecksumData(checkSumInfo.get("autoDebitChecksumString").asText());

							paymentService.addTransactionInfo(transactionInfo);

							final JsonNode response = paymentService.sendSIDebitRequest(checkSumInfo);

							final String status = response.get("error_code").asText();
//							transactionInfo.setChecksumResponseData(response.toString());
							transactionInfo.setChecksumStatus(
									PaymentResponseTypes.APPROVED.getValue().equals(status) ? "Success" : "Failed");

							paymentService.updateTransactionInfo(transactionInfo);

							/// Mandate fail case
							if (transactionInfo.getChecksumStatus().equals("Failed")) {
								final PaymentLink link = new PaymentLink();
								link.setSubscriberId(subscription.getSubscriberId());
								link.setSubscriptionSubscriberId(subscription.getId());
								link.setPaymentChecksumFlow(ChecksumRequestFlowTypes.RENEW_REGISTRATION.getValue());
								link.setCreatedOn(new Date());
								link.setActive(true);

								final String addPaymentLinkId = new PaymentService().addPaymentLink(link);
								// TODO Send Email with link Id
								continue;
							}
						}

						// mandate not set, send link for manual
						else {

							continue;
						}
					}
				}

				// renew calculation

				final Date periodStartDate = subscription.getNextBillingDate();
				final IntervalUnit intervalUnit = plan.getIntervalUnit();
				final String type = intervalUnit.getType();

				final int intervalValue = intervalUnit.getValue();
				final Date periodEndDate = DateUtil.getDateByType(periodStartDate, type, intervalValue);

				subscription.setPeriodStartDate(periodStartDate);
				subscription.setPeriodEndDate(periodEndDate);
				subscription.setPaused(false);
				subscription.setPausedCycleCount(0);
				subscription.setNextBillingDate(periodEndDate);
				int res = subscription.getRemainingBillingCount();
				subscription.setRemainingBillingCount(res > 0 ? res - 1 : 0);
				if (res > 0) {
					final Currency totalAmount = new SubscriptionDetailsHelperService().calculateBillingAmount(plan,
							subscription.getQnt(), subscription.getRemainingBillingCount());
					subscription.setTermBalance(totalAmount);
					result = invoiceService.createRenewFeeInvoice(subscription);
				}

				// update subscription acc to new renew details

				if (result)
					subscriptionRepository.update(session, subscription);
			}
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		} finally {
			session.close();
		}

	}

	public QueryBuilder renewQuery(final Date sdate, final Date edate) throws Exception {

		final BoolQueryBuilder q1 = QueryBuilders.boolQuery()
				.must(QueryBuilders.matchQuery(SubscriptionConstants.STATUS, SubscriptionStatusEnum.PAUSED.getValue()));

		final BoolQueryBuilder q2 = QueryBuilders.boolQuery().must(
				QueryBuilders.matchQuery(SubscriptionConstants.STATUS, SubscriptionStatusEnum.RENEWING.getValue()));

		final BoolQueryBuilder q3 = QueryBuilders.boolQuery().must(
				QueryBuilders.rangeQuery(SubscriptionConstants.NEXT_INVOIVE).gte(sdate.getTime()).lte(edate.getTime()));

		final BoolQueryBuilder q4 = QueryBuilders.boolQuery().should(q1).should(q2);

		final QueryBuilder query1 = QueryBuilders.boolQuery()

				.must(q4).must(q3);

		return query1;

	}

	public void postWebhookRenewSubscriptionData(Collection<SubscriberSubscription> result,
			final BaseEventBean baseEventBean) {
		Map<String, List<SubscriberSubscription>> subBySiteId = result.stream()
				.collect(Collectors.groupingBy(SubscriberSubscription::getSiteId));

		Map<String, Object> subMap = new HashMap<String, Object>();

		for (Entry<String, List<SubscriberSubscription>> sub : subBySiteId.entrySet()) {
			final Runnable webHookTask = () -> {
				try {

					// @formatter:off
					
					subMap.clear();
					
					subMap.put("subscriberSubscriptions", sub.getValue());

					ServiceCommunicator.triggerWebHook(baseEventBean, sub.getKey(), subMap,
							Constants.DEFAULT_MARKETPLACE_UPDATE_BY_USER_NAME,
							SubscriptionConstants.EVENT_RENEWING_SUBSCRIPTIONS);

					// @formatter:on

				} catch (final Exception e) {

					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeExceptionLog();
				}

			};
			BatchProcessingBootStrapper.getInstance().getThreadPoolService().execute(webHookTask);
		}

	}

}
