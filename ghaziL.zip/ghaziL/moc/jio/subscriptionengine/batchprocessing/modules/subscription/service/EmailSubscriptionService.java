package com.jio.subscriptionengine.batchprocessing.modules.subscription.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailHandler;

public class EmailSubscriptionService {

	private static final EmailSubscriptionService service = new EmailSubscriptionService();

	private EmailSubscriptionService() {
	}

	public static final EmailSubscriptionService getInstance() {
		return service;
	}

	/**
	 * @param result
	 * @param emailTemplateName
	 */
	public void sendBulkEmail(final Collection<SubscriberSubscription> result, final String emailTemplateName, 
			final Predicate<? super SubscriberSubscription> canceledsubscriptionNotification) {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		
		final List<Map<String, Object>> subscriptionBySiteId = result.stream().filter(canceledsubscriptionNotification)
				.map(p -> {
					final Map<String, Object> map = new HashMap<>();
					map.put("to", p.getSubscriber().getEmail());
					map.put("cc", p.getSubscriber().getCcEmail());
					map.put("siteId", p.getSiteId());
					map.put("contentObj", p);
					return map;

				}).collect(Collectors.toList());

		EmailHandler.getInstance().sendBulkMail(emailTemplateName, subscriptionBySiteId);
	}

	public Predicate<? super SubscriberSubscription> isCanceledsubscriptionNotification() {
		return p -> p.getPlan().getEmailSettingAttributes().isCanceledsubscriptionNotification();
	}
	public Predicate<? super SubscriberSubscription> isNewInvoiceNotification() {
		return p -> p.getPlan().getEmailSettingAttributes().isNewInvoiceNotification();
	}

}
