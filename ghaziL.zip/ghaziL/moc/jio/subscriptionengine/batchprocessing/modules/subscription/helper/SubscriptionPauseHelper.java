package com.jio.subscriptionengine.batchprocessing.modules.subscription.helper;

import java.util.Date;

import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.IntervalUnit;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscriptionDetailsHelperService;
import com.jio.subscriptionengine.batchprocessing.utils.DateUtil;

/**
 *This is helper class to perform all business logic on subscription while pause/resume actions
 * @author Samrudhi.Gandhe
 *
 */
public class SubscriptionPauseHelper { 
	
	/**
	 * @param cycleToSkip
	 * @param subscriberSubscription
	 */
	public void setPauseDetails(final int cycleToSkip, final SubscriberSubscription subscriberSubscription) {
		
		final Date currentPeriodStartDate = subscriberSubscription.getPeriodStartDate();
		final Date endDate = new Date().compareTo(currentPeriodStartDate) < 0 ? currentPeriodStartDate : subscriberSubscription.getPeriodEndDate();
		final IntervalUnit intervalUnit = subscriberSubscription.getPlan().getIntervalUnit();
        
		// Calculate next billing date after paused duration
		final int dateCountsToSkip = cycleToSkip * intervalUnit.getValue();
		final Date newEndDate = DateUtil.getDateByType(endDate, intervalUnit.getType(), dateCountsToSkip);

		subscriberSubscription.setNextBillingDate(newEndDate);

		// Extend the term end date as per billing cycle counts
		final Date newTermEndDate = DateUtil.getDateByType(subscriberSubscription.getTermEndDate(),
				intervalUnit.getType(), dateCountsToSkip);

		subscriberSubscription.setTermEndDate(newTermEndDate);

		// Set paused flag to avoid auto billing & next invoice generation
		subscriberSubscription.setPaused(true);

		// Set paused billing cycle count to re-calculate next invoice & term end date
		// if paused is cancelled or resumed
		subscriberSubscription.setPausedCycleCount(cycleToSkip);

		subscriberSubscription.setUpdatedOn(new Date());
		subscriberSubscription.setUpdatedBy(subscriberSubscription.getSubscriberId());
	}

	/**
	 * @param subscriberSubscription
	 */
	public void setCancelPausedDetails(final SubscriberSubscription subscriberSubscription) {
		final Date endDate = subscriberSubscription.getPeriodEndDate();
		subscriberSubscription.setNextBillingDate(endDate);
		
		final Plan plan = subscriberSubscription.getPlan();
		// Use billingCycle count to re-calculate term end date
		final IntervalUnit intervalUnit = plan.getIntervalUnit();
		final int cycleToSkip = subscriberSubscription.getPausedCycleCount();
		final int dateCountsToSkip = cycleToSkip *intervalUnit.getValue();
		final Date termEndDate = subscriberSubscription.getTermEndDate();
		final Date newTermEndDate = DateUtil.getDateByType(termEndDate, intervalUnit.getType(), dateCountsToSkip*-1);
		
		// Set nextBillingDate as per trial Info
		if (plan.getTrialInterval() != null) {
			subscriberSubscription.setNextBillingDate(subscriberSubscription.getPeriodStartDate());
		} else {
			subscriberSubscription.setNextBillingDate(subscriberSubscription.getPeriodEndDate());
		}
		
		subscriberSubscription.setTermEndDate(newTermEndDate);
		//Reset the paused info
		subscriberSubscription.setStatus(SubscriptionStatusEnum.RENEWING.getValue());
		subscriberSubscription.setPaused(false);
		subscriberSubscription.setPausedCycleCount(0);
		
		subscriberSubscription.setUpdatedOn(new Date());
		subscriberSubscription.setUpdatedBy(subscriberSubscription.getSubscriberId());
	}
	
	/**
	 * @param subscriberSubscription
	 */
	public void setResumeDetails(final SubscriberSubscription subscriberSubscription) {
		
		//Calculate current period dates
		final Date periodStartDate = new Date();
		final Plan plan = subscriberSubscription.getPlan();
		final IntervalUnit intervalUnit = plan.getIntervalUnit();
		final int intervalValue = intervalUnit.getValue();
		final Date periodEndDate = DateUtil.getDateByType(periodStartDate, intervalUnit.getType(), intervalValue);
		
		subscriberSubscription.setPeriodStartDate(periodStartDate);
		subscriberSubscription.setPeriodEndDate(periodEndDate);
		
		// Use billingCycle count to re-calculate term end date
		final Date nextBillingDate = DateUtil.getDateByType(new Date(), intervalUnit.getType(), intervalValue);
		final int remainingBillingCount = subscriberSubscription.getRemainingBillingCount();
		subscriberSubscription.setNextBillingDate(nextBillingDate);
		subscriberSubscription.setRemainingBillingCount(remainingBillingCount - 1);
		final int termBillingCount = remainingBillingCount *intervalValue;
		final Date newTermEndDate = DateUtil.getDateByType(new Date(), intervalUnit.getType(), termBillingCount);
		
		subscriberSubscription.setTermEndDate(newTermEndDate);
		
		//Calculate remaining termBalance
		final SubscriptionDetailsHelperService detailsHelperService = new SubscriptionDetailsHelperService();
		final Currency termBalance = detailsHelperService.calculateBillingAmount(plan, subscriberSubscription.getQnt(), subscriberSubscription.getRemainingBillingCount());
		subscriberSubscription.setTermBalance(termBalance);
		
		//Reset the paused info
		subscriberSubscription.setStatus(SubscriptionStatusEnum.RENEWING.getValue());
		subscriberSubscription.setPaused(false);
		subscriberSubscription.setPausedCycleCount(0);
		
		subscriberSubscription.setUpdatedOn(new Date());
		subscriberSubscription.setUpdatedBy(subscriberSubscription.getSubscriberId());
	}
	
	public void setReactivateSubscription(final SubscriberSubscription subscriberSubscription) {
		
		//For Reactivating Subscription
		subscriberSubscription.setStatus(SubscriptionStatusEnum.RENEWING.getValue());
		subscriberSubscription.setCancellationTimeFrame(null);
		subscriberSubscription.setPaused(false);
		subscriberSubscription.setPausedCycleCount(0);
		
		subscriberSubscription.setUpdatedOn(new Date());
		subscriberSubscription.setUpdatedBy(subscriberSubscription.getSubscriberId());
		
	}
	
	
	/**
	 * @param cycleToSkip
	 * @param subscriberSubscription
	 */
	public void recalculatePauseCycle(final int cycleToSkip, final SubscriberSubscription subscriberSubscription) {

		final Date endDate = subscriberSubscription.getPeriodEndDate();
		
		final int pendingBillingCycle = calculatePendingPausedCount(subscriberSubscription);
		final int billingCountToBeAdjust = cycleToSkip - pendingBillingCycle;
		final int totalPausedCount = subscriberSubscription.getPausedCycleCount() + billingCountToBeAdjust;
		subscriberSubscription.setPausedCycleCount(totalPausedCount);
		
		final IntervalUnit intervalUnit = subscriberSubscription.getPlan().getIntervalUnit();

		// Calculate next billing date after paused duration
		final int dateCountsToSkip = totalPausedCount * intervalUnit.getValue();
		final Date newEndDate = DateUtil.getDateByType(endDate, intervalUnit.getType(), dateCountsToSkip);

		subscriberSubscription.setNextBillingDate(newEndDate);

		// Extend the term end date as per billing cycle counts
		final Date newTermEndDate = DateUtil.getDateByType(subscriberSubscription.getTermEndDate(),
				intervalUnit.getType(), billingCountToBeAdjust);

		subscriberSubscription.setTermEndDate(newTermEndDate);

		// Set paused flag to avoid auto billing & next invoice generation
		subscriberSubscription.setPaused(true);
	}

	/**
	 * @param subscriberSubscription
	 * @return
	 */
	public int calculatePendingPausedCount(final SubscriberSubscription subscriberSubscription){
		final Date currentDate = new Date();
		int usedBillingCycle = 0;
		Date pauseStartDate = subscriberSubscription.getPeriodEndDate();

		final IntervalUnit intervalUnit = subscriberSubscription.getPlan().getIntervalUnit();
		for (int i = 1; i <= subscriberSubscription.getPausedCycleCount(); i++) {
			final Date pausePeriodicallyBillingEndDate = DateUtil
					.getDateByType(subscriberSubscription.getPeriodEndDate(), intervalUnit.getType(), i);

			if (currentDate.after(pausePeriodicallyBillingEndDate) || pauseStartDate.before(currentDate)) {
				usedBillingCycle++;
				pauseStartDate = pausePeriodicallyBillingEndDate;
			}
		}

		return subscriberSubscription.getPausedCycleCount() - usedBillingCycle;
	}
	
}
