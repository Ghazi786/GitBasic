package com.jio.subscriptionengine.batchprocessing.modules.subscription.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class SubscriptionResource {
	
	private String id;
	private String planName;
	private String status ;
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date startedOn ;
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date nextBillingDate;
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date trialEndDate;
   private boolean inTrial ;
   private String logo ;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getStartedOn() {
		return startedOn;
	}
	public void setStartedOn(Date startedOn) {
		this.startedOn = startedOn;
	}
	public Date getNextBillingDate() {
		return nextBillingDate;
	}
	public void setNextBillingDate(Date nextBillingDate) {
		this.nextBillingDate = nextBillingDate;
	}
	public SubscriptionResource() {
		
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Date getTrialEndDate() {
		return trialEndDate;
	}
	public void setTrialEndDate(Date trialEndDate) {
		this.trialEndDate = trialEndDate;
	}
	public boolean isInTrial() {
		return inTrial;
	}
	public void setInTrial(boolean inTrial) {
		this.inTrial = inTrial;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	
}
