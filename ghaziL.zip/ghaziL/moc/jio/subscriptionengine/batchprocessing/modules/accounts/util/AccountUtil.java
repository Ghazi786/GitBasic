package com.jio.subscriptionengine.batchprocessing.modules.accounts.util;

import java.util.regex.Pattern;

import org.eclipse.jetty.http.HttpStatus;

import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;

public class AccountUtil {

	public static boolean isEmailValid(String email) {
		final Pattern EMAIL_REGEX = Pattern.compile(
				"^[_a-z0-9A-Z]+(\\.[_a-z0-9A-Z]+)*@[A-Za-z0-9-]+(\\.[a-z0-9-]+)*(\\.[A-Za-z]{2,4})$",
				Pattern.MULTILINE);
		return EMAIL_REGEX.matcher(email).matches();
	}

	public static boolean isPasswordValid(String pswd) {
		final Pattern PSWD_REGEX = Pattern.compile("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,}$",
				Pattern.MULTILINE);
		return PSWD_REGEX.matcher(pswd).matches();
	}
	
	public static boolean isFirstNameValid(String name) {
		final Pattern PSWD_REGEX = Pattern.compile("^[a-zA-Z]+$",
				Pattern.MULTILINE);
		return PSWD_REGEX.matcher(name).matches();
	}

	public void checkValidation(Subscriber subscriber) throws Exception {

		try {

			if (!isEmailValid(subscriber.getEmail())) {
				throw new BaseException(HttpStatus.BAD_REQUEST_400, "Email must of valid Format Ex: random@ril.com ");
			}
			
			if (!isEmailValid(subscriber.getUsername())) {
				throw new BaseException(HttpStatus.BAD_REQUEST_400, "Username must of valid Format Ex: random@ril.com ");
			}
			
			if (!isFirstNameValid(subscriber.getFirstName())) {
				throw new BaseException(HttpStatus.BAD_REQUEST_400, "FirstName must of valid Format Ex: random ");
			}

			if (subscriber.getPassword() != null) {
				if (!isPasswordValid(subscriber.getPassword())) {
					throw new BaseException(HttpStatus.BAD_REQUEST_400,
							"Password must of valid Format Ex: random@123 ");
				}

			}
		} catch (BaseException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			throw e;

		}
	}

	public String genrateRandom(String randomString) {
		int size = 4;

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(size);

		for (int i = 0; i < size; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (randomString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(randomString.charAt(index));

		}
		return sb.toString();
	}

}
