package com.jio.subscriptionengine.batchprocessing.modules.accounts.helper;

/**
 * @author Alpesh.Sonar
 *
 */
public class AccountConstant {

	public static final String SUBSCRIBER_EXIST = "Subscriber already exists";

	public static final String UNIQUE_CONSTRAINT_FALIED = "Unique constraint failed";

	public static final String SUBSCRIBER_SAVE_ERROR = "An error occurred while saving a subscriber";

	public static final String SUBSCRIBER_EXIST_UPDATE = "Unable to update subscriber, username already exists";
	
	public static final String SUBSCRIBER_UPDATE_ERROR = "An error occurred while updating a subscriber";

	public static final String DELETED_SUCCESSFULLY = " deleted Subscriber successfully";
	public static final String DELETED_BIILINGINFO_SUCCESSFULLY = " deleted billing info successfully";
	public static String SUBSCRIPTION_STATUS = "subscription_status";
	
	public static String STATUS = "status";

	public static String ACCOUNT_STATUS = "subscriber.status";

	
	public static final String SUBSCRIBER_DELETE_ERROR = "An error occurred while deleting a Plan";

	public static final String SITE_ID = "siteId";

	public static final String FIRST_NAME = "subscriber.firstName";

	public static final String LAST_NAME = "subscriber.lastName";
	
	public static final String EMAIL = "subscriber.email";

	public static final String COMPANY_NAME = "subscriber.companyName";

	public static final String CREATED_ON = "subscriber.createdOn";

	public static final String WILDCARD = "wildcard";

	public static final String SUBSCRIBER_DELETED_FAILURE = "Unable to delete subscriber";

	public static String SUBSCRIBER_ID = "subscriberId";
	public static String BILLING_ID = "billingId";
	
	// create single user
	
	
		
		public static final String IAM_HOST_URL = "http://10.32.131.213:7050/IAM/identity/";
		
		public static final String IAM_ERROR = "An error occurred while creating user in IAM";
		
		public static final String FIRST_NAME_USER = "firstName";
		
		public static final String USER_NAME = "userName";
		
		public static final String USER_PASSWORD = "userPassword";
		
		public static final String EMAIL_USER="email";
		
		public static final String ENCRYPTION_ERROR = "Error Occured in Encrypting the Password";
		
		public static final String DECRYPTION_ERROR = "Error Occured in Decrypting the Password";

		public static final String CREATED_BY = "EXTERNAL_API";
		
		


}
