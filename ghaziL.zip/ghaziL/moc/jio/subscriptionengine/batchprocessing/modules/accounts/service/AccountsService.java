package com.jio.subscriptionengine.batchprocessing.modules.accounts.service;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.Base64;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.eclipse.jetty.http.HttpStatus;
import org.json.JSONObject;

import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.blockchain.sdk.util.UniqueUUIDGenerator;
import com.jio.resttalk.service.custom.exceptions.RestTalkInvalidURLException;
import com.jio.resttalk.service.custom.exceptions.RestTalkServerConnectivityError;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.subscriptionengine.batchprocessing.clearCodes.ClearCodeLevel;
import com.jio.subscriptionengine.batchprocessing.clearCodes.ClearCodes;
import com.jio.subscriptionengine.batchprocessing.configurationManager.ConfigParamsEnum;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.accounts.helper.AccountConstant;
import com.jio.subscriptionengine.batchprocessing.modules.accounts.repository.AccountsRepository;
import com.jio.subscriptionengine.batchprocessing.modules.accounts.util.AccountUtil;
import com.jio.subscriptionengine.batchprocessing.modules.bean.BillingInfo;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberResource;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;

/**
 * @author Samrudhi.Gandhe
 *
 */
public class AccountsService {

	private final AccountsRepository accountsRepository = new AccountsRepository();

	String key = ConfigParamsEnum.SECRET_KEY.getStringValue();

	private JsonElement jsonElement;

	/**
	 * @param subscriber
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */
	public Subscriber createSubscriberAccount(final Subscriber subscriber)
			throws BaseException, ElasticSearchException {
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();

		try {
			final Subscriber existingSubscriber = accountsRepository.getSubscriberByEmail(session,
					subscriber.getEmail());
			if (existingSubscriber != null) {
				return existingSubscriber;
			}

			subscriber.setCreatedOn(new Date());
			accountsRepository.saveSubscriber(session, subscriber);
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_SUBSCRIBER_ACCOUNT_SERVICE_SUCCESS.getValue(),
					ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

		} catch (final Exception e) {

			// error
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (final Exception rollback) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
			}

			// unique constraint failed check
			if (e.getMessage().contains(AccountConstant.UNIQUE_CONSTRAINT_FALIED))
				throw new BaseException(HttpStatus.CONFLICT_409, AccountConstant.SUBSCRIBER_EXIST);

			// global error
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.SUBSCRIBER_SAVE_ERROR);

		} finally {
			session.close();
		}
		return subscriber;
	}

	/**
	 * @param subscriber
	 * @return
	 * @throws Exception
	 */
	public Subscriber udpateSubscriberAccount(final Subscriber subscriber) throws Exception {
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		String subscriberaccountId;
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();

		try {

			final Subscriber existingSubscriber = accountsRepository.getSubscriberByEmail(session,
					subscriber.getEmail());
			existingSubscriber.setAddress(subscriber.getAddress());
			existingSubscriber.setCcEmail(subscriber.getCcEmail());
			existingSubscriber.setCompanyName(subscriber.getCompanyName());
			existingSubscriber.setFirstName(subscriber.getFirstName());
			existingSubscriber.setLastName(subscriber.getLastName());
			existingSubscriber.setUpdatedOn(new Date());
			existingSubscriber.setUsername(subscriber.getUsername());
			existingSubscriber.setStatus(subscriber.getStatus());
			existingSubscriber.setCreatedBy(subscriber.getCreatedBy());
			accountsRepository.mergeSubscriber(session, existingSubscriber);
			subscriberaccountId = existingSubscriber.getId();
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_UPDATE_SUBSCRIBER_ACCOUNT_SERVICE_SUCCESS.getValue(),
					ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		} catch (final Exception e) {

			// error
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (final Exception rollback) {
				rollback.printStackTrace();
			}

			// unique constraint failed check
			if (e.getMessage().contains(AccountConstant.UNIQUE_CONSTRAINT_FALIED))
				throw new BaseException(HttpStatus.CONFLICT_409, AccountConstant.SUBSCRIBER_EXIST_UPDATE);

			// global error
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.SUBSCRIBER_UPDATE_ERROR);

		} finally {
			session.close();
		}
		return getSubscriberById(subscriberaccountId);
	}

	/**
	 * @param subscriberId
	 * @return
	 * @throws Exception
	 */
	public Subscriber getSubscriberById(final String subscriberaccountId) throws Exception {
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final Subscriber result = accountsRepository.getSubscriberById(session, subscriberaccountId);
		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_CUSTOMER_LIST_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		return result;
	}

	/**
	 * @param subscriberId
	 * @return
	 * @throws Exception
	 */
	public BillingInfo getBillingInfoBySubscriberId(final String subscriberId) throws Exception {
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final BillingInfo result = accountsRepository.getBillingInfoBySubscriberId(session, subscriberId);
		final BaseResponse<BillingInfo> baseResponse = new BaseResponse<BillingInfo>(result);
		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_BILLING_INFO_BY_SUBSCRIBERID_SERVICE_SUCCESS.getValue(),
				ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		return result;
	}

	/**
	 * delete subscriber account
	 * 
	 * @param subscriber
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */

	public void deleteSubscriberById(Subscriber baseResponse) {
		// TODO Auto-generated method stub
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			this.accountsRepository.deleteSubscriber(session, baseResponse);
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_DELETE_SUBSCRIBER_ACCOUNT_SERVICE_SUCCESS.getValue(),
					ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Add billing Info
	 * 
	 * @param BillingInfo
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */
	public BillingInfo addBillingInfo(BillingInfo subscriber) throws Exception {
		// TODO Auto-generated method stub
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();

		try {
			subscriber.setCreatedOn(new Date());
			accountsRepository.saveBillingInfo(session, subscriber);
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_ADD_BILLING_INFO_SERVICE_SUCCESS.getValue(),
					ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

		} catch (final Exception e) {

			// error
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (final Exception rollback) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
			}

			// unique constraint failed check
			if (e.getMessage().contains(AccountConstant.UNIQUE_CONSTRAINT_FALIED))
				throw new BaseException(HttpStatus.CONFLICT_409, AccountConstant.SUBSCRIBER_EXIST);

			// global error
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.SUBSCRIBER_SAVE_ERROR);

		} finally {
			session.close();
		}
		return subscriber;
	}

	/**
	 * update billing Info
	 * 
	 * @param BillingInfo
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */

	public BillingInfo udpateBillingInfo(BillingInfo billingInfo) throws Exception {
		// TODO Auto-generated method stub
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		final BillingInfo rs;
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();

		try {

			final BillingInfo existingBillingInfo = accountsRepository.getBillingInfoBySubscriberId(session,
					billingInfo.getSubscriberId());
			if (existingBillingInfo == null) {
				billingInfo.setSiteId("Marketplace");
				accountsRepository.saveBillingInfo(session, billingInfo);
			} else {
				existingBillingInfo.setIpAddress(billingInfo.getIpAddress());
				existingBillingInfo.setAddress(billingInfo.getAddress());
				existingBillingInfo.setServiceProvider(billingInfo.getServiceProvider());
				existingBillingInfo.setName(billingInfo.getName());
				existingBillingInfo.setCardLastFourDigits(billingInfo.getCardLastFourDigits());
				existingBillingInfo.setExpiration(billingInfo.getExpiration());
				existingBillingInfo.setType(billingInfo.getType());
				existingBillingInfo.setIpAddress(billingInfo.getIpAddress());

				accountsRepository.mergeBillingInfo(session, existingBillingInfo);
				ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_UPDATE_BILLING_INFO_SERVICE_SUCCESS.getValue(),
						ClearCodeLevel.SUCCESS);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			}

		} catch (final Exception e) {

			// error
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (final Exception rollback) {
				rollback.printStackTrace();
			}

			// unique constraint failed check
			if (e.getMessage().contains(AccountConstant.UNIQUE_CONSTRAINT_FALIED))
				throw new BaseException(HttpStatus.CONFLICT_409, AccountConstant.SUBSCRIBER_EXIST_UPDATE);

			// global error
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.SUBSCRIBER_UPDATE_ERROR);

		} finally {
			rs = accountsRepository.getBillingInfoBySubscriberId(session, billingInfo.getSubscriberId());
			session.close();
		}
		return rs;
		// return null;
	}

	/**
	 * get billing Info by subscriberId
	 * 
	 * @param subscriberId
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */

	public BillingInfo getSubscriberBillingInfoById1(final String subscriberId) throws Exception {
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final BillingInfo result = accountsRepository.getBillingInfoBySubscriberId(session, subscriberId);
		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_CUSTOMER_LIST_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		return result;
	}

	/**
	 * delete billing Info
	 * 
	 * @param BillingInfo
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */
	public void deleteBillingInfoById(BillingInfo baseResponse) {
		// TODO Auto-generated method stub
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			this.accountsRepository.deleteBillingIn(session, baseResponse);
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_DELETE_BILLING_INFO_SERVICE_SUCCESS.getValue(),
					ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * get billing Info
	 * 
	 * @param BillingInfo
	 *            id
	 * @return
	 * @throws BaseException
	 * @throws ElasticSearchException
	 */

	public BillingInfo getBillingInfoById(String billingId) throws Exception {
		// TODO Auto-generated method stub
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final BillingInfo result = accountsRepository.getBillinInfoById(session, billingId);
		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_BILLING_INFO_BY_BILLINGID_SERVICE_SUCCESS.getValue(),
				ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		return result;
	}

	/**
	 * Get Subscriber info by email id
	 * 
	 * @param email
	 * @return
	 * @throws ElasticSearchException
	 */
	public Subscriber getSubscriberByEmail(final String email) throws ElasticSearchException {
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final Subscriber result = accountsRepository.getSubscriberByEmail(session, email);
		session.close();
		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_ACCOUNT_INFO_BY_EMAIL_SERIVE_SUCCESS.getValue(),
				ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		return result;
	}

	/**
	 * @param username
	 * @return
	 * @throws ElasticSearchException
	 */
	public Subscriber getSubscriberByUsername(final String username) throws ElasticSearchException {
		// logger
		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final Subscriber result = accountsRepository.getSubscriberByUsername(session, username);
		session.close();
		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_ACCOUNT_INFO_BY_USERNAME_SERVICE_SUCCESS.getValue(),
				ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		return result;
	}

	/**
	 * Get Subscriber info by email id
	 * 
	 * @param email
	 * @return
	 * @throws ElasticSearchException
	 */
	public String getSubscriberByEmailAsString(final String email) throws ElasticSearchException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		final String result = accountsRepository.getSubscriberByEmailAsString(session, email);
		session.close();
		return result;
	}

	public String dogenerate(Subscriber subscriber) {

		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();

		String url = AccountConstant.IAM_HOST_URL;

		String autherizationKey = subscriber.getUsername() + ":" + subscriber.getPassword();

		String basicAuth = null;
		String token = null;

		try {
//			basicAuth = "Basic "
//					+ javax.xml.bind.DatatypeConverter.printBase64Binary(autherizationKey.getBytes("UTF-8"));
		} catch (Exception e1) {

			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_TOKEN_FAILURE.getValue(), ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

			e1.printStackTrace();
		}

		RestTalkResponse response;
		try {
			response = new RestTalkBuilder().Get(url).addCustomHeader("project", "JIO_SE_MARKETPLACE")
					.addCustomHeader("operation", "doLoginAndGenerateToken").addCustomHeader("Authorization", basicAuth)
					.send();

			token = response.getResponsHeaders().get("userToken");

		} catch (RestTalkInvalidURLException e) {

			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_TOKEN_FAILURE.getValue(), ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

			e.printStackTrace();
		} catch (RestTalkServerConnectivityError e) {

			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_TOKEN_FAILURE.getValue(), ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

			e.printStackTrace();
		}

		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_TOKEN_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

		return token;

	}

	public SubscriberResource createSingleUser(Subscriber subscriber) throws Exception {

		ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();

		String message = null;
		JSONObject json1 = new JSONObject();
		JSONObject json2 = new JSONObject();

		JSONObject jsonObj = new JSONObject();

		SubscriberResource subscriberResource = new SubscriberResource();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();

		try {

			final Subscriber existingSubscriber = accountsRepository.getSubscriberByEmail(session,
					subscriber.getEmail());
			if (existingSubscriber != null) {

				existingSubscriber.setPassword(decryption(existingSubscriber.getPassword(), key));

				String token = dogenerate(existingSubscriber);

				if (token == null) {
					throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.IAM_ERROR);
				}

				subscriberResource.setId(existingSubscriber.getId());
				subscriberResource.setUsername(existingSubscriber.getUsername());
				subscriberResource.setEmail(existingSubscriber.getEmail());
				subscriberResource.setToken(token);
				subscriberResource.setCreatedOn(existingSubscriber.getCreatedOn());
				subscriberResource.setCreatedBy(existingSubscriber.getCreatedBy());

				ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_USER_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

				return subscriberResource;

			}

			if (subscriber.getPassword() == null || subscriber.getPassword().isEmpty()) {
				String randomPswd = randomString(subscriber.getEmail());
				subscriber.setPassword(randomPswd);
			}

			if (subscriber.getId() == null || subscriber.getId().isEmpty()) {
				String id = UniqueUUIDGenerator.getInstance().getUniqueUUID();
				subscriber.setId(id);
			}

			String epswd = encryption(subscriber.getPassword(), key);

			jsonObj.put(AccountConstant.USER_NAME, subscriber.getUsername());
			jsonObj.put(AccountConstant.USER_PASSWORD, epswd);
			jsonObj.put(AccountConstant.EMAIL_USER, subscriber.getEmail());

			json1.put("userInfo", jsonObj);
			json2.put("AppData", json1);

			message = json2.toString();

			String url = AccountConstant.IAM_HOST_URL + "?operation=createSingleUser&creatingUser=admin";

			RestTalkResponse response = new RestTalkBuilder().Post(url).addCustomHeader("project", "JIO_SE_MARKETPLACE")
					.addRequestData(message).send();

			JsonObject body = new JsonParser().parse(response.answeredContent().responseString()).getAsJsonObject();
			JsonObject appData = (JsonObject) body.get("statusCode");

			JsonElement httpCode = appData.get("httpstatuscode");

			if (httpCode.getAsInt() == 200) {

				subscriber.setCreatedBy(AccountConstant.CREATED_BY);
				subscriber.setCreatedOn(new Date());

				String token = dogenerate(subscriber);

				if (token == null) {
					throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.IAM_ERROR);
				}

				// for storing password in ES in encrypted format
				subscriber.setPassword(epswd);

				accountsRepository.saveSingleSubscriber(session, subscriber);

				subscriberResource.setId(subscriber.getId());
				subscriberResource.setUsername(subscriber.getUsername());
				subscriberResource.setEmail(subscriber.getEmail());
				subscriberResource.setToken(token);
				subscriberResource.setCreatedBy(subscriber.getCreatedBy());
				subscriberResource.setCreatedOn(subscriber.getCreatedOn());
			}

			else {
				throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.IAM_ERROR);
			}

		}

		catch (BaseException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			throw e;

		}

		catch (Exception e) {

			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_USER_FAILURE.getValue(), ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

			try {
				if (session.isSessionActive())
					session.rollback();
			} catch (final Exception rollback) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();

				ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_USER_FAILURE.getValue(), ClearCodeLevel.SUCCESS);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			}

			// unique constraint failed check
			if (e.getMessage().contains(AccountConstant.UNIQUE_CONSTRAINT_FALIED))
				throw new BaseException(HttpStatus.CONFLICT_409, AccountConstant.SUBSCRIBER_EXIST);

			// global error
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.SUBSCRIBER_SAVE_ERROR);

		} finally {
			session.close();
		}

		ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CREATE_USER_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

		return subscriberResource;
	}

	public static String encryption(String input, String key) throws BaseException {
		byte[] crypted = null;

		try {

			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");

			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, skey);
			crypted = cipher.doFinal(input.getBytes());
		} catch (Exception e) {
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.ENCRYPTION_ERROR);
		}

		return new BigInteger(1, crypted).toString(16);
	}

	public static String decryption(String input, String key) throws BaseException {

		try {

			byte[] decodedHex = org.apache.commons.codec.binary.Hex.decodeHex(input.toCharArray());
			String result = Base64.getEncoder().encodeToString(decodedHex);

			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");

			byte[] encrypted = Base64.getDecoder().decode(result);

			Cipher aesCipher = Cipher.getInstance("AES");
			aesCipher.init(Cipher.DECRYPT_MODE, skey);
			String s = new String(aesCipher.doFinal(encrypted));

			return s;

		} catch (Exception e) {
			throw new BaseException(HttpStatus.BAD_REQUEST_400, AccountConstant.DECRYPTION_ERROR);
		}

	}

	public String randomString(String value) {

		AccountUtil accountUtil = new AccountUtil();

		// chose a Character random from this String
		String NumericString = "0123456789";
		String AlphaString = "abcdefghijklmnopqrstuvwxyz";

		int number = Integer.parseInt(accountUtil.genrateRandom(NumericString));

		String alpha = accountUtil.genrateRandom(AlphaString);

		String pswd = alpha + "@" + number;

		return pswd;
	}

}
