package com.jio.subscriptionengine.batchprocessing.modules.accounts.repository;

import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.BillingInfo;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Subscriber;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberActivity;

/**
 * @author Samrudhi.Gandhe
 *
 */
public class AccountsRepository {

	/**
	 * @param session
	 * @param subscriber
	 * @throws Exception
	 */
	public void saveSubscriber(Session session, Subscriber subscriber) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.save(subscriber);
	}

	/**
	 * To update Subscriber details
	 * 
	 * @param session
	 * @param subscriber
	 * @throws Exception
	 */
	public void mergeSubscriber(Session session, Subscriber subscriber) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.merge(subscriber);
	}

	/**
	 * get subscriber details by emailId
	 * 
	 * @param session
	 * @param email
	 * @return
	 * @throws ElasticSearchException
	 */
	public Subscriber getSubscriberByEmail(Session session, String email) throws ElasticSearchException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.getObject(Subscriber.class, "email", email);
	}

	/**
	 * @param session
	 * @param subscriberActivity
	 * @throws Exception
	 */
	public void log(Session session, SubscriberActivity subscriberActivity) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.save(subscriberActivity);
	}

	/**
	 * get subscriber information with subscriber id
	 * 
	 * @param session
	 * @param subscriberId
	 * @return
	 * @throws Exception
	 */
	public Subscriber getSubscriberById(Session session, String subscriberaccountId) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.getObject(Subscriber.class, subscriberaccountId);
	}

	/**
	 * get billing information with subscriber id
	 * 
	 * @param session
	 * @param subscriberId
	 * @return
	 * @throws Exception
	 */
	public BillingInfo getBillingInfoBySubscriberId(Session session, String subscriberId) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.getObject(BillingInfo.class, "subscriberId", subscriberId);
	}

	/**
	 * delete subscriber information
	 * 
	 * @param session
	 * @param subscriber
	 * @return
	 * @throws Exception
	 */
	public void deleteSubscriber(Session session, Subscriber baseResponse) {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			session.delete(baseResponse);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Add billing information
	 * 
	 * @param session
	 * @param BillingInfo
	 * @return
	 * @throws Exception
	 */
	public void saveBillingInfo(Session session, BillingInfo billingInfo) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.save(billingInfo);
	}

	/**
	 * Add billing information
	 * 
	 * @param session
	 * @param siteId
	 * @return
	 * @throws Exception
	 */
	public BillingInfo getBillingBySiteId(Session session, String siteId) throws ElasticSearchException {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.getObject(BillingInfo.class, "siteId", siteId);
	}

	/**
	 * update billing information
	 * 
	 * @param session
	 * @param BillingInfo
	 * @return
	 * @throws Exception
	 */

	public void mergeBillingInfo(Session session, BillingInfo existingSubscriber) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.merge(existingSubscriber);

	}

	/**
	 * delete billing information
	 * 
	 * @param session
	 * @param BillingInfo
	 * @return
	 * @throws Exception
	 */
	public void deleteBillingIn(Session session, BillingInfo baseResponse) {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			session.delete(baseResponse);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Add billing information
	 * 
	 * @param session
	 * @param Billingid
	 * @return
	 * @throws Exception
	 */
	public BillingInfo getBillinInfoById(Session session, String billingId) throws ElasticSearchException {
		// TODO Auto-generated method stub
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.getObject(BillingInfo.class, billingId);
	}

	/**
	 * @param session
	 * @param username
	 * @return
	 * @throws ElasticSearchException
	 */
	public Subscriber getSubscriberByUsername(Session session, String username) throws ElasticSearchException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.getObject(Subscriber.class, "username", username);
	}

	public String getSubscriberByEmailAsString(final Session session, final String email) throws ElasticSearchException {
		return session.getString(Subscriber.class, "email", email);
	}
	
	/**
	 * @param session
	 * @param subscriber
	 * @throws Exception
	 */
	public void saveSingleSubscriber(Session session, Subscriber subscriber) throws Exception {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		session.merge(subscriber);
	}

}
