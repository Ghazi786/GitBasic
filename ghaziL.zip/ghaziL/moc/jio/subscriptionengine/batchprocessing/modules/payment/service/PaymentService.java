package com.jio.subscriptionengine.batchprocessing.modules.payment.service;

import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.payment.repository.PaymentRepository;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscriptionDetailsHelperService;
import com.jio.subscriptions.modules.bean.PaymentLink;

/**
 * 
 * This service is used for payments
 * 
 * @author Samrudhi.Gandhe
 *
 */
public class PaymentService {

	private static PaymentRepository paymentRepository;
	static {
		paymentRepository = PaymentRepository.getInstance();
	}

	public String addPaymentLink(final PaymentLink paymentLink) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			paymentLink.setCreatedOn(new Date());
			// paymentLink.setActive(true);
			session.beginTransaction();
			paymentRepository.addPaymentLink(session, paymentLink);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500, "Error occured while created payment link ");
		} finally {
			session.close();
		}
		return paymentLink.getId();
	}

	public PaymentLink getPaymentLink(final String linkId) throws BaseException {
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {

			session.beginTransaction();
			return paymentRepository.getPaymentLink(session, linkId);

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500, "Error occured while fetching payment link ");
		} finally {
			session.close();
		}
	}

	public boolean validatePaymentLink(final PaymentLink paymentLink) throws BaseException {
		final Date createdOn = paymentLink.getCreatedOn();
		final Date expiryMinutes = DateUtils.addMinutes(createdOn, 7);

		return new Date().before(expiryMinutes) && paymentLink.isActive();
	}

	public ObjectNode getInfo(final PaymentLink paymentLink, final Plan plan) {

		final ArrayNode addons = JsonNodeFactory.instance.arrayNode();
		plan.getAddOns().stream().filter(p -> !p.isOptionalAdOns()).forEach(e -> {
			final ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
			objectNode.put("code", e.getAddOnCode());
			objectNode.put("quantity", 1);
			addons.add(objectNode);
		});

		final ArrayNode items = JsonNodeFactory.instance.arrayNode();
		plan.getItems().stream().filter(p -> !p.isOptionalAdOns()).forEach(e -> {
			final ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
			objectNode.put("code", e.getItemCode());
			objectNode.put("quantity", 1);
			items.add(objectNode);
		});

		final ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
		objectNode.replace("items", items);
		objectNode.replace("addons", addons);
		objectNode.put("planId", paymentLink.getPlanId());
		objectNode.put("subscriberId", paymentLink.getSubscriberId());
		objectNode.put("callbackRedirectUrl", paymentLink.getCallbackRedirectUrl());

		try {
			final SubscriptionDetailsHelperService subscriptionDetailsHelperService = new SubscriptionDetailsHelperService();
			subscriptionDetailsHelperService.setPlanAddonsDetails(objectNode, plan);
			final Currency calculateBillingAmount = subscriptionDetailsHelperService.calculateBillingAmount(plan, 1, 1);

			if (plan.getSetupFeeAttributes() != null) {
				calculateBillingAmount.setUnitAmount(
						calculateBillingAmount.getUnitAmount() + plan.getSetupFeeAttributes().getUnitAmount());
			}
			objectNode.put("paymentAmount", calculateBillingAmount.getUnitAmount());
			objectNode.put("paymentCurrency", calculateBillingAmount.getCode());
		} catch (final Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return objectNode;
	}

	public void updatePaymentLink(final PaymentLink paymentLink) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			paymentRepository.updatePaymentLink(session, paymentLink);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500, "Error occured while updating payment link ");
		} finally {
			session.close();
		}
	}

//	public JsonNode  checkPaymentStatus(String txnRefNo) throws Exception {
//
//		final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("yyyyMMddhhmmss");
//		final Date currentDate = new Date();
//
//		final SessionFactory factory = SessionFactory.getSessionFactory();
//		final Session session = factory.getSession();
//
//		JsonNode  body = null;
//
//		String id = UniqueUUIDGenerator.getInstance().getUniqueUUID();
//
//		PaymentTransactionInfo mandateTransactionInfo = PaymentRepository.getInstance()
//				.getTransactionInfoByTxnRefNo(session, txnRefNo);
//
//		String tm = DATE_TIME_FORMAT.format(currentDate);
//
//		String checksumString = "CHECKPAYMENTSTATUS|" + tm + "|"
//				+ ConfigParamsEnum.PAYMENT_MERCHANT_ID.getStringValue();
//
//		String checksum = ChecksumHelper.getInstance().getChecksum(checksumString);
//
//		ObjectMapper mapper = new ObjectMapper();
//		ObjectNode rootNode = mapper.createObjectNode();
//		ObjectNode request = mapper.createObjectNode();
//
//		ObjectNode requestHeader = mapper.createObjectNode();
//
//		requestHeader.put("request_id", id);
//		requestHeader.put("api_name", "CHECKPAYMENTSTATUS");
//		requestHeader.put("timestamp", DATE_TIME_FORMAT.format(currentDate));
//
//		ObjectNode payloadData = mapper.createObjectNode();
//
//		ObjectNode tranRefNo = mapper.createObjectNode();
//
//		payloadData.put("mid", ConfigParamsEnum.PAYMENT_MERCHANT_ID.getStringValue());
//
//		// create ArrayNode object
//		ArrayNode arrayNode = mapper.createArrayNode();
//
//		arrayNode.add(PaymentFlowHelper.getInstance().getResponse(4, mandateTransactionInfo.getChecksumResponseData()));
//
//		tranRefNo.replace("tran_ref_no", arrayNode);
//		payloadData.replace("tran_details", tranRefNo);
//
//		payloadData.put("txntimestamp",
//				PaymentFlowHelper.getInstance().getResponse(9, mandateTransactionInfo.getChecksumResponseData()));
//
//		rootNode.replace("request_header", requestHeader);
//
//		rootNode.replace("payload_data", payloadData);
//
//		rootNode.put("checksum", checksum);
//
//		request.replace("request", rootNode);
//
//		String message = request.toString();
//
//		RestTalkResponse response;
//
//		try {
//			response = new RestTalkBuilder().Post(ConfigParamsEnum.PAYMENT_CHECK_PAYMENT_STATUS_API.getStringValue())
//					.addCustomHeader("Content-Type", "application/json").addCustomHeader("Accept", "application/json")
//					.addCustomHeader("APIVer", "3.1").addRequestData(message).send();
//
//			body = new ObjectMapper().readTree(response.answeredContent().responseString());
//
//		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {
//
//			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
//					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
//					.writeExceptionLog();
//			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500,
//					"Error occured while checking payment status ");
//		}
//		return body;
//
//	}

//	public boolean isCheckPaymentStatusSuccess(final String txnRefNo, final JsonNode  checkPaymentStatus)
//			throws Exception {
//		final ArrayNode txnInfos = (ArrayNode) checkPaymentStatus.get("checkpaymentstatus");
//		final Optional<JsonNode> maybeTxnInfo = StreamSupport.stream(txnInfos.spliterator(), false)
//				.filter(p -> p.get("tran_ref_no").asText().equals(txnRefNo)).findFirst();
//		return maybeTxnInfo.map(p -> PaymentResponseTypes.APPROVED.getValue().equals(p.get("error_code").asText()))
//				.orElse(false);
//	}

}
