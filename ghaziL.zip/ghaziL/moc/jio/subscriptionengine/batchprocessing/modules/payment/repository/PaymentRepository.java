package com.jio.subscriptionengine.batchprocessing.modules.payment.repository;

import java.util.HashMap;
import java.util.Map;

import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptions.modules.bean.PaymentCard;
import com.jio.subscriptions.modules.bean.PaymentLink;
import com.jio.subscriptions.modules.bean.PaymentMandate;
import com.jio.subscriptions.modules.bean.PaymentTransactionInfo;



/**
 * 
 * This repository will be used for payments
 * @author Samrudhi.Gandhe
 *
 */
public class PaymentRepository {

	private static PaymentRepository paymentRepository = new PaymentRepository();

	private PaymentRepository() {

	}

	public static PaymentRepository getInstance() {
		return paymentRepository;
	}

	/**
	 * 
	 * @param session
	 * @param payment
	 * @throws Exception
	 */
	public void addPaymentLink(Session session, PaymentLink paymentLink) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		session.save(paymentLink);
	}

	public PaymentLink getPaymentLink(Session session, String linkId) throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		try {
			return session.getObject(PaymentLink.class, linkId);
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void updatePaymentLink(final Session session, final PaymentLink paymentLink) throws Exception {
		session.merge(paymentLink);
	}

	public void addTransactionInfo(final Session session, final PaymentTransactionInfo payTransactionInfo) throws Exception {
		session.save(payTransactionInfo);
	}

	public PaymentTransactionInfo getTransactionInfoByTxnRefNo(final Session session, final String id) throws Exception {
		final Map<String, Object> filters = new HashMap<>();
		filters.put("txnRefNo.keyword", id);
		return session.getObject(PaymentTransactionInfo.class, filters);
	}
	public PaymentTransactionInfo getTransactionInfoByFilters(final Session session, final Map<String, Object> filters) throws Exception {
		return session.getObject(PaymentTransactionInfo.class, filters);
	}

	public void addPayMandate(Session session, PaymentMandate payMandate) throws Exception {
		session.merge(payMandate);

	}

	public void updateTransactionInfo(final Session session, final PaymentTransactionInfo payTransactionInfo)
			throws Exception {
		session.merge(payTransactionInfo);
	}

	public void addPaymentCard(final Session session, final PaymentCard paymentCard) throws Exception {
		session.save(paymentCard);

	}

}
