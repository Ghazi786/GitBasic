package com.jio.subscriptionengine.batchprocessing.modules.payment.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.subscriptionengine.batchprocessing.configurationManager.ConfigParamsEnum;
import com.jio.subscriptionengine.batchprocessing.core.HttpParamConstants;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.ChecksumHelper;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.ChecksumRequestFlowTypes;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.PaymentConstants;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.PaymentResponseTypes;
import com.jio.subscriptionengine.batchprocessing.modules.payment.repository.PaymentRepository;
import com.jio.subscriptionengine.batchprocessing.modules.plan.helper.PlanConstant;
import com.jio.subscriptionengine.batchprocessing.modules.plan.service.PlanService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.helper.SubscriptionDetailsHelperService;
import com.jio.subscriptionengine.batchprocessing.utils.MS;
import com.jio.subscriptions.modules.bean.PaymentCard;
import com.jio.subscriptions.modules.bean.PaymentMandate;
import com.jio.subscriptions.modules.bean.PaymentTransactionInfo;

/**
 * This class represents checksum creations and transactions
 * @author Samrudhi.Gandhe
 *
 */
/**
 * @author Ashish14.Gupta
 *
 */
public class PaymentChecksumService {

	private static PaymentChecksumService instance = new PaymentChecksumService();
	private ChecksumHelper checksumHelper = ChecksumHelper.getInstance();

	private PaymentChecksumService() {
	}

	public static PaymentChecksumService getInstance() {
		return instance;
	}


	

	// @formatter:off
	/**
	 * @param checkSumInfo
	 * @return
	 * @throws Exception
	 */
	public JsonNode sendSIDebitRequest(final ObjectNode checkSumInfo) throws Exception {
		final RestTalkResponse restResponse = new RestTalkBuilder()
				.Post(ConfigParamsEnum.PAYMENT_SI_DEBIT_API.getStringValue())
				.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.USER_SUBSCRIPTION_MS.name())
				.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
				.addCustomHeader("Content-Type", "application/json").addCustomHeader("Accept", "application/json")
				.addCustomHeader("APIVer", "4.0").addRequestData(checkSumInfo.toString()).send();
		// @formatter:on

		final String response = restResponse.answeredContent().responseString();
		return new ObjectMapper().readTree(response);
	}

	
	/**
	 * @param requestParams
	 * @param subscriptionId
	 * @param subscriberId
	 * @return
	 * @throws Exception
	 */
	public ObjectNode creatAutoRenewSubscriptionChecksum(final JsonNode requestParams, final String subscriptionId,
			final String subscriberId) throws Exception {

//		final ObjectNode checkSumInfo = getChecksumInfo(subscriberId, false);

		final ObjectNode checkSumInfo = null;
		// Get Subscription object
		// Calculate Subscription billing amount
		final double totalTxnAmount = 0;
		final String totalTxCurrency = "";
		final BigDecimal price = new BigDecimal(totalTxnAmount).setScale(2);

		checkSumInfo.put("transaction_amount", price.toString());
		checkSumInfo.put("transaction_currency", totalTxCurrency);
		checkSumInfo.put("productdescription", subscriptionId);
		checkSumInfo.put("subscriber_customerid", ""); // Mandate
		checkSumInfo.put("udf1", ""); // Mandate
		checkSumInfo.put("version", "3.3");

//		String checksumString = checksumHelper.setChecksum(checkSumInfo, requestParams);

		//		final PaymentTransactionInfo transactionInfo = checksumHelper.getTransactionInfo(requestParams, checkSumInfo,
//				subscriberId);
		PaymentTransactionInfo transactionInfo = new PaymentTransactionInfo();
		transactionInfo.setRequestFlowType(ChecksumRequestFlowTypes.AUTO_RENEW_PLAN.getValue());
		transactionInfo.setSubscriptionId(subscriptionId);
//		transactionInfo.setChecksumData("");
		transactionInfo.setAmount(price.doubleValue());

		addTransactionInfo(transactionInfo);

		return checkSumInfo;
	}

//	private ObjectNode getChecksumInfo(final String subscriberId, boolean isMandateFlow) throws Exception {
//		final Subscriber subscriber = new AccountsService().getSubscriberById(subscriberId);
//		final ObjectNode checkSumInfo = checksumHelper.getCheckSumInfo(isMandateFlow, subscriber);
//		return checkSumInfo;
//	}

	private Currency getTransactionAmount(final JsonNode requestParams, final Plan plan) throws Exception {
		final SubscriptionDetailsHelperService detailsHelperService = new SubscriptionDetailsHelperService();

		double totalTxnAmount = 0;

		// Add Subscription of plan
		detailsHelperService.setPlanAddonsDetails(requestParams, plan);

		int qnt = requestParams.hasNonNull("qnt") ? requestParams.get("qnt").asInt() : 1;
		final Currency calculateBillingAmount = detailsHelperService.calculateBillingAmount(plan, qnt, 1);

		final double unitAmount = calculateBillingAmount.getUnitAmount();

		double setupAmount = 0;

		if (plan.getSetupFeeAttributes() != null && plan.getSetupFeeAttributes().getUnitAmount() != 0) {
			setupAmount = plan.getSetupFeeAttributes().getUnitAmount();
			totalTxnAmount += setupAmount;
		}

		if (plan.getTrialInterval() == null || plan.getTrialInterval().getValue() == 0) {

			totalTxnAmount += unitAmount;
		}

		final String totalTxCurrency = calculateBillingAmount.getCode();
		final Currency currency = new Currency();
		currency.setUnitAmount(totalTxnAmount);
		currency.setCode(totalTxCurrency);
		return currency;
	}

	private Plan getPlan(final String planId) throws BaseException {
		final PlanService planService = new PlanService();
		final Plan plan = planService.getPlan(planId);
		if (plan == null) {
			throw new BaseException(HttpStatus.CONFLICT_409, PlanConstant.INVALID_PLAN);
		}
		return plan;
	}

	public String addTransactionInfo(final PaymentTransactionInfo payTransactionInfo) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			PaymentRepository.getInstance().addTransactionInfo(session, payTransactionInfo);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.CONFLICT_409, PaymentConstants.SAVE_PAYMENT_TRANSACTION_FAILURE);
		} finally {
			session.close();
		}
		return payTransactionInfo.getId();
	}

	public String addMandateInfo(final PaymentMandate payMandate) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			PaymentRepository.getInstance().addPayMandate(session, payMandate);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.CONFLICT_409, PaymentConstants.SAVE_PAYMENT_MANDATE_FAILURE);
		} finally {
			session.close();
		}
		return payMandate.getId();
	}

	public PaymentTransactionInfo getTransactionInfoByTxnRefNo(final String id) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			return PaymentRepository.getInstance().getTransactionInfoByTxnRefNo(session, id);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.CONFLICT_409,
					PaymentConstants.GET_PAYMENT_TRANSACTION_BY_REFERENCE_FAILURE);
		} finally {
			session.close();
		}
	}

	public PaymentTransactionInfo getTransactionInfoByFilters(final Map<String, Object> filters) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			return PaymentRepository.getInstance().getTransactionInfoByFilters(session, filters);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.CONFLICT_409, PaymentConstants.GET_PAYMENT_TRANSACTION_FAILURE);
		} finally {
			session.close();
		}
	}

	public void updateTransactionInfo(final PaymentTransactionInfo payTransactionInfo) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			payTransactionInfo.setUpdatedOn(new Date());
			payTransactionInfo.setUpdatedBy(payTransactionInfo.getSubscriberId());
			PaymentRepository.getInstance().updateTransactionInfo(session, payTransactionInfo);
			session.flush();
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.CONFLICT_409, PaymentConstants.UPDATE_PAYMENT_TRANSACTION_FAILURE);
		} finally {
			session.close();
		}
	}

	public PaymentTransactionInfo updateTransactionInfo(final String[] infos, String response) throws BaseException {

		final Map<String, Object> filters = new HashMap<>();
		filters.put("txnRefNo.keyword", infos[4]);
		filters.put("cmid.keyword", infos[3]);
		PaymentTransactionInfo transactionInfo = PaymentChecksumService.getInstance()
				.getTransactionInfoByFilters(filters);
//		transactionInfo.setChecksumResponseData(response);
		transactionInfo.setChecksumStatus(PaymentResponseTypes.APPROVED.getValue().equals(infos[0]) ? 
				PaymentResponseTypes.SUCCESS.getValue() : PaymentResponseTypes.FAILED.getValue());
		transactionInfo.setCardNumber(infos[10]);
//		transactionInfo.setTxnType(infos[11]);
		transactionInfo.setCardType(infos[12]);
		PaymentChecksumService.getInstance().updateTransactionInfo(transactionInfo);

		return transactionInfo;
	}

	public void addPaymentCard(PaymentCard paymentCard) throws BaseException {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		try {
			session.beginTransaction();
			PaymentRepository.getInstance().addPaymentCard(session, paymentCard);
			session.flush();
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.CONFLICT_409, PaymentConstants.SAVE_PAYMENT_CARD_FAILURE);
		} finally {
			session.close();
		}
	}

	public void addPaymentCard(final String[] infos, final String subscriberId) throws BaseException {
		final PaymentCard paymentCard = ChecksumHelper.getInstance().getPaymentCard(infos, subscriberId);
		addPaymentCard(paymentCard);
	}

	/**
	 * To calculate max transaction amount that we need to debit
	 * 
	 * @param requestParams
	 * @param plan
	 * @return
	 * @throws Exception
	 */
//	private Currency getMaxTransactionAmount(JsonNode requestParams, Plan plan) throws Exception {
//		final SubscriptionDetailsHelperService detailsHelperService = new SubscriptionDetailsHelperService();
//
//		// Add Subscription of plan
//		detailsHelperService.setPlanAddonsDetails(requestParams, plan);
//
//		int qnt = requestParams.hasNonNull("qnt") ? requestParams.get("qnt").asInt() : 1;
//		final Currency calculateBillingAmount = detailsHelperService.calculateBillingAmount(plan, qnt, 1);
//
//		final double unitAmount = calculateBillingAmount.getUnitAmount();
//
//		final double setupAmount = plan.getSetupFeeAttributes().getUnitAmount();
//
//		final double totalTxnAmount = unitAmount + setupAmount;
//
//		final String totalTxCurrency = calculateBillingAmount.getCode();
//		final Currency currency = new Currency();
//		currency.setUnitAmount(totalTxnAmount);
//		currency.setCode(totalTxCurrency);
//		return currency;
//	}

//	private ObjectNode createManualSubscription(final JsonNode requestParams, final String planId,
//			final String subscriberId, final ObjectNode checkSumInfo, final Currency currency, final BigDecimal price)
//			throws BaseException {
//		checkSumInfo.put("transaction_amount", price.toString());
//		checkSumInfo.put("transaction_currency", currency.getCode());
//		checkSumInfo.put("version", "5.0");
//		checkSumInfo.put("jm_acct_type", "");
//
//		checkSumInfo.put("si_flag", "N");
//
//		checkSumInfo.put("productdescription", ChecksumRequestFlowTypes.MANUAL_SUBSCRIBE_PLAN.getValue());
//
//		final String checksumString = checksumHelper.setChecksum(checkSumInfo, requestParams);
//
//		final PaymentTransactionInfo transactionInfo = checksumHelper.getTransactionInfo(requestParams, checkSumInfo,
//				subscriberId);
//		transactionInfo.setRequestFlowType(ChecksumRequestFlowTypes.MANUAL_SUBSCRIBE_PLAN.getValue());
//		transactionInfo.setPlanId(planId);
//		transactionInfo.setChecksumData(checksumString);
//		transactionInfo.setAmount(price.doubleValue());
//
//		addTransactionInfo(transactionInfo);
//
//		return checkSumInfo;
//	}

//	private ObjectNode getFreePlanChecksumInfo(final SubscriberSubscription subscriberSubscription) throws Exception {
//
//		final ObjectNode checkSumInfo = JsonNodeFactory.instance.objectNode();
//
//		checkSumInfo.put("isSubscription", "true");
//
//		checkSumInfo.putPOJO("subscriber", subscriberSubscription);
//
//		return checkSumInfo;
//	}

}
