package com.jio.subscriptionengine.batchprocessing.modules.wishlists.helper;

public class WishlistConstant {

	public static final String SUBSCRIBER_ID = "subscriberId";

	public static final String NAME = "name";

	public static final String PLAN_CODE = "planCode";

	public static final String DESCRIPTION = "description";

	public static final String WILDCARD = "wildcard";

	public static final String CREATED_ON = "createdOn";

	public static String FROM_DATE = "from_date";

	public static String TO_END = "to_end";

	public static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static String SORT = "sort";

	public static String ORDER = "order";

	public static String ASC = "ASC";

	public static String PAGE = "page";

	public static String PAGE_SIZE = "page_size";

	public static String q = "q";
	
	
	public static String GET_WISHLIST_ERROR = "error while getting wishlist with subscriberid";
	public static String GET_WISHLIST_ERROR_GetAllWishListId = "error while getting wishlist with subscriberid in getAllWishListId";
	public static String GET_WISHLIST_ERROR_IN_DELETE_METHOD = "error while getting wishlist with subscriberid and planId filters";
	public static String ADD_WISHLIST_ERROR = "error while adding wishlist ";
	
	public static String DELETE_WISHLIST_ERROR = "error while deleting wishlist ";
	public static String DUPLICATE_WISHLIST_ERROR = "Wishlist already exists for plan '%s' ";
	
	
	public static final String DELETE_SUCCESS="WishList Deleted Sucessfully";
	public static final String EXECUTION_STARTED_ADD_METHOD = "Execution started in add method";
	public static final String EXECUTION_STARTED_GET_METHOD = "Execution started in get method";
	public static final String EXECUTION_STARTED_DELETE_METHOD = "Execution started in delete method";
	public static final String EXECUTION_STARTED_GETID_METHOD = "Execution started in gesubscriptiontid method";
	public static final String EXECUTION_ENDED_ADD_METHOD = "Execution ended in added method";
	public static final String EXECUTION_ENDED_GET_METHOD = "Execution ended in get method";
	public static final String EXECUTION_ENDED_DELETE_METHOD = "Execution ended in delete method";
	public static final String EXECUTION_ENDED_GETID_METHOD = "Execution ended in getsubscriptionid method";
	public static final String SITE_UPDATE_ERROR = "An error occurred while updating a site";
	public static final String EXECUTION_ERROR_GET_METHOD = "Execution error in get method";
	public static final String EXECUTION_ERROR_DELETE_METHOD = "Execution error in delete method";
	public static final String EXECUTION_ERROR_ADD_METHOD = "Execution error in add method";
	public static final String EXECUTION_STARTED_DELETE_METHOD_CONTROLLER = "Execution started in delete method in controller";
	public static final String EXECUTION_STARTED_GETID_METHOD_CONTROLLER = "Execution started in get subscriber id method in controller";
	public static final String EXECUTION_STARTED_ADD_METHOD_CONTROLLER = "Execution started in add method in controller";
	public static final String EXECUTION_STARTED_GET_METHOD_CONTROLLER = "Execution started in get method in controller";
	public static final String EXECUTION_ENDED_ADD_METHOD_CONTROLLER = "Execution ended in add method in controller";
	public static final String EXECUTION_ENDED_GET_METHOD_CONTROLLER = "Execution ended in get method in controller";
	public static final String EXECUTION_ENDED_DELETE_METHOD_CONTROLLER = "Execution ended in delete method in controller";
	public static final String EXECUTION_ENDED_GETID_METHOD_CONTROLLER = "Execution ended in get subscriberid method in controller";
	public static final String EXECUTION_STARTED_ADD_METHOD_REPOSITORY = "Execution started in add method in repository";
	public static final String EXECUTION_STARTED_GET_METHOD_REPOSITORY = "Execution started in get method in repository";
	public static final String EXECUTION_STARTED_DELETE_METHOD_REPOSITORY = "Execution started in delete method in repository";
	public static final String EXECUTION_STARTED_GETID_METHOD_REPOSITORY = "Execution started in get BY SUBSCRIBERID method in repository";
}
