package com.jio.subscriptionengine.batchprocessing.modules.plan.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.sort.SortOrder;

import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.bean.WildCardSearch;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Category;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.plan.helper.PlanConstant;

public class PlanRepository {

	/**
	 * get plan by id
	 * 
	 * @param session
	 * @param id
	 * @return
	 * @throws ElasticSearchException
	 */
	public Plan getPlan(final Session session, final String id) throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		
		try {
		return session.getObject(Plan.class, id);
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
			.getLogBuilder(
					"Executing [ " + this.getClass().getName() + "."
							+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ] for plan id: "+ id,
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
			.writeLog();
	}
		return null;
	}
	
	public SearchResult<Plan> getAllPlanIds(Session session) throws ElasticSearchException {
		return session.get(Plan.class);
	}

	/**
	 * search plan by parameters
	 * 
	 * @param session
	 * @param siteId
	 * @param q
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public SearchResult<Plan> getPlans(Session session, String q, DateRange dateRange, OrderBy order,
			int page, int pageSize) throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		
		Map<String, Object> filters = new HashMap<>();
		filters.put("hidden", false); 
		// wildcard check
		if (q != null) {

			// fields on which we will perform wildcard search
			List<String> fields = new ArrayList<>();
			fields.add(PlanConstant.NAME);
			fields.add(PlanConstant.PLAN_CODE);
			fields.add(PlanConstant.DESCRIPTION);

			WildCardSearch search = new WildCardSearch(q, fields);
			filters.put(PlanConstant.WILDCARD, search);
		}

		// check date range
		if (dateRange != null) {
			filters.put(PlanConstant.CREATED_ON, dateRange);
		}

		List<OrderBy> orders = new ArrayList<>();
		// order by check
		if (order != null) {
			orders.add(order);
		} else {
			orders.add(new OrderBy("createdOn", SortOrder.DESC, "Double"));
		}

		// page related
		Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}

		return session.get(Plan.class, orders, filters, qPage);

	}
	
	/**
	 * get subscription Bucket info grouped on planId 
	 * @param session
	 * @param q
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	/**
	 * @param session
	 * @param q
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public List<Bucket> getPlansbyPopularity(Session session, String q, DateRange dateRange, OrderBy order,
			int page, int pageSize) throws ElasticSearchException {

		Map<String, Object> filters = new HashMap<>();
		filters.put("hidden", false); 
		// wildcard check
		if (q != null) {

			// fields on which we will perform wildcard search
			List<String> fields = new ArrayList<>();
			fields.add(PlanConstant.NAME);
			fields.add(PlanConstant.PLAN_CODE);
			fields.add(PlanConstant.DESCRIPTION);

			WildCardSearch search = new WildCardSearch(q, fields);
			filters.put(PlanConstant.WILDCARD, search);
		}

		// check date range
		if (dateRange != null) {
			filters.put(PlanConstant.CREATED_ON, dateRange);
		}

		List<OrderBy> orders = new ArrayList<>();
		// order by check
		if (order != null) {
			orders.add(order);
		}

		// page related
		Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}
		Terms term = null;
		try {
			term = session.aggregation(SubscriberSubscription.class, "plan.id.keyword");
			return (List<Bucket>) term.getBuckets();
		} catch (NoSuchFieldException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ArrayList<Bucket>();

	}
	
	/**
	 * get plan list based on filters provided
	 * @param session
	 * @param filters
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @param q 
	 * @return
	 * @throws ElasticSearchException
	 */
	public SearchResult<Plan> getPlansByFilters(final Session session, final Map<String, Object> filters, 
			final DateRange dateRange, 
			final OrderBy order,
			final int page, final int pageSize, final String q) throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		
		filters.put("hidden", false); 

		final List<OrderBy> orders = new ArrayList<>();
		// order by check
		if (order != null) {
			if (order.getField().contains("marketPlacePricePerTerm")) {
				final OrderBy ord = new OrderBy("marketPlacePricePerTerm.unitAmount", order.getOrder(), "Double");
				orders.add(ord);
			} else if (order.getField().contains("marketPlacePricePerUnit")) {
				final OrderBy ord = new OrderBy("marketPlacePricePerUnit.unitAmount", order.getOrder(), "Double");
				orders.add(ord);
			} else if (order.getField().contains("createdOn")) {
				final OrderBy ord = new OrderBy(order.getField(), order.getOrder(), "Double");
				orders.add(ord);
			} else {
				final OrderBy ord = new OrderBy(order.getField(), order.getOrder(), "String");
				orders.add(ord);
				
			}
		}

		// wildcard check
		if (q != null) {
			// fields on which we will perform wildcard search
			final List<String> fields = new ArrayList<>();
			fields.add(PlanConstant.NAME);
			fields.add(PlanConstant.PLAN_CODE);
			fields.add(PlanConstant.CATEGORY_NAME);

			final WildCardSearch search = new WildCardSearch(q, fields);
			filters.put(PlanConstant.WILDCARD, search);
		}

		// page related
		final Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}

		return session.get(Plan.class, orders, filters, qPage);

	}
	
	/**
	 * get count of plan subscription
	 * @param session
	 * @param planCode
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public List<Bucket> getPlansCount(Session session, String planCode, DateRange dateRange, OrderBy order,
			int page, int pageSize) throws ElasticSearchException {

		Map<String, Object> filters = new HashMap<>();
		// wildcard check
		if (planCode != null) {

			// fields on which we will perform wildcard search
			
			filters.put(PlanConstant.PLAN_CODE, planCode);
		}

		// check date range
		if (dateRange != null) {
			filters.put(PlanConstant.CREATED_ON, dateRange);
		}

		List<OrderBy> orders = new ArrayList<>();
		// order by check
		if (order != null) {
			orders.add(order);
		}

		// page related
		Page qPage = session.defaultPage();

		if (page > 0) {
			qPage.setPageNo(page);
		}

		if (pageSize > 0) {
			qPage.setPageLength(pageSize);
		}
		List<Bucket> list = null;
		Terms term = null;
		try {
			term = session.aggregation(SubscriberSubscription.class, "plan.id.keyword" ); 
			list = (List<Bucket>) term.getBuckets();
			list = list.stream().filter(x -> x.getKeyAsString().equalsIgnoreCase(planCode)).collect(Collectors.toList());
			
		} catch (NoSuchFieldException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}
	
	public SearchResult<Category> getPlancategories(Session session) throws ElasticSearchException {

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		return session.get(Category.class);
	}
	
	 /**
	   * get plan by id
	   * 
	   * @param session
	   * @param id
	   * @return
	   * @throws ElasticSearchException
	   */
	  public String getPlanString(Session session, String id) throws ElasticSearchException {
			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder("Executing [ " + this.getClass().getName() + "."
		                + Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
	    return session.getString(Plan.class, id);
	  }
}
