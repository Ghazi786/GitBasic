package com.jio.subscriptionengine.batchprocessing.modules.plan.helper;

/**
 * @author Alpesh.Sonar
 *
 */
public class PlanConstant {

	public static final String UNIQUE_CONSTRAINT_FALIED = "Unique constraint failed";

	public static final String INVALID_PLAN = "Invalid plan requested";

	public static final String SITE_ID = "siteId";

	public static final String NAME = "name";

	public static final String PLAN_CODE = "planCode";
	public static final String CATEGORY_NAME = "categoryName";

	public static final String DESCRIPTION = "description";

	public static final String WILDCARD = "wildcard";

	public static final String CREATED_ON = "createdOn";
	public static final String FETCH_PLAN_ERROR = "An error occurred while fetching a Plan detail";
	public static final String PLAN_LIST_FAILURE = "Error occured while fetching plan list";
	public static final String REDIS_RATINGS_KEY = "ratings";
	public static final String REDIS_REVIEW_COUNT_KEY = "review-count";
	public static final String REDIS_SUBSCRIPTION_COUNT_KEY = "subscription-count";
	public static final String REDIS_ALL_PLAN_LIST_KEY = "all-plans-list";
	public static final String REDIS_TOP_RATED_LIST_KEY = "top-rated-list";
	public static final String REDIS_POPULARITY_LIST_KEY = "popularity-list";
	public static final String REDIS_NO_PLAN_LIST_EXIST = "In Redis, No Plan Exist for key";

}
