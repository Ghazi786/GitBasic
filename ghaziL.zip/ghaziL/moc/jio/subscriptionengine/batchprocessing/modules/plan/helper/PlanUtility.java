package com.jio.subscriptionengine.batchprocessing.modules.plan.helper;

import java.util.List;

import org.apache.commons.lang.math.NumberUtils;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.plan.bean.PlanResource;
import com.jio.subscriptionengine.batchprocessing.redis.RedisOperationImpl;

/**
 * @author Barun.Rai
 *
 */
public class PlanUtility {

	/**
	 * method to add review ratings to plans
	 * @param plans
	 * @return
	 */
	public static List<PlanResource> addReviewRatingDetailsInPlan(List<PlanResource> plans) {
		if(!plans.isEmpty()) {
			try {
				final RedisOperationImpl redisOperationImpl = new RedisOperationImpl();
				plans.parallelStream().forEach(x -> {
					x.setRating(NumberUtils.toDouble(redisOperationImpl.getFromMap(PlanConstant.REDIS_RATINGS_KEY, x.getId()), 0));
					x.setReviewsCount(NumberUtils.toInt(redisOperationImpl.getFromMap(PlanConstant.REDIS_REVIEW_COUNT_KEY, x.getId()), 0));
					x.setSubcribersCount(NumberUtils.toInt(redisOperationImpl.getFromMap(PlanConstant.REDIS_SUBSCRIPTION_COUNT_KEY, x.getId()), 0));
				});
			} catch (final Exception e) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(), "PlanUtility",
						Thread.currentThread().getStackTrace()[1].getMethodName()).writeExceptionLog();
			}
		}
		
		return plans;
	}
	
	/**
	 * return plans sorted on ratings
	 * @param plans
	 * @return
	 */
	public static List<PlanResource> sortByratings(List<PlanResource> plans) {
		plans.sort(( p1,  p2) -> p1.getRating() > p2.getRating() ? 1 : -1); 
		return plans; 
	}
}
