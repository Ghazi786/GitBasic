package com.jio.subscriptionengine.batchprocessing.modules.plan.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.time.DateUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;

import com.elastic.search.bean.DateRange;
import com.elastic.search.bean.OrderBy;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.enums.Levels;
import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.clearCodes.ClearCodeLevel;
import com.jio.subscriptionengine.batchprocessing.clearCodes.ClearCodes;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.core.MarketPlaceMapper;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Category;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Plan;
import com.jio.subscriptionengine.batchprocessing.modules.plan.bean.PlanResource;
import com.jio.subscriptionengine.batchprocessing.modules.plan.helper.PlanConstant;
import com.jio.subscriptionengine.batchprocessing.modules.plan.repository.PlanRepository;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.service.CustomerReviewService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.service.SubscribeService;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.redis.CachePlansUtils;
import com.jio.subscriptionengine.batchprocessing.redis.RedisOperationImpl;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;

/**
 * 
 * The Class for Plan service.
 */
public class PlanService {

	/**
	 * Instantiate Plan Repository
	 */
	private final PlanRepository planRepository = new PlanRepository();

	/**
	 * get plans by parameters
	 * 
	 * @param siteId
	 * @param q
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public SearchResult<Plan> getPlans(final String q, final DateRange dateRange, final OrderBy order,
			final int page, final int pageSize) throws ElasticSearchException {

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		final SearchResult<Plan> result = planRepository.getPlans(session, q, dateRange, order, page, pageSize);
		
		return result;
	}

	/**
	 * 
	 * @param page
	 * @param redis_key
	 * @return
	 * @throws ElasticSearchException
	 */
	public SearchResult<PlanResource> getPlansFromCache(final Page page, final String redis_key) throws ElasticSearchException {
		
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		final SearchResult<PlanResource> result = new SearchResult<>();
		try {
			final RedisOperationImpl redisOperationImpl = new RedisOperationImpl();
		
			final long documentsCount = redisOperationImpl.llen(redis_key);

			if(documentsCount == 0) {
				executeCachePlansTask(redis_key);
				return null;
			}

			final long pageLength = page.getPageLength() < 1 ? 20 : page.getPageLength();
			final int pageNo = page.getPageNo() < 1 ? 1 : page.getPageNo();
			long firstPage = (pageNo - 1) * pageLength;

			if (firstPage > documentsCount) {
				firstPage = documentsCount;
		       }
			long lastPage = pageNo * pageLength - 1;
			if (lastPage > documentsCount) {
				lastPage = documentsCount;
		        }
			final List<PlanResource> plans = redisOperationImpl.getFromList(redis_key, PlanResource.class, firstPage,
					lastPage);
			result.setDocumentsCount(documentsCount);
			final int count = (int) (documentsCount / page.getPageLength());
			final int offset = documentsCount % page.getPageLength() != 0 ? 1 : 0;
			page.setPagesCount(count + offset);
			result.setPage(page);
			result.setResult(plans);
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return result;
		        }
		        
	private void executeCachePlansTask(final String redis_key) {
		final Runnable cachePlanstask = () -> {
			try {
				setPlansInRedis();
			} catch (final Exception e1) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e1, e1.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
			}
		};

		BatchProcessingBootStrapper.getInstance().getThreadPoolService().submit(cachePlanstask);

		final BaseException e = new BaseException(HttpStatus.NOT_FOUND_404,
				PlanConstant.REDIS_NO_PLAN_LIST_EXIST + " " + redis_key);
		DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(),
				Thread.currentThread().getStackTrace()[1].getMethodName()).writeExceptionLog();
		
	}
	

		        
	/**
	 * Set Plans in Cache
	 * 
	 * @throws Exception
	 */
	public void setPlansInRedis() throws Exception {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		
		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
	
		Page page;
		SearchResult<Plan> result;
		final RedisOperationImpl redisOperationImpl = new RedisOperationImpl();
		redisOperationImpl.delete(PlanConstant.REDIS_TOP_RATED_LIST_KEY);
		redisOperationImpl.delete(PlanConstant.REDIS_ALL_PLAN_LIST_KEY);
		redisOperationImpl.delete(PlanConstant.REDIS_POPULARITY_LIST_KEY);
	
		int pageNo = 1;
		final MarketPlaceMapper<Plan, PlanResource> mapper = new MarketPlaceMapper<>();
		final List<PlanResource> allPlans = new ArrayList<>();
		final SubscribeService subscribeService = new SubscribeService();
		do {
			page = new Page(1000, pageNo++);
			result = planRepository.getPlans(session, null, null, null, page.getPageNo(), page.getPageLength());
			final Collection<Plan> plans = result.getResult();
				final List<PlanResource> per = mapper.mapObjects((List<Plan>) plans, PlanResource.class, Plan.class);
				for (final PlanResource pr : per) {
					
					final String id = pr.getId();
	
					CustomerReviewService.getInstance().setPlanReviewAndRating(pr);
					pr.setSubcribersCount((int) subscribeService.calculateSubscriptionCount(id));
					
					redisOperationImpl.addTolist(PlanConstant.REDIS_ALL_PLAN_LIST_KEY, pr);

					allPlans.add(pr);
				}
		} while (result.getDocumentsCount() > result.getPage().getPageLength() * result.getPage().getPageNo());
		
		final List<PlanResource> ratingSortedList = allPlans.stream()
	            .sorted(Comparator.comparingDouble(PlanResource::getRating))
	            .collect(Collectors.toList());	
	
		final List<PlanResource> popularSortedList = allPlans.stream()
				.sorted(Comparator.comparingDouble(PlanResource::getSubcribersCount))
				.collect(Collectors.toList());
	
		for (int index = 0; index < ratingSortedList.size(); index++) {
			redisOperationImpl.addTolist(PlanConstant.REDIS_TOP_RATED_LIST_KEY, ratingSortedList.get(index));
			redisOperationImpl.addTolist(PlanConstant.REDIS_POPULARITY_LIST_KEY, popularSortedList.get(index));
		}
		final Date time = DateUtils.addDays(new Date(), 1);
		redisOperationImpl.expireAt(PlanConstant.REDIS_TOP_RATED_LIST_KEY, time);
		redisOperationImpl.expireAt(PlanConstant.REDIS_ALL_PLAN_LIST_KEY, time);
		redisOperationImpl.expireAt(PlanConstant.REDIS_POPULARITY_LIST_KEY, time);
	}
	
	public BaseResponse<SearchResult<Plan>> getAllPlansId() throws ElasticSearchException {

		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		SearchResult<Plan> result = planRepository.getAllPlanIds(session);
		final BaseResponse<SearchResult<Plan>> baseResponse = new BaseResponse<SearchResult<Plan>>(result);
		return baseResponse;
	}

	/**
	 * get plan by id
	 * 
	 * @param id
	 * @return
	 * @throws BaseException
	 */
	public Plan getPlan(final String id) throws BaseException {
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.COMPLETE);

		Plan plan;
		try {
			plan = planRepository.getPlan(session, id);
			return plan;
		} catch (final ElasticSearchException e) {
			// error
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			throw new BaseException(HttpStatus.BAD_REQUEST_400, PlanConstant.FETCH_PLAN_ERROR);

		} finally {
			session.close();
		}
	}

	/**
	 *  get plan list sorted on popularity
	 * @param q
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public  List<Plan> getPlansByPopularity(String q, DateRange dateRange, OrderBy order, int page, int pageSize)
			throws BaseException, ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		List<org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket> result = planRepository
				.getPlansbyPopularity(session, q, dateRange, order, page, pageSize);
		SearchResult<Plan> plans = new SearchResult<>();
		plans.setResult(new LinkedHashSet<>());
		List<Plan> s = new ArrayList<>();
		List<String> planCodes = result.stream().map(Bucket::getKeyAsString).collect(Collectors.toList());
		result.stream().forEach(x -> {
			try {
				Plan sr = planRepository.getPlan(session, x.getKeyAsString());
				if (sr != null && planCodes.contains(sr.getId().toLowerCase())) {
					s.add(sr);
				}

			} catch (ElasticSearchException e) {
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
						.writeExceptionLog();
			}

		});
		return s;
	}

	/**
	 * get plans by filters provided
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @param filters
	 * @param q 
	 * @return
	 * @throws ElasticSearchException
	 */
	public SearchResult<Plan> getPlansByFilters(final DateRange dateRange, final OrderBy order, final int page, final int pageSize,
			final Map<String, Object> filters, final String q) throws ElasticSearchException {

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		final SearchResult<Plan> result = planRepository.getPlansByFilters(session, filters, dateRange, order, page,
				pageSize, q);
		return result;
	}

	/** 
	 * get count of plan subscription
	 * @param planCode
	 * @param dateRange
	 * @param order
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ElasticSearchException
	 */
	public BaseResponse<?> getPlanCount(String planCode, DateRange dateRange, OrderBy order, int page, int pageSize)
			throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		List<Bucket> result = planRepository.getPlansCount(session, planCode, dateRange, order, page, pageSize);

		final BaseResponse<?> baseResponse = new BaseResponse<>(result);
		return baseResponse;
	}
	
	public BaseResponse<List<Category>> getPlancategories() throws ElasticSearchException {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		SessionFactory factory = SessionFactory.getSessionFactory();
		Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);
		SearchResult<Category> result = planRepository.getPlancategories(session);
		return new BaseResponse<List<Category>>((List<Category>) result.getResult());
	}

	 /**
	   * get plan by id
	   * 
	   * @param id
	   * @return
	   * @throws ElasticSearchException
	   */
	  public BaseResponse<String> getPlanString(final String id) throws ElasticSearchException {

			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
	    final ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();

	    final SessionFactory factory = SessionFactory.getSessionFactory();
	    final Session session = factory.getSession();
	    session.setSearchLevel(Levels.COMPLETE);

	    final String plan = planRepository.getPlanString(session, id);
	    final BaseResponse<String> baseResponse = new BaseResponse<>(plan);
	    session.close();

	    ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_GET_PLAN_BY_ID_SUCCESS.getValue(), ClearCodeLevel.SUCCESS);
	    ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	    return baseResponse;

	  }

	public SearchResult<String> getPlansFromCacheAsString(final Page page, final String redis_key)
			throws ElasticSearchException {
		final SearchResult<String> result = new SearchResult<>();
		try {

			final List<String> plans = CachePlansUtils.getInstance().getAllPlans();
			final long documentsCount =  CachePlansUtils.getInstance().getDocumentsCount();
			if(documentsCount == 0 || plans.size()== 0) {

				final BaseException e = new BaseException(HttpStatus.NOT_FOUND_404,
						"no length - No Data" + redis_key);
				DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage()).writeExceptionLog();
				return null;
			}

			final long pageLength = page.getPageLength() < 1 ? 20 : page.getPageLength();
			final int pageNo = page.getPageNo() < 1 ? 1 : page.getPageNo();
			long firstPage = (pageNo - 1) * pageLength;

			if (firstPage > documentsCount) {
				firstPage = documentsCount;
			}
			long lastPage = pageNo * pageLength ;
			if (lastPage > documentsCount) {
				lastPage = documentsCount;
			}
			final int count = (int) (documentsCount / page.getPageLength());
			final int offset = documentsCount % page.getPageLength() != 0 ? 1 : 0;
			page.setPagesCount(count + offset);
			
			result.setDocumentsCount(documentsCount);
			result.setPage(page);
			result.setResult(plans.subList((int)firstPage,(int) lastPage));
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
		return result;
	}


}
