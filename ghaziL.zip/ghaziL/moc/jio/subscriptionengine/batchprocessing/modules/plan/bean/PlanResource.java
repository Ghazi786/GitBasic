package com.jio.subscriptionengine.batchprocessing.modules.plan.bean;

import java.util.List;

import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;

public class PlanResource {

	private String id;
	private String name;
	private String planCode;
	private String description;
	private String logo;
	private String categoryName;
	private String categoryDescription;

	private double rating;
	private int subcribersCount;
	private int reviewsCount;

	private boolean newPlan;
	private Currency marketPlacePricePerUnit;
	private Currency marketPlacePricePerTerm;
	
	private List<String> descriptionImages;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public int getSubcribersCount() {
		return subcribersCount;
	}

	public void setSubcribersCount(int subcribersCount) {
		this.subcribersCount = subcribersCount;
	}

	public int getReviewsCount() {
		return reviewsCount;
	}

	public void setReviewsCount(int reviewsCount) {
		this.reviewsCount = reviewsCount;
	}

	public boolean isNewPlan() {
		return newPlan;
	}

	public void setNewPlan(boolean newPlan) {
		this.newPlan = newPlan;
	}

	public List<String> getDescriptionImages() {
		return descriptionImages;
	}

	public void setDescriptionImages(List<String> descriptionImages) {
		this.descriptionImages = descriptionImages;
	}

	public Currency getMarketPlacePricePerUnit() {
		return marketPlacePricePerUnit;
	}

	public void setMarketPlacePricePerUnit(Currency marketPlacePricePerUnit) {
		this.marketPlacePricePerUnit = marketPlacePricePerUnit;
	}

	public Currency getMarketPlacePricePerTerm() {
		return marketPlacePricePerTerm;
	}

	public void setMarketPlacePricePerTerm(Currency marketPlacePricePerTerm) {
		this.marketPlacePricePerTerm = marketPlacePricePerTerm;
	}

}
