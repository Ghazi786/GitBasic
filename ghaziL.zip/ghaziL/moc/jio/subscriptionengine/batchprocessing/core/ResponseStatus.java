package com.jio.subscriptionengine.batchprocessing.core;

public enum ResponseStatus {

}
