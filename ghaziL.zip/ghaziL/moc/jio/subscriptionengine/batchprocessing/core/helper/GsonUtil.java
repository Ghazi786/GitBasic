package com.jio.subscriptionengine.batchprocessing.core.helper;

import java.io.IOException;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

public class GsonUtil {

	public static Gson getGsonInstance() {
		final Gson gson = new GsonBuilder().registerTypeAdapter(Date.class, new TypeAdapter<Date>() {

			@Override
			public void write(final JsonWriter out, final Date value) throws IOException {
				if (value != null)
					out.value(value.getTime());
				else
					out.nullValue();
			}

			@Override
			public Date read(final JsonReader in) throws IOException {
				return new Date(in.nextLong());
			}
		}).create();
		return gson;
	}
}
