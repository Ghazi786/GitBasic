package com.jio.subscriptionengine.batchprocessing.core;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Map;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.blockchain.sdk.constants.Constants;
import com.jio.resttalk.service.custom.exceptions.RestTalkInvalidURLException;
import com.jio.resttalk.service.custom.exceptions.RestTalkServerConnectivityError;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.impl.RestTalkManager;
import com.jio.resttalk.service.pojo.RestTalkClient;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.telco.framework.pool.PoolingManager;

/**
 * 
 * @author Arun.Tagde
 * 
 */

public class RestApiCalls {
	private static RestTalkBuilder builder;
	static {
		RestTalkClient restTalkClient = new RestTalkClient();
		restTalkClient.setKeystoreFilePath("./../configuration/client_keystore.jks");
		restTalkClient.setKeyPhrase("123456");
		restTalkClient.setTrustStorePath("./../configuration/client_truststore.jks");
		restTalkClient.setTrustStorePassword("123456");
		restTalkClient.setIdentifier(Constants.IDENTIFIER_VALUE);
		try {
			RestTalkManager.getInstance().addNewHTTPClient(restTalkClient);
		} catch (KeyManagementException | UnrecoverableKeyException | NoSuchAlgorithmException | KeyStoreException
				| CertificateException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			builder = ((RestTalkBuilder) PoolingManager.getPoolingManager().borrowObject(RestTalkBuilder.class));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static JsonObject get(String url) {
		
		builder.setEndPointIdentifier(Constants.IDENTIFIER_VALUE).Get(url);
		
		System.out.println("url : " +url); 
		RestTalkResponse res;
		JsonObject jsonData = null;
		try {
			res = builder.send();
			JsonObject jsonObject = new JsonParser().parse(res.answeredContent().responseString()).getAsJsonObject();
			jsonData = (JsonObject) jsonObject.get("result");
		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		return jsonData;

	}

	public static Object post(String url, String requestData, Map<String, String> headers) {


		builder.setEndPointIdentifier(Constants.IDENTIFIER_VALUE)
			   .Post(url)
			   .addRequestData(requestData)
			   .addCustomHeaders(headers);
		
		RestTalkResponse res;
		JsonObject jsonData = null;
		try {
			res = builder.send();
			JsonObject jsonObject = new JsonParser().parse(res.answeredContent().responseString()).getAsJsonObject();
			jsonData = (JsonObject) jsonObject.get("result");
		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {
			e.printStackTrace();
		}

		return jsonData;

	}
	
	public static Object put(String url, String requestData) {


		builder.setEndPointIdentifier(Constants.IDENTIFIER_VALUE)
		       .Put(url)
		       .addRequestData(requestData);
			   
		RestTalkResponse res;
		JsonObject jsonData = null;

		try {
			res = builder.send();
			JsonObject jsonObject = new JsonParser().parse(res.answeredContent().responseString()).getAsJsonObject();
			jsonData = (JsonObject) jsonObject.get("result");
		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {
			e.printStackTrace();
		}

		return jsonData;

	}
	
	public static Object delete(String url, String requestData) {


		JsonObject jsonData = null;

	

		return jsonData;

	}

	// private static void giveBuilderObjectToPool() {
	// try {
	// PoolingManager.getPoolingManager().returnObject(builder);
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

}
