package com.jio.subscriptionengine.batchprocessing.core;

public class RPCIdentifierConstant {
	
	public static final byte CUSTOMER_ID = 1;

}
