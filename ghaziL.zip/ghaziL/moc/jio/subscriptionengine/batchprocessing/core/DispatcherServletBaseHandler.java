package com.jio.subscriptionengine.batchprocessing.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;

import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.http.HttpStatus;

import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.impl.ObjectMapperHelper;
import com.jio.subscriptionengine.batchprocessing.exceptions.BaseException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.threadpoolfactory.EventAckAnnotationRequestDispatcher;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.MarketplaceCommonMethod;

/**
 * 
 * This is base servlet to be implemented by each controller
 * 
 * @author Barun.Rai
 *
 * @modifyBy Kiran.Jangid
 */
public class DispatcherServletBaseHandler extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5872479692969508281L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp);
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp);
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp);
	}

	/**
	 * @param response
	 * @param responseBody
	 * @param status
	 * @param responseMessage
	 * @param cursor
	 */
	protected void sendResponse(HttpServletResponse response, Object responseBody, int status, String responseMessage,
			Cursor cursor) {

		if(responseBody == null && status == HttpStatus.OK_200) {
			status = HttpStatus.NOT_FOUND_404;
			responseMessage = "No Data Found";
		}

		try {

			if (responseBody instanceof String) {
				String SEPERATOR = ",";
				String ENCLOSED = "\"";
				String SEPERATOR_COL = ":";

				StringBuilder sb = new StringBuilder();
				sb.append("{");
				if (responseBody != null)
					sb.append(ENCLOSED).append(Constants.RESPONSE_BODY).append(ENCLOSED).append(SEPERATOR_COL)
							.append(responseBody.toString()).append(SEPERATOR);

				sb.append(ENCLOSED).append(Constants.RESPONSE_MESSAGE).append(ENCLOSED).append(SEPERATOR_COL)
						.append(ENCLOSED).append(responseMessage).append(ENCLOSED).append(SEPERATOR);
				sb.append(ENCLOSED).append(Constants.RESPONSE_CODE).append(ENCLOSED).append(SEPERATOR_COL)
						.append(status).append(SEPERATOR);
				sb.append(ENCLOSED).append(Constants.CREATED_TIME_STAMP).append(ENCLOSED).append(SEPERATOR_COL)
						.append(System.currentTimeMillis());
				sb.append("}");
				response.setStatus(status);
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				PrintWriter printWriter;
				printWriter = response.getWriter();
				printWriter.print(sb.toString());
				printWriter.flush();
				printWriter.close();

			} else {

				Map<String, Object> jsonObj = new HashMap<>();
				if (responseBody != null)
					jsonObj.put(Constants.RESPONSE_BODY, responseBody);
				jsonObj.put(Constants.RESPONSE_MESSAGE, responseMessage);
				jsonObj.put(Constants.RESPONSE_CODE, status);
				jsonObj.put(Constants.CREATED_TIME_STAMP, System.currentTimeMillis());

				response.setStatus(status);
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				PrintWriter printWriter;
				printWriter = response.getWriter();
				printWriter.print(ObjectMapperHelper.getInstance().getEntityObjectMapper().writeValueAsString(jsonObj));
				printWriter.flush();
				printWriter.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void processRequest(HttpServletRequest req, HttpServletResponse resp) {

		String path = req.getContextPath() + req.getPathInfo();
		String httpMethod = req.getMethod();

		try {

			BaseEventBean eventPojo = MarketplaceCommonMethod.getEventTrackingObject(req);

			Class<?> classObj = null;

			if (BaseContextMapper.EVENT_CLASS_MAPPING.containsKey(eventPojo.getEventName())) {
				classObj = Class.forName(BaseContextMapper.EVENT_CLASS_MAPPING.get(eventPojo.getEventName()));
			} else {
				classObj = Class.forName(BaseContextMapper.CONTROLLER_MAPPING.get(req.getContextPath()));
			}

			DispatcherBaseController controller = (DispatcherBaseController) classObj.newInstance();

			// check condition for Async Request
			if ((!HttpParamConstants.EXECUTION_TYPE.equals(eventPojo.getExecutionType()))
					&& (BaseContextMapper.ASYNC_MAPPING.contains(path)
							|| BaseContextMapper.ASYNC_EVENT_MAPPING.contains(eventPojo.getEventName()))) {

				AsyncContext context = req.startAsync();

				ExecutorService executorService = BatchProcessingBootStrapper.getInstance().getDappExecutor();
				executorService
						.execute(new EventAckAnnotationRequestDispatcher(eventPojo, req, resp, controller, context));

				sendResponse(resp, "Request Accepted", HttpServletResponse.SC_ACCEPTED, "Request Accepted", null);
				context.complete();

			} else {

				java.lang.reflect.Method method = null;

				if (eventPojo.getEventName() != null && !eventPojo.getEventName().isEmpty()
						&& BaseContextMapper.EVENT_MAPPING.containsKey(eventPojo.getEventName().trim())) {

					method = controller.getClass().getMethod(
							BaseContextMapper.EVENT_MAPPING.get(eventPojo.getEventName().trim()),
							HttpServletRequest.class, HttpServletResponse.class);

				} else {
					method = controller.getClass().getMethod(
							BaseContextMapper.PATH_MAPPING.get(HttpRequestMethod.valueOf(httpMethod).name()).get(path),
							HttpServletRequest.class, HttpServletResponse.class);
				}

				BaseResponse<?> response = (BaseResponse<?>) method.invoke(controller, req, resp);

				if (response != null) {
					sendResponse(resp, response.getData(), response.getStatus(), response.getMessage(),
							response.getCursor());
				}
			}

		} catch (Exception e) {

			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

			BaseException exp = new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500,
					"Server error occurred. Please contact the administrator");

			if (e.getCause() instanceof BaseException)
				exp = (BaseException) e.getCause();

			if (e.getCause() instanceof ElasticSearchException)
				exp = new BaseException(HttpStatus.INTERNAL_SERVER_ERROR_500, e.getCause().getMessage());

			sendResponse(resp, null, exp.getStatus(), exp.getMessage(), null);
		}
	}

}
