package com.jio.subscriptionengine.batchprocessing.core;

/**
 * Base controller class which will be implemented by every controllers
 * 
 * @author Barun.Rai
 * 
 */
public interface DispatcherBaseController {

}
