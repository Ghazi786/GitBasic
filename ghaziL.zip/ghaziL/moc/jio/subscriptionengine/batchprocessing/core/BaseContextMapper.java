package com.jio.subscriptionengine.batchprocessing.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseContextMapper {
	
	public static final Map<String, Map<String, String>> PATH_MAPPING = new HashMap<>();

	public static final Map<String, String> CONTROLLER_MAPPING = new HashMap<>();

	public static final List<String> ASYNC_MAPPING = new ArrayList<>();
	
	public static final Map<String, String> EVENT_MAPPING = new HashMap<>();
	 
	public static final Map<String, String> EVENT_CLASS_MAPPING = new HashMap<>();
	
	public static final List<String>  ASYNC_EVENT_MAPPING = new ArrayList<>();


}
