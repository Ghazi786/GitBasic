package com.jio.subscriptionengine.batchprocessing.core;


import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;

public class MasterDataInitializer {
	

	   private static MasterDataInitializer singleton = new MasterDataInitializer( );
	   
	  

	 
	   private MasterDataInitializer() { }

	   
	   public static MasterDataInitializer getInstance( ) {
	      return singleton;
	   }
	   
	   
	   //To insert masterData just add your entity as below 
	   public void init() throws Exception
	   {
	
		   
		   //inserting Industry MasterData for Education
//		   IndustryType I4=new IndustryType("Education", "A");
//		   masterData(I4, "name", I4.getName());
		   
		   
	   }
	   

	   //Method for inserting masterdata for any generic class
	   protected void masterData(Object obj,String key,String value ) {
	     
	       
	      
	      SessionFactory factory = SessionFactory.getSessionFactory();
	      Session session = factory.getSession();
	      
	      
	      
	      Object object;
			try {
				session.beginTransaction();
				object = session.getObject(obj.getClass(), key, value);
				 
				//to check if data is already present in db
				if(object==null)
			      {
			    	  
			    	try {
						session.save(obj);
						
						session.flush();
					} catch (Exception e) {
						
						e.printStackTrace();
					}
			    	  
			    	  
			    	  
			      }
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			finally {
				session.close();
			}
		      
		     
	      
		
	      
	      
	   }


}
