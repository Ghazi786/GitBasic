package com.jio.subscriptionengine.batchprocessing.core;

public enum HttpRequestMethod {

	GET, POST, DELETE, PUT
}
