package com.jio.subscriptionengine.batchprocessing.entities;

public class UserElasticEntity {

}
