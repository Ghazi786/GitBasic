/**
 * 
 */
package com.jio.subscriptionengine.batchprocessing.site.repository;

import com.elastic.search.exception.ElasticSearchException;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Site;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class SiteRepository {

	/**
	 * 
	 */
	public SiteRepository() {
		// TODO Auto-generated constructor stub
	}

	public Site getSiteById(Session session, String siteId) throws ElasticSearchException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		return session.getObject(Site.class, siteId);

	}
}
