/**
 * 
 */
package com.jio.subscriptionengine.batchprocessing.subscriptiontermination.helper;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;

/**
 * @author Ghajnafar.Shahid
 *
 */
@Controller
@RequestMapping(name = "/subscription-detail-event-ack")
public class SubscriptionTerminationAckController implements DispatcherBaseController {

	/**
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 * 
	 */

	public static final long serialVersionUID = 1L;

	@RequestMapping(name = "/create", type = HttpRequestMethod.POST)
	@EventName("CREATE_SUBSCRIPTION_TERMINATION_DETAILS")
	public BaseResponse<?> createSubscriptionDetailsAck(HttpServletRequest req, HttpServletResponse resp)
			throws JsonParseException, JsonMappingException, IOException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		BaseResponse<?> response = null;
//		ObjectMapper mapper = new ObjectMapper();
//		
//		JsonNode reqJson = mapper.readValue(req.getReader(), JsonNode.class);

		response = new BaseResponse<>("{}");
		response.setMessage("Accepted");
		response.setStatus(200);
		return response;
	}

	@RequestMapping(name = "/update", type = HttpRequestMethod.POST)
	@EventName("UPDATE_SUBSCRIPTION_TERMINATION_DETAILS")
	public BaseResponse<?> updateSubscriptionDetailsAck(HttpServletRequest req, HttpServletResponse resp)
			throws JsonParseException, JsonMappingException, IOException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		BaseResponse<?> response = null;
//		ObjectMapper mapper = new ObjectMapper();
//		JsonNode reqJson = mapper.readValue(req.getReader(), JsonNode.class);
		response = new BaseResponse<>("{}");
		response.setMessage("Accepted");
		response.setStatus(200);
		return response;
	}

	@RequestMapping(name = "/delete", type = HttpRequestMethod.POST)
	@EventName("DELETE_SUBSCRIPTION_TERMINATION_DETAILS")
	public BaseResponse<?> deleteSubscriptionDetailsAck(HttpServletRequest req, HttpServletResponse resp)
			throws JsonParseException, JsonMappingException, IOException {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		BaseResponse<?> response = null;
//		ObjectMapper mapper = new ObjectMapper();
//		JsonNode reqJson = mapper.readValue(req.getReader(), JsonNode.class);
		response = new BaseResponse<>("{}");
		response.setMessage("Accepted");
		response.setStatus(200);
		return response;
	}

}
