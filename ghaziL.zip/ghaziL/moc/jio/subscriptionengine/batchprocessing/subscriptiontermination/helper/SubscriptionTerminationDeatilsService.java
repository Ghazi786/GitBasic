
/**
 * 
 */
package com.jio.subscriptionengine.batchprocessing.subscriptiontermination.helper;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jio.resttalk.service.custom.exceptions.RestTalkInvalidURLException;
import com.jio.resttalk.service.custom.exceptions.RestTalkServerConnectivityError;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.core.HttpParamConstants;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Site;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.site.repository.SiteRepository;
import com.jio.subscriptionengine.batchprocessing.utils.Constants;
import com.jio.subscriptionengine.batchprocessing.utils.MS;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;
import com.jio.telco.framework.pool.PoolingManager;

/**
 * @author Ghajnafar.Shahid
 *
 */
public class SubscriptionTerminationDeatilsService {

	/**
	 * 
	 */
	private SiteRepository repository = new SiteRepository();
	private static SubscriptionTerminationDeatilsService subscriptionTerminationDeatilsService = null;

	private static Map<String, Site> siteMap = new HashMap<>();

	private SubscriptionTerminationDeatilsService() {

	}

	public static SubscriptionTerminationDeatilsService getInstance() {
		if (subscriptionTerminationDeatilsService == null) {
			subscriptionTerminationDeatilsService = new SubscriptionTerminationDeatilsService();
		}
		return subscriptionTerminationDeatilsService;
	}

	public void createSubscriptionDetails(List<SubscriberSubscription> subscriberSubscriptionList) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();

			// map to store list of subscriberSubscription corresponding to siteId or
			// vendorId
			HashMap<String, List<SubscriberSubscription>> map = new HashMap<String, List<SubscriberSubscription>>();

			// setting map corresponding to siteId or vendorId
			for (SubscriberSubscription subscriberSubscription : subscriberSubscriptionList) {
				if (map.get(subscriberSubscription.getSiteId()) != null) {
					map.get(subscriberSubscription.getSiteId()).add(subscriberSubscription);
				} else {
					List<SubscriberSubscription> list = new ArrayList<SubscriberSubscription>();
					list.add(subscriberSubscription);
					map.put(subscriberSubscription.getSiteId(), list);
				}
			}

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());

			// making request corresponding to each siteId or vendorId
			map.forEach((siteId, listsubscriberSubscription) -> {
				ObjectNode finalReqJson = JsonNodeFactory.instance.objectNode();
				Site site = null;
				RestTalkBuilder builder = null;
				try {

					if (siteMap.containsKey(siteId)) {
						site = siteMap.get(siteId);
					}

					else {
						site = this.repository.getSiteById(session, siteId);
						siteMap.put(siteId, site);
					}

					ArrayNode reqList = finalReqJson.putArray("subscriptionDetails");

					for (SubscriberSubscription subscriberSubscription : listsubscriberSubscription) {
						ObjectNode reqJson = JsonNodeFactory.instance.objectNode();

						reqJson.put("vendorId", subscriberSubscription.getSiteId());
						reqJson.put("vendorName", site.getName());
						reqJson.put("subscriptionId", subscriberSubscription.getId());
						reqJson.put("subscriberId", subscriberSubscription.getSubscriberId());
						reqJson.put("planId", subscriberSubscription.getPlan().getId());
						reqJson.put("planName", subscriberSubscription.getPlan().getName());
						reqJson.put("subscribedOn", subscriberSubscription.getStartedOn().getTime());
						reqJson.put("terminatesOn", subscriberSubscription.getNextBillingDate().getTime());
						reqJson.put("callbackUrl", callBackurl);
						reqList.add(reqJson);
					}

					DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							"Req Data To PSC:", finalReqJson.toString()).writeLog();
					builder = getRestTalkBuilder();
					RestTalkResponse response = builder.Post(reqUrl)
							.addCustomHeader(HttpParamConstants.EVENT_NAME, "CREATE_SUBSCRIPTION_TERMINATION_DETAILS")
							.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
							.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
							.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
							.addCustomHeader("vendorId", siteId).addCustomHeader("vendorName", site.getName())
							.addRequestData(finalReqJson.toString()).send();
					logResposne(response.answeredContent().responseString());
				} catch (Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeLog();
				} finally {
					if (builder != null) {
						try {
							PoolingManager.getPoolingManager().returnObject(builder);
						} catch (Exception e) {
							DappLoggerService.GENERAL_ERROR_FAILURE_LOG
									.getExceptionLogBuilder(e, e.getMessage(), this.getClass().getName(),
											Thread.currentThread().getStackTrace()[1].getMethodName())
									.writeLog();
						}
					}
				}

			});

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void updateSubscriptionDetails(List<SubscriberSubscription> subscriberSubscriptionList) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();

			// map to store list of subscriberSubscription corresponding to siteId or
			// vendorId
			HashMap<String, List<SubscriberSubscription>> map = new HashMap<String, List<SubscriberSubscription>>();

			// setting map corresponding to siteId or vendorId
			for (SubscriberSubscription subscriberSubscription : subscriberSubscriptionList) {
				if (map.get(subscriberSubscription.getSiteId()) != null) {
					map.get(subscriberSubscription.getSiteId()).add(subscriberSubscription);
				} else {
					List<SubscriberSubscription> list = new ArrayList<SubscriberSubscription>();
					list.add(subscriberSubscription);
					map.put(subscriberSubscription.getSiteId(), list);
				}
			}

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());

			// making request corresponding to each siteId or vendorId
			map.forEach((siteId, listsubscriberSubscription) -> {
				ObjectNode finalReqJson = JsonNodeFactory.instance.objectNode();
				Site site = null;
				try {
					site = this.repository.getSiteById(session, siteId);
					ArrayNode reqList = finalReqJson.putArray("subscriptionDetails");

					for (SubscriberSubscription subscriberSubscription : listsubscriberSubscription) {
						ObjectNode reqJson = JsonNodeFactory.instance.objectNode();

						reqJson.put("vendorId", subscriberSubscription.getSiteId());
						reqJson.put("vendorName", site.getName());
						reqJson.put("subscriptionId", subscriberSubscription.getId());
						reqJson.put("subscriberId", subscriberSubscription.getSubscriberId());
						reqJson.put("planId", subscriberSubscription.getPlan().getId());
						reqJson.put("planName", subscriberSubscription.getPlan().getName());
						reqJson.put("subscribedOn", subscriberSubscription.getStartedOn().getTime());
						reqJson.put("terminatesOn", subscriberSubscription.getNextBillingDate().getTime());
						reqJson.put("callbackUrl", callBackurl);
						reqList.add(reqJson);
					}

					DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							"Req Data To PSC:", finalReqJson.toString()).writeLog();
					RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
							.addCustomHeader(HttpParamConstants.EVENT_NAME, "UPDATE_SUBSCRIPTION_TERMINATION_DETAILS")
							.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
							.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
							.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
							.addCustomHeader("vendorId", siteId).addCustomHeader("vendorName", site.getName())
							.addRequestData(finalReqJson.toString()).send();
					logResposne(response.answeredContent().responseString());
				} catch (Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeLog();
				}

			});

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void deleteSubscriptionDetails(List<SubscriberSubscription> subscriberSubscriptionList) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();

			// map to store list of subscriberSubscription corresponding to siteId or
			// vendorId
			HashMap<String, List<SubscriberSubscription>> map = new HashMap<String, List<SubscriberSubscription>>();

			// setting map corresponding to siteId or vendorId
			for (SubscriberSubscription subscriberSubscription : subscriberSubscriptionList) {
				if (map.get(subscriberSubscription.getSiteId()) != null) {
					map.get(subscriberSubscription.getSiteId()).add(subscriberSubscription);
				} else {
					List<SubscriberSubscription> list = new ArrayList<SubscriberSubscription>();
					list.add(subscriberSubscription);
					map.put(subscriberSubscription.getSiteId(), list);
				}
			}

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());

			// making request corresponding to each siteId or vendorId
			map.forEach((siteId, listsubscriberSubscription) -> {
				ObjectNode finalReqJson = JsonNodeFactory.instance.objectNode();
				Site site = null;
				try {
					site = this.repository.getSiteById(session, siteId);
					ArrayNode reqList = finalReqJson.putArray("subscriptionDetails");

					for (SubscriberSubscription subscriberSubscription : listsubscriberSubscription) {
						ObjectNode reqJson = JsonNodeFactory.instance.objectNode();

						reqJson.put("vendorId", subscriberSubscription.getSiteId());
						reqJson.put("subscriptionId", subscriberSubscription.getId());
						reqJson.put("subscriberId", subscriberSubscription.getSubscriberId());
						reqJson.put("callbackUrl", callBackurl);
						reqList.add(reqJson);
					}

					DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							"Req Data To PSC:", finalReqJson.toString()).writeLog();
					RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
							.addCustomHeader(HttpParamConstants.EVENT_NAME, "DELETE_SUBSCRIPTION_TERMINATION_DETAILS")
							.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
							.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
							.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
							.addCustomHeader("vendorId", siteId).addCustomHeader("vendorName", site.getName())
							.addRequestData(finalReqJson.toString()).send();
					logResposne(response.answeredContent().responseString());
				} catch (Exception e) {
					DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
							.writeLog();
				}

			});

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void createSubscriptionDetails(SubscriberSubscription subscriberSubscription, BaseEventBean baseEventBean) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();
			Site site = this.repository.getSiteById(session, subscriberSubscription.getSiteId());
			String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());
			ObjectNode reqJson = JsonNodeFactory.instance.objectNode();
			reqJson.put("vendorId", subscriberSubscription.getSiteId());

			reqJson.put("vendorName", site.getName());
			reqJson.put("subscriptionId", subscriberSubscription.getId());
			reqJson.put("subscriberId", subscriberSubscription.getSubscriberId());
			reqJson.put("planId", subscriberSubscription.getPlan().getId());
			reqJson.put("planName", subscriberSubscription.getPlan().getName());
			reqJson.put("subscribedOn", subscriberSubscription.getStartedOn().getTime());
			reqJson.put("terminatesOn", subscriberSubscription.getNextBillingDate().getTime());
			reqJson.put("callbackUrl", callBackurl);
			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
					.addCustomHeader(HttpParamConstants.EVENT_NAME, "CREATE_SUBSCRIPTION_TERMINATION_DETAILS")
					.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
					.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
					.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
					.addCustomHeader("vendorId", subscriberSubscription.getSiteId())
					.addCustomHeader("vendorName", site.getName()).addRequestData(reqJson.toString()).send();
			logResposne(response.answeredContent().responseString());

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void updateSubscriptionDetails(SubscriberSubscription subscriberSubscription, BaseEventBean baseEventBean) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();
			Site site = this.repository.getSiteById(session, subscriberSubscription.getSiteId());
			String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());
			ObjectNode reqJson = JsonNodeFactory.instance.objectNode();
			reqJson.put("vendorId", subscriberSubscription.getSiteId());

			reqJson.put("vendorName", site.getName());
			reqJson.put("subscriptionId", subscriberSubscription.getId());
			reqJson.put("subscriberId", subscriberSubscription.getSubscriberId());
			reqJson.put("planId", subscriberSubscription.getPlan().getId());
			reqJson.put("planName", subscriberSubscription.getPlan().getName());
			reqJson.put("subscribedOn", subscriberSubscription.getStartedOn().getTime());
			reqJson.put("terminatesOn", subscriberSubscription.getNextBillingDate().getTime());
			reqJson.put("callbackUrl", callBackurl);

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
					.addCustomHeader(HttpParamConstants.EVENT_NAME, "UPDATE_SUBSCRIPTION_TERMINATION_DETAILS")
					.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
					.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
					.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
					.addCustomHeader("vendorId", subscriberSubscription.getSiteId())
					.addCustomHeader("vendorName", site.getName()).addRequestData(reqJson.toString()).send();
			logResposne(response.answeredContent().responseString());
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}

	}

	public void deleteSubscriptionDetails(SubscriberSubscription subscriberSubscription, BaseEventBean baseEventBean) {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		try {
			SessionFactory factory = SessionFactory.getSessionFactory();
			Session session = factory.getSession();
			Site site = this.repository.getSiteById(session, subscriberSubscription.getSiteId());
			String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());

			ObjectNode reqJson = JsonNodeFactory.instance.objectNode();
			reqJson.put("vendorId", subscriberSubscription.getSiteId());
			reqJson.put("subscriptionId", subscriberSubscription.getId());
			reqJson.put("subscriberId", subscriberSubscription.getSubscriberId());
			reqJson.put("callbackUrl", callBackurl);

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
					.addCustomHeader(HttpParamConstants.EVENT_NAME, "DELETE_SUBSCRIPTION_TERMINATION_DETAILS")
					.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
					.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
					.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
					.addCustomHeader("vendorId", subscriberSubscription.getSiteId())
					.addCustomHeader("vendorName", site.getName()).addRequestData(reqJson.toString()).send();
			logResposne(response.answeredContent().responseString());
		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void createVendorNotification(JsonNode req, BaseEventBean baseEventBean) {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		final ObjectMapper mapper = new ObjectMapper();
		InputStream input;
		ArrayNode node = null;
		try {
			String profile = System.getProperty("profile");
			if (profile != null && profile.equals("dev")) {
				input = new FileInputStream("./configuration/notification.json");
			} else {
				input = new FileInputStream("../configuration/notification.json");
			}
			node = mapper.readValue(input, ArrayNode.class);

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
		ObjectNode reqJson = JsonNodeFactory.instance.objectNode();
		reqJson.put("vendorId", req.get("vendorId").asText());
		reqJson.put("vendorName", req.get("vendorName").asText());
		String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());
		reqJson.put("callbackUrl", callBackurl);
		reqJson.put("notification", node);

		try {

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
					.addCustomHeader(HttpParamConstants.EVENT_NAME, "CREATE_VENDOR_NOTIFICATION")
					.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
					.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
					.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
					.addCustomHeader("vendorId", req.get("vendorId").asText())
					.addCustomHeader("vendorName", req.get("vendorName").asText()).addRequestData(reqJson.toString())
					.send();
			logResposne(response.answeredContent().responseString());
		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void updateVendorNotification(JsonNode req, BaseEventBean baseEventBean) {
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		final ObjectMapper mapper = new ObjectMapper();
		InputStream input;
		ArrayNode node = null;
		try {
			String profile = System.getProperty("profile");
			if (profile != null && profile.equals("dev")) {
				input = new FileInputStream("./configuration/notification.json");

			} else {
				input = new FileInputStream("../configuration/notification.json");
			}
			node = mapper.readValue(input, ArrayNode.class);

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
		ObjectNode reqJson = JsonNodeFactory.instance.objectNode();
		reqJson.put("vendorId", req.get("vendorId").asText());
		reqJson.put("vendorName", req.get("vendorName").asText());
		String callBackurl = ServiceCommunicator.getHTTPElbUrl(MS.BATCH_PROCESSING_MS.name());
		reqJson.put("callbackUrl", callBackurl);
		reqJson.put("notification", node);

		try {

			String reqUrl = ServiceCommunicator.getHTTPElbUrl(MS.PSC.name() + Constants.SUBCRIPTION_HANDLER);
			RestTalkResponse response = new RestTalkBuilder().Post(reqUrl)
					.addCustomHeader(HttpParamConstants.EVENT_NAME, "UPDATE_VENDOR_NOTIFICATION")
					.addCustomHeader(HttpParamConstants.MSG_TYPE, "event")
					.addCustomHeader(HttpParamConstants.PUBLISHER_NAME, MS.BATCH_PROCESSING_MS.name())
					.addCustomHeader(HttpParamConstants.FLOW_ID, UUID.randomUUID().toString())
					.addCustomHeader("vendorId", req.get("vendorId").asText())
					.addCustomHeader("vendorName", req.get("vendorName").asText()).addRequestData(reqJson.toString())
					.send();
			logResposne(response.answeredContent().responseString());
		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}
	}

	public void logResposne(String response) {
		DappLoggerService.GENERAL_INFO_LOG.getLogBuilder("Response from PSC : " + response, this.getClass().getName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
	}

	private RestTalkBuilder getRestTalkBuilder() throws Exception {
		return ((RestTalkBuilder) PoolingManager.getPoolingManager().borrowObject(RestTalkBuilder.class));
	}

}
