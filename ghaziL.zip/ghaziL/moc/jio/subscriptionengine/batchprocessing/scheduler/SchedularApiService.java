package com.jio.subscriptionengine.batchprocessing.scheduler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;

public class SchedularApiService {

	private static SchedularApiService service = new SchedularApiService();
	private static Scheduler scheduler;

	private SchedularApiService() {

	}

	public static SchedularApiService getInstance() {
		return service;
	}

	public void initialize() {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder("Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		final StdSchedulerFactory schedulerFactory = new StdSchedulerFactory();
		try {
			schedulerFactory.initialize(getQuartzProperties());
			SchedularApiService.scheduler = schedulerFactory.getScheduler();
 			scheduler.start();

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
			shutdown();
		}
	}

	public void shutdown() {
		try {
			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder("Executing [ " + this.getClass().getName() + "."
							+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
			.writeLog();
			scheduler.shutdown(true);
		} catch (final SchedulerException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();
		}
	}

	public static Scheduler getScheduler() {
		return scheduler;
	}

	public static Properties getQuartzProperties() throws IOException {
		FileInputStream fis = null;
		Properties prop = null;
		String xmlName = "../configuration/jobs.xml";
		try {
			String profile = System.getProperty("profile");
			if (profile != null && profile.equals("dev")) {
				xmlName = "./configuration/jobs.xml";
				fis = new FileInputStream(new File("./configuration/quartz.properties"));
			} else {
				fis = new FileInputStream(new File("../configuration/quartz.properties"));
			}
			prop = new Properties();
			prop.load(fis);
			prop.setProperty("org.quartz.plugin.jobInitializer.fileNames", xmlName);
		} catch (IOException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					"SchedularApiService", Thread.currentThread().getStackTrace()[1].getMethodName())
			.writeExceptionLog();
			throw e;
		} finally {
			if(fis != null) {
			fis.close();
		}
		}
		return prop;
	}
}
