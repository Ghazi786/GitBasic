package com.jio.subscriptionengine.batchprocessing.scheduler.jobs;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionCancellationService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;

/**
 * This will change the status of user scheduled cancel of subscription on
 * Subscription Period End Date to EXPIRED
 * 
 * @author Samrudhi.Gandhe
 *
 */

@Controller
@RequestMapping(name = "/expire-canceled-subscription-job")
public class ExpireCanceledSubscriptionJob implements DispatcherBaseController {

	@EventName("SUBSCRIPTION_TERMINATION_JOB")
	@RequestMapping(name = "/expire", type = HttpRequestMethod.POST)
	public void expireSubscription(final HttpServletRequest req, final HttpServletResponse resp) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		try {

			final SubscriptionService subscriptionService = new SubscriptionService();
			ObjectMapper mapper = new ObjectMapper();
			// logger
			String reqData = IOUtils.toString(req.getReader()).toString();
			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							"Req Data :", reqData)
					.writeLog();
			ArrayNode reqArray = mapper.readValue(reqData, ArrayNode.class);

			List<SubscriberSubscription> list = new ArrayList<SubscriberSubscription>();
			for (JsonNode node : reqArray) {
				String subscriptionId = node.get("subscriptionId").asText();
				String subcriberId = node.get("subscriberId").asText();
				SubscriberSubscription subscriberSubscription = subscriptionService.getSubscription(subcriberId,
						subscriptionId);
				list.add(subscriberSubscription);
			}

			SubscriptionCancellationService.getInstance().updateBulkExpireStatus(list);

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}

	}

}
