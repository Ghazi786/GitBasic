package com.jio.subscriptionengine.batchprocessing.scheduler.jobs;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;

import com.elastic.search.bean.BasicOperations;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.enums.Levels;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionStatusEnum;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionRenewService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;

/**
 * This will generate the invoice of subscription as per next billing date. It
 * also performs the recurring payment of newly created invoice. Avoid the
 * subscription have scheduled for pause or cancel by user.
 * 
 * @author Samrudhi.Gandhe
 *
 */

@Controller
@RequestMapping(name = "/renew-subscription-job")
public class RenewSubscriptionJob implements DispatcherBaseController{

	@EventName("RENEW_SUBSCRIPTION_JOB")
	@RequestMapping(name = "/renew", type = HttpRequestMethod.POST)
	public void renewSubscription(final HttpServletRequest req, final HttpServletResponse resp) {
		DappLoggerService.GENERAL_INFO_LOG
		.getLogBuilder(
				"Executing [ " + this.getClass().getName() + "."
						+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
				this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
		.writeLog();
		
		final SubscriptionService service = new SubscriptionService();
		final Map<String, Object> filters = new HashMap<String, Object>();
		final BasicOperations o = new BasicOperations();
		final Date currentDate = new Date();
		o.gt(DateUtils.addHours(currentDate, -4).getTime());
		o.lte(DateUtils.addHours(currentDate, 4).getTime());
		filters.put("periodEndDate", o);
		filters.put("status", SubscriptionStatusEnum.RENEWING.toString());
		try {
			Page page;
			SearchResult<SubscriberSubscription> result;
			int pageNo = 1;
			do {
				page = new Page(1000, pageNo++);
				result = service.findSubscriptionsByFilters(filters, Levels.COMPLETE, page);
			SubscriptionRenewService.getInstance().updateBulkRenewStatus(result.getResult());

			} while (result.getDocumentsCount() > result.getPage().getPageLength() * result.getPage().getPageNo());
		} catch (final Exception e) {
			DappLoggerService.GENERAL_INFO_LOG
			.getLogBuilder(
					"Executing [ " + this.getClass().getName() + "."
							+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
			.writeLog();
		}
		
	}
 
}
