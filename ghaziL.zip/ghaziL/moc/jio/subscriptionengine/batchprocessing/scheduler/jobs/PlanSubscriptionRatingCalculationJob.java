package com.jio.subscriptionengine.batchprocessing.scheduler.jobs;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.StringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.Cardinality;

import com.elastic.search.enums.Levels;
import com.elastic.search.launcher.SessionFactory;
import com.elastic.search.service.Session;
import com.jio.subscriptionengine.batchprocessing.clearCodes.ClearCodeLevel;
import com.jio.subscriptionengine.batchprocessing.clearCodes.ClearCodes;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.reviewrating.service.CustomerReviewService;
import com.jio.subscriptionengine.batchprocessing.modules.subscribe.service.SubscribeService;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;

@Controller
@RequestMapping(name = "/create-plan-rating")
public class PlanSubscriptionRatingCalculationJob implements DispatcherBaseController {

	@RequestMapping(name = "/calculate", type = HttpRequestMethod.POST)
	@EventName("CREATE-PLAN-RATING-JOB")
	public void calculatePlanRating(final HttpServletRequest req, final HttpServletResponse resp) {

		final SessionFactory factory = SessionFactory.getSessionFactory();
		final Session session = factory.getSession();
		session.setSearchLevel(Levels.NONE);

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final ClearCodeAsnPojo ccAsnPojo = BatchProcessingBootStrapper.getInstance().getClearCodeObj();
		try {
			final AggregationBuilder aggs = AggregationBuilders.cardinality("distinct_plan_count")
					.field("plan.id.keyword");
			final Cardinality term = (Cardinality) session.aggregation(SubscriberSubscription.class, aggs,
					new HashMap<>());
			final AggregationBuilder childAggregation = AggregationBuilders.terms("plan").field("plan.id.keyword")
					.size((int) term.getValue());
			final StringTerms aggregation = (StringTerms) session.aggregation(SubscriberSubscription.class,
					childAggregation, new HashMap<>());
			final SubscribeService subscribeService = new SubscribeService();
			for (final Bucket bucket : aggregation.getBuckets()) {
				CustomerReviewService.getInstance().setPlanReviewAndRatingIntoRedis((String) bucket.getKey());
				subscribeService.setSubscriberCountByPlanIntoRedis((String) bucket.getKey(), bucket.getDocCount());
			}
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CALCULATE_PLAN_RATING_SUCCESS.getValue(),
					ClearCodeLevel.SUCCESS);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

		} catch (final Exception e) {
			ccAsnPojo.addClearCode(ClearCodes.MARKETPLACE_CALCULATE_PLAN_RATING_FAILURE.getValue(),
					ClearCodeLevel.FAILURE);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

		} finally {
			session.close();
		}

	}

}
