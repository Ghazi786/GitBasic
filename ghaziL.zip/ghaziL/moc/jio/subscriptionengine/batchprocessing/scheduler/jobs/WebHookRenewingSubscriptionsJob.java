package com.jio.subscriptionengine.batchprocessing.scheduler.jobs;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;

import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionRenewService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;
import com.jio.subscriptionengine.batchprocessing.utils.DateUtil;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;

@Controller
@RequestMapping(name = "/webhook-renewing-job")
public class WebHookRenewingSubscriptionsJob implements DispatcherBaseController {

	@EventName("WEBHOOK_RENEWING_SUBSCRIPTIONS")
	@RequestMapping(name = "/webhook-renewing-subscriptions", type = HttpRequestMethod.GET)
	public void renewSubscriptions(final HttpServletRequest req, final HttpServletResponse resp) throws Exception {

		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		final Date currentDate = new Date();

		final Date sdate = DateUtil.getStartTime(DateUtils.addDays(currentDate, 1));
		final Date edate = DateUtil.getEndTime(DateUtils.addDays(currentDate, 1));

		final QueryBuilder query = SubscriptionRenewService.getInstance().renewQuery(sdate, edate);

		final BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
		boolQueryBuilder.filter(query);

		Page page;
		int pageNo = 1;

		SearchResult<SubscriberSubscription> searchResult;
		
		final BaseEventBean baseEventBean =ServiceCommunicator.getBaseEventBeanObject(req);

		try {
			final SubscriptionService subscriptionService = new SubscriptionService();

			do {
				page = new Page(1000, pageNo++);

				searchResult = subscriptionService.getSubscriptions(boolQueryBuilder, page);

				SubscriptionRenewService.getInstance().postWebhookRenewSubscriptionData(searchResult.getResult(),baseEventBean);

			} while (searchResult.getDocumentsCount() > searchResult.getPage().getPageLength()
					* searchResult.getPage().getPageNo());

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
					.writeExceptionLog();

		}
	}

}
