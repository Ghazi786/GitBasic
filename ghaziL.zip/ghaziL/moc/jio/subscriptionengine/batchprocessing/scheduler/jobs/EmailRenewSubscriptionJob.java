package com.jio.subscriptionengine.batchprocessing.scheduler.jobs;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateUtils;

import com.elastic.search.bean.BasicOperations;
import com.elastic.search.bean.Page;
import com.elastic.search.bean.SearchResult;
import com.elastic.search.enums.Levels;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.RequestHeaderEnum;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.Currency;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.payment.helper.ChecksumRequestFlowTypes;
import com.jio.subscriptionengine.batchprocessing.modules.payment.service.PaymentService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.helper.SubscriptionStatusEnum;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.EmailSubscriptionService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;
import com.jio.subscriptionengine.batchprocessing.utils.DateUtil;
import com.jio.subscriptionengine.batchprocessing.utils.NumberUtil;
import com.jio.subscriptionengine.batchprocessing.utils.ServiceCommunicator;
import com.jio.subscriptions.modules.bean.PaymentLink;

/**
 * This job will send bulk email for renew subscription
 * 
 * @author Ashish14.Gupta
 *
 */
@Controller
@RequestMapping(name = "/subscription-renew-email-job")
public class EmailRenewSubscriptionJob implements DispatcherBaseController {

	@EventName("RENEW-EMAIL-JOB")
	@RequestMapping(name = "/renew-email-job", type = HttpRequestMethod.GET)
	public void renewEmailSubscription(final HttpServletRequest req, final HttpServletResponse resp) {
		final String ENCLOSED = "\"";
		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();
		int days = NumberUtil.stringToNumber(req.getParameter("days"));
		final SubscriptionService service = new SubscriptionService();
		final Map<String, Object> filters = new HashMap<String, Object>();
		final BasicOperations o = new BasicOperations();
		final Date currentDate = new Date();
		Date cdate = DateUtil.getStartTime(DateUtils.addDays(currentDate, days));
		Date edate = DateUtil.getEndTime(DateUtils.addDays(currentDate, days));
		o.gte(cdate.getTime());
		o.lte(edate.getTime());

		filters.put("renewsOn", o);
		filters.put("status", SubscriptionStatusEnum.RENEWING.getValue());
		try {
			Page page;
			SearchResult<SubscriberSubscription> result;
			int pageNo = 1;
			do {
				page = new Page(1000, pageNo++);
				result = service.findSubscriptionsByFilters(filters, Levels.COMPLETE, page);
				/**
				 * SOC - 26/04/2020 code to generate payment link for manual renew and send it
				 * in an email : Madhushree.Malkar
				 */
				result.getResult().forEach(subscription -> {
					Currency marketPlacePricePerUnit = subscription.getPlan().getMarketPlacePricePerUnit();

					if (!subscription.getPlan().isAutoRenew() && marketPlacePricePerUnit.getUnitAmount() > 0
							&& subscription.getRemainingBillingCount() > 0) {
						final PaymentLink paylinkObj = new PaymentLink();
						paylinkObj.setId(subscription.getId());
						paylinkObj.setCreatedOn(new Date());
						paylinkObj.setPaymentChecksumFlow(ChecksumRequestFlowTypes.MANUAL_RENEW_PLAN.getValue());
						paylinkObj.setSubscriberId(subscription.getSubscriberId());
						paylinkObj.setSubscriptionSubscriberId(subscription.getId());
						paylinkObj.setPlanId(subscription.getPlan().getId());
						paylinkObj.setActive(true);
						try {
							String addPaymentLink = new PaymentService().addPaymentLink(paylinkObj);
							final String requestURI = ServiceCommunicator
									.url(req.getHeader(RequestHeaderEnum.HEADER_NAME_LB_URL.getValue()), "");
							//@formatter:off
				            final String url = new StringBuilder(ENCLOSED)
				                    .append(requestURI)
				                    .append("se-marketplace/#/payment-gateway?token=")
				                    .append(addPaymentLink).append(ENCLOSED).toString();
				            // TODO : send url in email
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				/**
				 * EOC - 26/04/2020 code to generate payment link for manual renew and send it in
				 * an email : Madhushree.Malkar
				 */
				EmailSubscriptionService.getInstance().sendBulkEmail(result.getResult(),
						EmailTemplateConstants.SUBSCRIPTION_CHANGE_LABEL,
						EmailSubscriptionService.getInstance().isNewInvoiceNotification());

			} while (result.getDocumentsCount() > result.getPage().getPageLength() * result.getPage().getPageNo());

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}

	}
}
