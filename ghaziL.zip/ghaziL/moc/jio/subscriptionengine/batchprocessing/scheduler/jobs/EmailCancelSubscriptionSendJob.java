package com.jio.subscriptionengine.batchprocessing.scheduler.jobs;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.jio.subscriptionengine.batchprocessing.core.DispatcherBaseController;
import com.jio.subscriptionengine.batchprocessing.core.HttpRequestMethod;
import com.jio.subscriptionengine.batchprocessing.core.annotations.Controller;
import com.jio.subscriptionengine.batchprocessing.core.annotations.EventName;
import com.jio.subscriptionengine.batchprocessing.core.annotations.RequestMapping;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.modules.bean.SubscriberSubscription;
import com.jio.subscriptionengine.batchprocessing.modules.emailTemplates.helper.EmailTemplateConstants;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.EmailSubscriptionService;
import com.jio.subscriptionengine.batchprocessing.modules.subscription.service.SubscriptionService;

/**
 * This job will send email the user of upcoming subscriptions going to be
 * terminated
 * 
 * @author Samrudhi.Gandhe
 *
 */
@Controller
@RequestMapping(name = "/cancel-subscription-email-job")
public class EmailCancelSubscriptionSendJob implements DispatcherBaseController {

	@EventName("CANCEL_EMAIL_JOB")
	@RequestMapping(name = "/cancel-email", type = HttpRequestMethod.POST)
	public void cancelEmailSubscription(final HttpServletRequest req, final HttpServletResponse resp) {

		// logger
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder(
						"Executing [ " + this.getClass().getName() + "."
								+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
						this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName())
				.writeLog();

		try {

			// logger
			String reqData = IOUtils.toString(req.getReader()).toString();
			DappLoggerService.GENERAL_INFO_LOG
					.getLogBuilder(
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							"Req Data :", reqData)
					.writeLog();
			final SubscriptionService subscriptionService = new SubscriptionService();
			ObjectMapper mapper = new ObjectMapper();
			ArrayNode reqArray = mapper.readValue(reqData, ArrayNode.class);
			List<SubscriberSubscription> list = new ArrayList<SubscriberSubscription>();
			for (JsonNode node : reqArray) {
				String subscriptionId = node.get("subscriptionId").asText();
				String subcriberId = node.get("subscriberId").asText();
				SubscriberSubscription subscriberSubscription = subscriptionService.getSubscription(subcriberId,
						subscriptionId);
				list.add(subscriberSubscription);
			}

//			final SubscriptionService subscriptionService = new SubscriptionService();
//			ObjectMapper mapper=new ObjectMapper();
//			JsonNode reqJson=mapper.readValue(req.getReader(), JsonNode.class);
//			ArrayNode reqArray=(ArrayNode) reqJson.get("list");
//			List<SubscriberSubscription> list=new ArrayList<SubscriberSubscription>();
//			for(JsonNode node:reqArray) {
//				String subscriptionId=node.get("subscriptionId").asText();
//				String subcriberId=node.get("subscriberId").asText();
//				SubscriberSubscription subscriberSubscription=	subscriptionService.getSubscription(subcriberId, subscriptionId);
//				list.add(subscriberSubscription);
//			}

			EmailSubscriptionService.getInstance().sendBulkEmail(list,
					EmailTemplateConstants.SUBSCRIPTION_CANCELLED_LABEL,
					EmailSubscriptionService.getInstance().isCanceledsubscriptionNotification());

		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e, e.getMessage(),
					this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeLog();
		}

	}

}
