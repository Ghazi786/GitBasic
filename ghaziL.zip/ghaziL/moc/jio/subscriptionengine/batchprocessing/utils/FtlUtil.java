package com.jio.subscriptionengine.batchprocessing.utils;

import java.util.Map;

public interface FtlUtil {
	
	String buildPojoObj(String label,Object obj) throws Exception;
	String buildPojoMap(String label,Map <String,Object> data) throws Exception;

	
	

}
