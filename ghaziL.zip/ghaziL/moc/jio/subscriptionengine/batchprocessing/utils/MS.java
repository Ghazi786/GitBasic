package com.jio.subscriptionengine.batchprocessing.utils;

public enum MS {
	CONFIGURATION_MS,

	SUBSCRIBERS_MS,

	INTEGRATIONS_MS,

	USER_SUBSCRIPTION_MS, BATCH_PROCESSING_MS,
	PSC;
}