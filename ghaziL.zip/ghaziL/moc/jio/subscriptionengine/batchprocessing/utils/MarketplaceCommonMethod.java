package com.jio.subscriptionengine.batchprocessing.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.elastic.search.service.impl.ObjectMapperHelper;
import com.jio.subscriptionengine.batchprocessing.core.BaseEventBean;
import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.core.Cursor;
import com.jio.subscriptionengine.batchprocessing.core.HttpParamConstants;
import com.jio.subscriptionengine.batchprocessing.core.RequestHeaderEnum;
import com.jio.subscriptionengine.batchprocessing.core.RestApiCalls;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;

/**
 * Utility class which will have useful methods to perform processing in Devops
 * 
 * @author Barun.Rai
 *
 */

public class MarketplaceCommonMethod {

	private static final String CONTENT_TYPE_OCTET = "application/octet-stream";
	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "attachment; filename=\"";

	private MarketplaceCommonMethod() {

	}

	/**
	 * Method to extract DevopsEvent object form request
	 * 
	 * @param httpRequest
	 * @return
	 */
	public static BaseEventBean getEventTrackingObject(HttpServletRequest httpRequest) {

		try {

			BaseEventBean eventTracking = new BaseEventBean();
			eventTracking.setBranchId(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_BRANCH_ID.getValue()));
			eventTracking.setEventName(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_EVENT_NAME.getValue()));
			eventTracking
					.setServiceContext(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_SERVICE_CONTEXT.getValue()));
			eventTracking.setFlowId(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_FLOW_ID.getValue()));
			eventTracking.setHopCount(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_HOP_COUNT.getValue()));
			eventTracking.setMessageType(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_MESSAGE_TYPE.getValue()));
			eventTracking.setServiceIp(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_SERVICE_IP.getValue()));
			eventTracking
					.setPublisherName(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_PUBLISHER_NAME.getValue()));

			eventTracking
					.setExecutionType(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_EXECUTION_TYPE.getValue()));

			eventTracking.setTimeStamp(System.currentTimeMillis());
			eventTracking.setRequest(httpRequest);

			// header introduced in 2.1 ELB
			eventTracking.setLbUrl(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_LB_URL.getValue()));
			eventTracking
					.setSocketAddress(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_SOCKET_ADDRESS.getValue()));
			eventTracking.setUsername(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_USERNAME.getValue()));

			// header introduced in 2.1 ERM
			eventTracking
					.setErmIdentifier(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_ERM_IDENTIFIER.getValue()));
			eventTracking.setTargetErm(httpRequest.getHeader(RequestHeaderEnum.HEADER_NAME_TARGET_ERM.getValue()));

			// adding all query parameters
			Enumeration<String> en = httpRequest.getParameterNames();
			Map<String, String> params = new HashMap<>();

			while (en.hasMoreElements()) {
				String paramName = en.nextElement();
				params.put(paramName, httpRequest.getParameter(paramName));
			}

			eventTracking.setRequestParams(params);

			// adding all headers in headers map
			Enumeration<String> headerKeys = httpRequest.getHeaderNames();
			Map<String, String> headers = new HashMap<>();

			while (headerKeys.hasMoreElements()) {
				String headerName = headerKeys.nextElement();
				headers.put(headerName, httpRequest.getHeader(headerName));
			}

			eventTracking.setRequestHeaders(headers);

			// adding request Body
			// eventTracking.setRequestStream(IOUtils.toByteArray(httpRequest.getInputStream()));

			// Executing Task to Dump Event Dumping Event Data
			// BootStrapper.getInstance().getDappExecutor().execute(new
			// EventDumpTask(eventTracking));

			return eventTracking;

		} catch (Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG.getExceptionLogBuilder(e,
					"Error in converting event pojo to json string :", "DevopsUtils", "getEventTrackingObject");
			return null;
		}

	}

	/**
	 * @param response
	 * @param responseBody
	 * @param status
	 * @param responseMessage
	 * @param cursor
	 */
	public static void sendResponse(final BaseEventBean eventPojo, final HttpServletResponse response,
			final Object responseBody, final int status, final String responseMessage, final Cursor cursor) {

		try {

			if (responseBody instanceof String) {
				String SEPERATOR = ",";
				String ENCLOSED = "\"";
				String SEPERATOR_COL = ":";

				StringBuilder sb = new StringBuilder();
				sb.append("{");
				if (responseBody != null)
					sb.append(ENCLOSED).append(Constants.RESPONSE_BODY).append(ENCLOSED).append(SEPERATOR_COL)
							.append(responseBody.toString()).append(SEPERATOR);

				sb.append(ENCLOSED).append(Constants.RESPONSE_MESSAGE).append(ENCLOSED).append(SEPERATOR_COL)
						.append(ENCLOSED).append(responseMessage).append(ENCLOSED).append(SEPERATOR);
				sb.append(ENCLOSED).append(Constants.RESPONSE_CODE).append(ENCLOSED).append(SEPERATOR_COL)
						.append(status).append(SEPERATOR);
				sb.append(ENCLOSED).append(Constants.CREATED_TIME_STAMP).append(ENCLOSED).append(SEPERATOR_COL)
						.append(System.currentTimeMillis());
				sb.append("}");
				response.setStatus(status);
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				PrintWriter printWriter;
				printWriter = response.getWriter();
				printWriter.print(sb.toString());
				printWriter.flush();
				printWriter.close();

			} else {

				Map<String, Object> jsonObj = new HashMap<>();
				if (responseBody != null)
					jsonObj.put(Constants.RESPONSE_BODY, responseBody);
				jsonObj.put(Constants.RESPONSE_MESSAGE, responseMessage);
				jsonObj.put(Constants.RESPONSE_CODE, status);
				jsonObj.put(Constants.CREATED_TIME_STAMP, System.currentTimeMillis());

				response.setStatus(status);
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				PrintWriter printWriter;
				printWriter = response.getWriter();
				printWriter.print(ObjectMapperHelper.getInstance().getEntityObjectMapper().writeValueAsString(jsonObj));
				printWriter.flush();
				printWriter.close();
			}
			ESConnection.getInstance().getHaOperation()
					.removeEventData(eventPojo.getFlowId() + "_" + eventPojo.getBranchId());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void sendFileStreamAsResponse(HttpServletResponse response, File file, int status,
			String responseMessage, Cursor cursor) {

		int bufferSize = 1024 * 10;
		byte[] buffer = new byte[bufferSize];
		if (file.exists()) {
			try (FileInputStream fis = new FileInputStream(file)) {

				response.setContentType(CONTENT_TYPE_OCTET);
				response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + file.getName() + "\"");
				response.setContentLength((int) file.length());
				OutputStream os = response.getOutputStream();

				int byteRead = 0;
				while ((byteRead = fis.read(buffer)) != -1) {
					os.write(buffer, 0, byteRead);

				}
				os.flush();

			} catch (Exception e) {
				try {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST);
				} catch (IOException e1) {
				}
			}
		} else {

			try {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			} catch (IOException e) {
			}

		}

	}

	/**
	 * 
	 * @param eventPojo
	 * @param appData
	 * @param inputStream
	 */

	public static void sendAsyncResponseToELB(BaseEventBean eventPojo, BaseResponse<?> appData,
			InputStream inputStream) {

		final String methodName = "sendResponseToMS";
		DappLoggerService.GENERAL_INFO_LOG
				.getLogBuilder("Execution Started of " + methodName + " " + eventPojo.toString(),
						MarketplaceCommonMethod.class.getSimpleName(), methodName)
				.writeLog();

		try {

			String data = null;
			if (appData.getData() instanceof String) {
				final String SEPERATOR = ",";
				final String ENCLOSED = "\"";
				final String SEPERATOR_COL = ":";

				final StringBuilder sb = new StringBuilder();
				sb.append("{");
				if (appData.getData() != null)
					sb.append(ENCLOSED).append(Constants.RESPONSE_BODY).append(ENCLOSED).append(SEPERATOR_COL)
							.append(appData.getData().toString()).append(SEPERATOR);

				sb.append(ENCLOSED).append(Constants.RESPONSE_MESSAGE).append(ENCLOSED).append(SEPERATOR_COL)
						.append(ENCLOSED).append(appData.getMessage()).append(ENCLOSED).append(SEPERATOR);
				sb.append(ENCLOSED).append(Constants.RESPONSE_CODE).append(ENCLOSED).append(SEPERATOR_COL).append(200)
						.append(SEPERATOR);
				sb.append(ENCLOSED).append(Constants.CREATED_TIME_STAMP).append(ENCLOSED).append(SEPERATOR_COL)
						.append(System.currentTimeMillis());
				sb.append("}");
				data = sb.toString();

			} else {

				final Map<String, Object> jsonObj = new HashMap<>();
				if (appData.getData() != null)
					jsonObj.put(Constants.RESPONSE_BODY, appData.getData());
				jsonObj.put(Constants.RESPONSE_MESSAGE, appData.getMessage());
				jsonObj.put(Constants.RESPONSE_CODE, 200);
				jsonObj.put(Constants.CREATED_TIME_STAMP, System.currentTimeMillis());
				jsonObj.put(Constants.RESPONSE_CODE, 200);
				data = ObjectMapperHelper.getInstance().getEntityObjectMapper().writeValueAsString(jsonObj);
			}

			if (eventPojo != null) {
				System.out.println(eventPojo.toString());
			}

			final Map<String, String> headerMap = new HashMap<>();
			headerMap.put(HttpParamConstants.FLOW_ID, eventPojo.getFlowId());
			headerMap.put(HttpParamConstants.BRANCH_ID, eventPojo.getBranchId());
			headerMap.put(HttpParamConstants.EVENT_NAME, eventPojo.getEventName());
			headerMap.put(HttpParamConstants.HOP_COUNT, eventPojo.getHopCount());
			headerMap.put(HttpParamConstants.SRC_MS_IP_PORT, eventPojo.getServiceIp());
			headerMap.put(HttpParamConstants.SRC_MS_CONTEXT, eventPojo.getServiceContext());
			headerMap.put(HttpParamConstants.MSG_TYPE, HttpParamConstants.MSG_TYPE_EVENT_ACK_VALUE);
			headerMap.put(HttpParamConstants.PUBLISHER_NAME, eventPojo.getPublisherName());

			// header introduced in 2.1 ELB
			if (eventPojo.getLbUrl() != null)
				headerMap.put(RequestHeaderEnum.HEADER_NAME_LB_URL.getValue(), eventPojo.getLbUrl());
			if (eventPojo.getSocketAddress() != null)
				headerMap.put(RequestHeaderEnum.HEADER_NAME_SOCKET_ADDRESS.getValue(), eventPojo.getSocketAddress());
			if (eventPojo.getUsername() != null)
				headerMap.put(RequestHeaderEnum.HEADER_NAME_USERNAME.getValue(), eventPojo.getUsername());

			final String requestURI = "http://" + eventPojo.getLbUrl() + Constants.EdgeLB_WebSocket;
			final Object jsondata = RestApiCalls.post(requestURI, data, headerMap);

			// Removing Event from Dump
			ESConnection.getInstance().getHaOperation()
					.removeEventData(eventPojo.getFlowId() + "_" + eventPojo.getBranchId());
		} catch (final Exception e) {

		}
	}

}
