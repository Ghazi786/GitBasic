package com.jio.subscriptionengine.batchprocessing.utils;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;

public class DateUtil {

	private static final String MONTH = "month";
	private static final String DAYS = "days";
	private static final String DAY = "day";
	private static final String YEAR = "year";

	public static Date getDateByType(final Date periodStartDate, final String type, final int intervalValue) {
		if (DAYS.equalsIgnoreCase(type) || DAY.equalsIgnoreCase(type)) {
			return DateUtils.addDays(periodStartDate, intervalValue);
		} else if (MONTH.equalsIgnoreCase(type)) {
			return DateUtils.addMonths(periodStartDate, intervalValue);
		} else {
			return DateUtils.addYears(periodStartDate, intervalValue);
		}
	}

	public static Date getStartTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static Date getEndTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 999);
		return cal.getTime();
	}

}
