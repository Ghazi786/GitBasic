package com.jio.subscriptionengine.batchprocessing.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;

public class LoggerUtilityService {
	
	private final static ExecutorService EXECUTOR_SERVICE = Executors.newCachedThreadPool();
	private final static LoggerUtilityService UTILITY_SERVICE = new LoggerUtilityService();
	
	private LoggerUtilityService(){
		
	}
	
	public static LoggerUtilityService getInstance(){
		return UTILITY_SERVICE;
	}

	public void writeInfoLog(final String description, final String className, final String methodName) {
		final Runnable runnable = () -> {
			DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(description, className, methodName).writeLog();
		};
		write(runnable);
	}

	public void writeExceptionLog(final Exception e, final String errorDescription, final String className,
			final String methodName) {
		final Runnable runnable = () -> {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e, errorDescription, className, methodName).writeExceptionLog();
		};
		write(runnable);
	}

	private void write(final Runnable runnable) {
		try {
			if (runnable == null)
				return;

			LoggerUtilityService.EXECUTOR_SERVICE.submit(runnable);
		} catch (final Exception e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
					.getExceptionLogBuilder(e,
							"Executing [ " + this.getClass().getName() + "."
									+ Thread.currentThread().getStackTrace()[1].getMethodName() + " ]",
							this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName()).writeExceptionLog();
		} 
	}

}
