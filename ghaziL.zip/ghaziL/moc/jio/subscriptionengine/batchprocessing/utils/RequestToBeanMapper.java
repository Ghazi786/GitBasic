package com.jio.subscriptionengine.batchprocessing.utils;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;

import com.jio.subscriptionengine.batchprocessing.core.BaseResponse;
import com.jio.subscriptionengine.batchprocessing.exceptions.InvalidRequestParamValueException;
import com.jio.subscriptionengine.batchprocessing.logger.DappLoggerService;

/**
 * Utility is responsible for populating the request params into mentioned class bean.
 * If error occurs while populating request params into bean it throws InvalidRequestParamValueException 
 * 
 * @author Samrudhi.Gandhe
 *
 */
public class RequestToBeanMapper {


	public static <T> T getBeanFromRequest(final HttpServletRequest req, final Class<T> clazz) throws InvalidRequestParamValueException {
		String json;
		try {
			json = IOUtils.toString(req.getReader());
			return ObjectMapperHelper.getInstance().getEntityObjectMapper().readValue(json, clazz);
		} catch (final IOException e) {
			DappLoggerService.GENERAL_ERROR_FAILURE_LOG
			.getExceptionLogBuilder(e, e.getMessage(),	"RequestToBeanMapper" , "getBeanFromRequest")
			.writeExceptionLog();
			throw new InvalidRequestParamValueException(422, "Invalid request parameter value");
		}
	}

	public static <T> T getBeanFromString(final String json, final Class<T> clazz) throws InvalidRequestParamValueException {
		try {
			return ObjectMapperHelper.getInstance().getEntityObjectMapper().readValue(json, clazz);
		} catch (final IOException e) {
			throw new InvalidRequestParamValueException(422, "Invalid request parameter value");
		}
	}

	public static BaseResponse<?> getErrorResponse(final int errorCode,	final String message) {
		@SuppressWarnings({ "rawtypes", "unchecked" })
		final BaseResponse<?> response = new BaseResponse(null, false, message, errorCode, null);
		return response;
	}
	
	public static String getCookie(final HttpServletRequest req, String key) {
		if (req.getCookies() != null) {
			for (Cookie cookie : req.getCookies()) {
				if (cookie.getName().equals(key))
					return cookie.getValue();
			}
		}
		return null;
	}
	
	public static String getSubscriberId(final HttpServletRequest req) {
		 return req.getHeader("X-Subscriber-Id") ; 
	}
	
	
	
}
