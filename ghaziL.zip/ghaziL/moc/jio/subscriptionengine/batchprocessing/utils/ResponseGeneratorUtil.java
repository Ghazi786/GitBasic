package com.jio.subscriptionengine.batchprocessing.utils;

import com.elastic.search.bean.SearchResult;

public class ResponseGeneratorUtil {

	
	public static String getStringResponse(final SearchResult<String> searchResult) {
		final String SEPERATOR = ",";
		final String ENCLOSED = "\"";
		final String SEPERATOR_COL = ":";

		final StringBuilder sb = new StringBuilder();
		sb.append("{");
		if (searchResult != null) {
			sb.append(ENCLOSED).append("documentsCount").append(ENCLOSED).append(SEPERATOR_COL)
					.append(searchResult.getDocumentsCount()).append(SEPERATOR);

			sb.append(ENCLOSED).append("page").append(ENCLOSED).append(SEPERATOR_COL).append("{");

			sb.append(ENCLOSED).append("pagesCount").append(ENCLOSED).append(SEPERATOR_COL)
					.append(searchResult.getPage().getPagesCount()).append(SEPERATOR);
			sb.append(ENCLOSED).append("pageLength").append(ENCLOSED).append(SEPERATOR_COL)
					.append(searchResult.getPage().getPageLength()).append(SEPERATOR);
			sb.append(ENCLOSED).append("pageNo").append(ENCLOSED).append(SEPERATOR_COL)
					.append(searchResult.getPage().getPageNo());

			sb.append("}");
			sb.append(SEPERATOR);
			sb.append(ENCLOSED).append("result").append(ENCLOSED).append(SEPERATOR_COL)
					.append(searchResult.getResult().toString());
		}
		sb.append("}");
		return sb.toString();
	}
	

}
