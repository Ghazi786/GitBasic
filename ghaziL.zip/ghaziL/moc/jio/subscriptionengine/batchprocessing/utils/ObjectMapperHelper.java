package com.jio.subscriptionengine.batchprocessing.utils;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonFactory.Feature;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Samrudhi.Gandhe
 *
 */
public class ObjectMapperHelper {
	private static ObjectMapperHelper mapper = new ObjectMapperHelper();

	private final ObjectMapper entityObjectMapper;

	private ObjectMapperHelper() {
		entityObjectMapper = new ObjectMapper();
		entityObjectMapper.getFactory().configure(Feature.INTERN_FIELD_NAMES, false);
	}

	public static ObjectMapperHelper getInstance() {
		return mapper;
	}

	public ObjectMapper getEntityObjectMapper() {
		return entityObjectMapper;
	}

	public <T> T getBeanFromString(final String json, final Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {

		return entityObjectMapper.readValue(json, clazz);

	}
	
	public <T> T getBeanFromObject(final Object json, final Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {

		return entityObjectMapper.convertValue(json, clazz);

	}
}
