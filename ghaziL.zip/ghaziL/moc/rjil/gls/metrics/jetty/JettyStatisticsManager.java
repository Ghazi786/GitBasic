/*    */ package com.rjil.gls.metrics.jetty;
/*    */ 
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import org.eclipse.jetty.server.Server;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JettyStatisticsManager
/*    */ {
/*    */   public void getJettyServerConnectorStatistics(String fileName, Server server) throws IOException {
/*    */     try {
/* 21 */       JettyStatisticsDump jettyStatisticsDump = new JettyStatisticsDump();
/* 22 */       String res = jettyStatisticsDump.getJettyServerConnectorStatistics(server);
/*    */       
/* 24 */       try(FileWriter fw = new FileWriter(fileName, true); BufferedWriter bw = new BufferedWriter(fw)) {
/* 25 */         bw.write(res);
/*    */       }
/*    */     
/* 28 */     } catch (IOException e) {
/*    */       
/* 30 */       StackTrace.printToConsole("Exception occured : " + e.getMessage());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\metrics\jetty\JettyStatisticsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */