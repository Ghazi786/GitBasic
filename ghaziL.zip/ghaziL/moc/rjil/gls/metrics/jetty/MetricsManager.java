/*     */ package com.rjil.gls.metrics.jetty;
/*     */ 
/*     */ import com.codahale.metrics.JmxReporter;
/*     */ import com.codahale.metrics.MetricRegistry;
/*     */ import com.codahale.metrics.Timer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetricsManager
/*     */ {
/*  12 */   private static MetricsManager metricsManager = new MetricsManager();
/*  13 */   private MetricRegistry metrics = new MetricRegistry();
/*     */   
/*  15 */   private Timer receiveTxnWithSmartContractId = this.metrics.timer("receive-Txn-With-Smart-Contract-Id");
/*  16 */   private Timer jsonValidationCheck = this.metrics.timer("json-Validation-Check");
/*  17 */   private Timer dbOperation = this.metrics.timer("db-Operation");
/*  18 */   private Timer kafkaOperation = this.metrics.timer("kafka-Operation");
/*  19 */   private JmxReporter jmxReporter = JmxReporter.forRegistry(this.metrics).build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MetricsManager() {
/*  26 */     this.jmxReporter.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public static MetricsManager getInstance() {
/*  31 */     return metricsManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer getReceiveTxnWithSmartContractId() {
/*  40 */     return this.receiveTxnWithSmartContractId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer getJsonValidationCheck() {
/*  47 */     return this.jsonValidationCheck;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer getDbOperation() {
/*  54 */     return this.dbOperation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer getKafkaOperation() {
/*  61 */     return this.kafkaOperation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReceiveTxnWithSmartContractId(Timer receiveTxnWithSmartContractId) {
/*  68 */     this.receiveTxnWithSmartContractId = receiveTxnWithSmartContractId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJsonValidationCheck(Timer jsonValidationCheck) {
/*  75 */     this.jsonValidationCheck = jsonValidationCheck;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDbOperation(Timer dbOperation) {
/*  82 */     this.dbOperation = dbOperation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKafkaOperation(Timer kafkaOperation) {
/*  89 */     this.kafkaOperation = kafkaOperation;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReceiveTxnWithSmartContractIdDump() {
/*  94 */     return getSnapshot(this.receiveTxnWithSmartContractId);
/*     */   }
/*     */   
/*     */   public String getJsonValidationCheckDump() {
/*  98 */     return getSnapshot(this.jsonValidationCheck);
/*     */   }
/*     */   
/*     */   public String getDbOperationDump() {
/* 102 */     return getSnapshot(this.dbOperation);
/*     */   }
/*     */   
/*     */   public String getKafkaOperationDump() {
/* 106 */     return getSnapshot(this.kafkaOperation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSnapshot(Timer timer) {
/* 112 */     String result = null;
/* 113 */     StringBuilder snapshot = new StringBuilder();
/* 114 */     if (timer == null) {
/* 115 */       snapshot.append("\n=============================================================================\n");
/* 116 */       snapshot.append("No operation. Could not dump the statistics.\n");
/* 117 */       snapshot.append("=============================================================================\n");
/*     */     } else {
/*     */       
/* 120 */       snapshot.append("\n=============================================================================\n");
/* 121 */       snapshot.append("Getting statistics...\n");
/* 122 */       snapshot.append("=============================================================================\n");
/* 123 */       snapshot.append("\n\t\tTotal count            : " + timer.getCount());
/* 124 */       snapshot.append("\n\t\tMean rate              : " + timer.getMeanRate());
/* 125 */       snapshot.append("\n\t\tOne Minute Rate        : " + timer.getOneMinuteRate());
/* 126 */       snapshot.append("\n\t\tFive Minute Rate       : " + timer.getFiveMinuteRate());
/* 127 */       snapshot.append("\n\t\tFifteen Minute Rate    : " + timer.getFifteenMinuteRate());
/* 128 */       snapshot.append("\n\t\tMinimum Time           : " + timer.getSnapshot().getMin());
/* 129 */       snapshot.append("\n\t\tMaximum Time           : " + timer.getSnapshot().getMax());
/* 130 */       snapshot.append("\n\t\tMean Time              : " + timer.getSnapshot().getMean());
/* 131 */       snapshot.append("\n\t\tMedian Time            : " + timer.getSnapshot().getMedian());
/* 132 */       snapshot.append("\n\t\tStd Deviation          : " + timer.getSnapshot().getStdDev());
/* 133 */       snapshot.append("\n\t\t75% Execution Time     : " + timer.getSnapshot().get75thPercentile());
/* 134 */       snapshot.append("\n\t\t95% Execution Time     : " + timer.getSnapshot().get95thPercentile());
/* 135 */       snapshot.append("\n\t\t98% Execution Time     : " + timer.getSnapshot().get98thPercentile());
/* 136 */       snapshot.append("\n\t\t99% Execution Time     : " + timer.getSnapshot().get99thPercentile());
/* 137 */       snapshot.append("\n\t\t99.9% Execution Time   : " + timer.getSnapshot().get999thPercentile() + "\n");
/*     */     } 
/*     */     
/* 140 */     result = snapshot.toString();
/* 141 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\metrics\jetty\MetricsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */