/*     */ package com.rjil.gls.metrics.jetty;
/*     */ 
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
/*     */ import org.apache.http.pool.PoolStats;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyStatisticsDump
/*     */ {
/*     */   public String getJettyServerConnectorStatistics(Server server) {
/*  22 */     StringBuilder builder = new StringBuilder();
/*     */     
/*     */     try {
/*  25 */       if (server == null) {
/*  26 */         String s = "******************************************************\n";
/*  27 */         builder.append(s);
/*     */         
/*  29 */         builder.append("    Server is null. Could not dump the statistics.    \n");
/*     */         
/*  31 */         builder.append(s);
/*     */       } else {
/*     */         
/*  34 */         String s = "******************************************************************************************************************* \n";
/*  35 */         builder.append(s);
/*  36 */         builder.append("                                                        Jetty Server Connector Statistics :                                 \n");
/*     */         
/*  38 */         builder.append(s);
/*  39 */         builder.append("---------------------------------------------------------------------------------------------- \njetty Server Running State                          : " + server
/*     */             
/*  41 */             .getState() + " \nJetty Server URI                                    : " + server
/*  42 */             .getURI() + " \nJetty Server Version                                : " + 
/*  43 */             Server.getVersion() + " \nJetty Server StopTimeout                            : " + server
/*     */             
/*  45 */             .getStopTimeout() + " \nMaximum Number of Threads Available in The Pool     : " + server
/*     */             
/*  47 */             .getThreadPool().getThreads() + " \nMaximum Number of IdleThreds Available in The Pool  : " + server
/*     */             
/*  49 */             .getThreadPool().getIdleThreads() + " \nIs ThreadPool Low On Threads                        : " + server
/*     */             
/*  51 */             .getThreadPool().isLowOnThreads() + " \n-----------------------------------------------------------------------------------------------");
/*     */       }
/*     */     
/*     */     }
/*  55 */     catch (Exception e) {
/*  56 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*     */     } 
/*  58 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHttpClientStatistics(PoolingHttpClientConnectionManager httpClientConnectionManager) {
/*  63 */     StringBuilder builder = new StringBuilder();
/*     */     
/*  65 */     if (httpClientConnectionManager == null) {
/*  66 */       String s = "******************************************************\n";
/*  67 */       builder.append(s);
/*     */       
/*  69 */       builder.append("    httpClientConnectionManager is null. Could not dump the statistics.\n");
/*     */       
/*  71 */       builder.append(s);
/*     */     } else {
/*     */       
/*  74 */       String s = "******************************************************************************************************************* \n";
/*  75 */       PoolStats poolStats = httpClientConnectionManager.getTotalStats();
/*  76 */       builder.append(s);
/*  77 */       builder.append("                                                     \t  HTTP Client Statistics :                                  \n");
/*     */       
/*  79 */       builder.append(s);
/*  80 */       builder.append("Default Max Per Route                                                                         " + httpClientConnectionManager
/*     */           
/*  82 */           .getDefaultMaxPerRoute() + "\n");
/*  83 */       builder.append("Max Total                                                                                     " + httpClientConnectionManager
/*     */           
/*  85 */           .getMaxTotal() + "\n");
/*  86 */       builder.append("Total Stats                                                                                   " + httpClientConnectionManager
/*     */           
/*  88 */           .getTotalStats() + "\n");
/*  89 */       builder.append("Number of idle persistent(available) connections(Total connections = Available+Leased)        " + poolStats
/*     */           
/*  91 */           .getAvailable() + "\n");
/*  92 */       builder.append("Number of persistent connections currently being used to execute requests(Leased connections) " + poolStats
/*     */           
/*  94 */           .getLeased() + "\n");
/*  95 */       builder.append("Maximum number of allowed persistent connections                                              " + poolStats
/*     */           
/*  97 */           .getMax() + "\n");
/*  98 */       builder.append("Number of connection requests being blocked awaiting a free connection(Pending requests)      " + poolStats
/*     */           
/* 100 */           .getPending() + "\n");
/*     */     } 
/*     */ 
/*     */     
/* 104 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\metrics\jetty\JettyStatisticsDump.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */