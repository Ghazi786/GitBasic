/*     */ package com.rjil.gls.metrics.jetty;
/*     */ 
/*     */ import com.jio.telco.framework.pool.PoolingManager;
/*     */ import com.rjil.gls.boostrapmanager.GLSBootstrapper;
/*     */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import com.rjil.gls.timertask.GLSTimerTask;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.Map;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonStatistics
/*     */   implements CommonStatisticsMBean
/*     */ {
/*  26 */   private static CommonStatistics st = new CommonStatistics();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CommonStatistics getInstance() {
/*  33 */     if (st == null) {
/*  34 */       st = new CommonStatistics();
/*     */     }
/*  36 */     return st;
/*     */   }
/*     */   
/*     */   public void startStatisticsMbeanService() {
/*     */     try {
/*  41 */       MBeanServer counterMbeanServer = ManagementFactory.getPlatformMBeanServer();
/*  42 */       ObjectName adapterName = new ObjectName("com.rjil.gls.metrics.jetty:rtSDP_gls=CommonStatisticsMBean");
/*  43 */       counterMbeanServer.registerMBean(this, adapterName);
/*     */     }
/*  45 */     catch (Exception e) {
/*  46 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String fetchJettyStats() {
/*  53 */     return GLSBootstrapper.getInstance().getJettyRestEngine().jettyStats();
/*     */   }
/*     */ 
/*     */   
/*     */   public String fetchPoolingStats() {
/*  58 */     return PoolingManager.getPoolingManager().getPoolStatistics();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getHeaderMap() {
/*  63 */     return GLSCacheManager.getInstance().getHeaderMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getPropertyMap() {
/*  68 */     return GLSCacheManager.getInstance().getPropertyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public void gracefulSHutdown() {
/*  73 */     StackTrace.printToConsole("Received request for graceful shutdown");
/*  74 */     Timer time = new Timer();
/*  75 */     time.schedule(new WaitAndshutdownApplication(), 2500L);
/*     */   }
/*     */   
/*     */   class WaitAndshutdownApplication
/*     */     extends TimerTask {
/*     */     public void run() {
/*     */       try {
/*  82 */         StackTrace.printToConsole("Gracefully shutting down application");
/*  83 */         System.exit(0);
/*  84 */       } catch (Exception e) {
/*  85 */         StackTrace.printToConsole("Exception Occured : " + e.getMessage() + "/n" + e.getCause());
/*  86 */         System.exit(1);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean stopLoad() {
/*  95 */     GLSBootstrapper.timer.cancel();
/*  96 */     GLSBootstrapper.timer.purge();
/*  97 */     GLSBootstrapper.timerTask.cancel();
/*     */     
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean startLoad() {
/* 104 */     GLSBootstrapper.timer = new Timer();
/* 105 */     GLSBootstrapper.timerTask = (TimerTask)new GLSTimerTask();
/* 106 */     GLSBootstrapper.timer.schedule(GLSBootstrapper.timerTask, 1000L, 100L);
/*     */     
/* 108 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\metrics\jetty\CommonStatistics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */