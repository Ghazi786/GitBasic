package com.rjil.gls.metrics.jetty;

import java.util.Map;

public interface CommonStatisticsMBean {
  String fetchJettyStats();
  
  String fetchPoolingStats();
  
  Map<String, String> getHeaderMap();
  
  Map<String, String> getPropertyMap();
  
  void gracefulSHutdown();
  
  boolean stopLoad();
  
  boolean startLoad();
}


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\metrics\jetty\CommonStatisticsMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */