/*     */
package com.rjil.gls.boostrapmanager;

import com.elastic.search.config.ElasticConfig;
import com.elastic.search.config.IndexConfig;
import com.elastic.search.launcher.SessionFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
/*     */
/*     */ import com.jio.resttalk.service.impl.RestTalkManager;
import com.jio.subscriptionengine.batchprocessing.node.es.ESConnection;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscrition.testing.SubscriberCreateTask;
import com.jio.subscrition.testing.SubscriberExcelCreation;
import com.jio.subscrition.testing.SubscriberReadTask;
import com.jio.subscrition.testing.SubscriptionUniqueIdStorage;
/*     */ import com.jio.telco.framework.pool.PoolingManager;
/*     */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*     */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import com.rjil.gls.gracefulshutdown.ServerShutdownHook;
/*     */ import com.rjil.gls.jetty.JettyRestEngine;
/*     */ import com.rjil.gls.metrics.jetty.CommonStatistics;
/*     */ import com.rjil.gls.netty.client.GLSNettyChannelInitThread;
/*     */ import com.rjil.gls.netty.server.GLSNettyServer;
/*     */ import com.rjil.gls.poolfactory.GLSPoolingManager;
/*     */ import com.rjil.gls.threadpool.GLSSimulatorThreadPoolExecutor;
/*     */ import com.rjil.gls.threadpool.GLSThread;
/*     */ import com.rjil.gls.timertask.GLSCounterTimerTask;
/*     */ import com.rjil.gls.timertask.GLSTimerTask;
import com.rjil.gls.timertask.GLSTimerTaskCustomerDumpSubscription;
import com.rjil.gls.timertask.GLSTimerTaskSDRPDRSubscription;
import com.rjil.gls.timertask.GLSTimerTaskXMLCreation;
import com.rjil.gls.timertask.GLSUniqueIDcreationTask;

import java.io.IOException;
import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;

/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */ public class GLSBootstrapper
/*     */ {
	/* 38 */ private static final GLSBootstrapper gLSBootstrapper = new GLSBootstrapper();
	/*     */ private GLSSimulatorThreadPoolExecutor threadPoolExecutor;
	/* 40 */ private JettyRestEngine jettyRestEngine = new JettyRestEngine();
	/*     */
	/*     */
	/*     */ public static Timer timer;
	/*     */
	/*     */
	/*     */ public static TimerTask timerTask;

	public static Timer timer1;
	/*     */
	/*     */
	/*     */ public static TimerTask timerTask1;

	/*     */
	/*     */
	/*     */
	/*     */ public static GLSBootstrapper getInstance() {
		/* 51 */ return gLSBootstrapper;
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public static void main(String[] args) throws Exception {
		System.out.println("Packet runner starting");
		/* 59 */ System.setProperty("org.eclipse.jetty.util.log.class", "org.eclipse.jetty.util.log.StdErrLog");
		/* 60 */ System.setProperty("org.eclipse.jetty.LEVEL", "OFF");
		/*     */
		/* 62 */ RestTalkManager.getInstance().startRestTalk();
		/* 63 */ getInstance();
//				BatchProcessingBootStrapper.getInstance().initializeConfigParamSheet();
//				ESConnection.getInstance().initializeES();
		/* 64 */ gLSBootstrapper.loadConfiguration();
		/* 65 */ GLSPoolingManager.getInstance().initialize();
		gLSBootstrapper.initializeElasticSearchSessionFactory();
		/* 66 */ gLSBootstrapper.initThreadPoolExecuter();
		/* 67 */ gLSBootstrapper.initializeNettyServer();
		/*     */
///*  69 */     if (GLSConfigurationManager.getInstance().getInterfaceName().equalsIgnoreCase("http2")) {
///*  70 */       gLSBootstrapper.initializeNettyClientForRequest();
///*     */     }
		/*     */
		/* 73 */ gLSBootstrapper.initilizeJettyRestEngine();
		/* 74 */ gLSBootstrapper.initializeMbeans();
		System.out.println("Value====" + GLSConfigurationManager.getInstance().dump);

		// not using this ignore this condition
		if (GLSConfigurationManager.getInstance().dump == 1) {

//				SubscriberExcelCreation.createSubscriberExcel();
			timer = new Timer();
			timerTask = (TimerTask) new SubscriberReadTask();
			timer.schedule(timerTask, 1000L);
		}
		// create Subscriber in data base and writing into excel
		else if (GLSConfigurationManager.getInstance().dump == 2) {
			System.out.println("creating Subscriber");
			timer = new Timer();
			timerTask = (TimerTask) new SubscriberCreateTask();
			timer.schedule(timerTask, 1000L);

		}

		else if (GLSConfigurationManager.getInstance().dump == 3) {
			System.out.println("File Writting case");
			timer = new Timer();
			/* 91 */ timerTask = (TimerTask) new GLSTimerTask();
			/* 92 */ timer.schedule(timerTask, 1000L, 100L);
//				/*     */
			/* 94 */ Timer timerCounter = new Timer();
			/* 95 */ GLSCounterTimerTask gLSCounterTimerTask = new GLSCounterTimerTask();
			/* 96 */ timerCounter.schedule((TimerTask) gLSCounterTimerTask, 1000L, 1000L);
		} else if (GLSConfigurationManager.getInstance().dump == 4) {
			System.out.println("ORDER SUMBIT DIGITAL API");

			System.out.println("Starting main Unique Id Creation task ==" + (new Date()).toString());

			timer1 = new Timer();
			timerTask1 = (TimerTask) new GLSUniqueIDcreationTask();
			timer1.schedule(timerTask1, 1000L);

			Thread.sleep(60000);

			System.out.println("Size=" + SubscriptionUniqueIdStorage.hashSet.size());
//			for (String key : SubscriptionUniqueIdStorage.hashSet.keySet()) {
//				System.out.println(key);
//			}

			int size = SubscriptionUniqueIdStorage.hashSet.size();
			System.out.println("Size of List=" + size);

			for (int i = 0; i < 1000; i++) {
				SubscriptionUniqueIdStorage.list[i] = new ConcurrentLinkedQueue<String>();
			}

			/// convert hash map to queue
			int j = 0;
			for (String key : SubscriptionUniqueIdStorage.hashSet.keySet()) {

				SubscriptionUniqueIdStorage.list[j / 10000].add(key);
				j++;
				if (j >= size) {
					break;
				}
			}

			for (int i = 0; i < 1000; i++) {
				System.out.println("list size " + (i + 1) + "=" + SubscriptionUniqueIdStorage.list[i].size());
			}

			System.out.println("Starting main task ==" + (new Date()).toString());
			/// main task to create subscription
			timer = new Timer();
			timerTask = (TimerTask) new GLSTimerTaskSDRPDRSubscription();
			timer.schedule(timerTask, 1000L, 1000L);

			Timer timerCounter = new Timer();
			GLSCounterTimerTask gLSCounterTimerTask = new GLSCounterTimerTask();
			timerCounter.schedule((TimerTask) gLSCounterTimerTask, 1000L, 1000L);

		} else
			
			//for customer dump
			if (GLSConfigurationManager.getInstance().dump == 5) {
				timer = new Timer();
				timerTask = new GLSTimerTaskCustomerDumpSubscription();
				timer.schedule(timerTask, 1000L);
				
				Timer timerCounter = new Timer();
				GLSCounterTimerTask gLSCounterTimerTask = new GLSCounterTimerTask();
				timerCounter.schedule((TimerTask) gLSCounterTimerTask, 1000L, 1000L);

		}
		else if(GLSConfigurationManager.getInstance().dump == 5) {
			System.out.println("XML File Writting case");
			timer = new Timer();
			/* 91 */ timerTask = (TimerTask) new GLSTimerTaskXMLCreation();
			/* 92 */ timer.schedule(timerTask, 1000L);
//				/*     */
		}
		// reading from excel and making request
		else {
			SubscriberExcelCreation.readSubscriberExcel();
		}
		/*     */
///*  76 */     if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("unittest")) {
///*     */       
///*  78 */       GLSThread task = (GLSThread)PoolingManager.getPoolingManager().borrowObject(GLSThread.class);
///*     */       
///*  80 */       JSONObject headerJsonObj = new JSONObject((String)GLSCacheManager.getInstance().getPropertyMap().get("headerJson"));
///*     */       
///*  82 */       task.setParams(getInstance().jsonToMap(headerJsonObj));
///*     */       
///*  84 */       getInstance().getThreadPoolExecutor().execute((Runnable)task);
///*     */ 
///*     */     
///*     */     }
///*  88 */     else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
///*  89 */       .equalsIgnoreCase("loadtest")) {
///*  90 */       timer = new Timer();
///*  91 */       timerTask = (TimerTask)new GLSTimerTask();
///*  92 */       timer.schedule(timerTask, 1000L, 100L);
///*     */       
///*  94 */       Timer timerCounter = new Timer();
///*  95 */       GLSCounterTimerTask gLSCounterTimerTask = new GLSCounterTimerTask();
///*  96 */       timerCounter.schedule((TimerTask)gLSCounterTimerTask, 1000L, 1000L);
///*     */     } 
		/*     */
		/* 99 */ Runtime.getRuntime().addShutdownHook((Thread) new ServerShutdownHook(getInstance()));
		/*     */ }

	/*     */
	/*     */ private void initThreadPoolExecuter() {
		/* 103 */ this
				/*     */
				/* 105 */ .threadPoolExecutor = new GLSSimulatorThreadPoolExecutor(100, 200, 5L, TimeUnit.MILLISECONDS,
						new LinkedBlockingQueue());
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ private void initializeMbeans() {
		/*     */ try {
			/* 113 */ CommonStatistics.getInstance().startStatisticsMbeanService();
			/*     */ }
		/* 115 */ catch (Exception e) {
			/* 116 */ StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
			/*     */ }
		/*     */ }

	/*     */
	/*     */
	/*     */ public void loadConfiguration() throws JSONException, JsonProcessingException, IOException {
		/* 122 */ GLSConfigurationManager.getInstance().readConfiguration();
//		/* 123 */ GLSConfigurationManager.getInstance().readPropertyFile();
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public GLSSimulatorThreadPoolExecutor getThreadPoolExecutor() {
		/* 130 */ return this.threadPoolExecutor;
		/*     */ }

	/*     */
	/*     */ private void initilizeJettyRestEngine() {
		/* 134 */ this.jettyRestEngine = new JettyRestEngine();
		/* 135 */ this.jettyRestEngine.initialise();
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */ public void initializeNettyClientForRequest() {
		/*     */ try {
			/* 142 */ (new Thread((Runnable) new GLSNettyChannelInitThread("channel"))).start();
			/*     */ }
		/* 144 */ catch (Exception e) {
			/*     */
			/* 146 */ StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause()
					+ " GLSBootstrapper:initializeNettyClientForRequest");
			/*     */ }
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */ private void initializeNettyServer() {
		/* 153 */ (new GLSNettyServer()).start(GLSConfigurationManager.getInstance().getGlsIp(),
				/* 154 */ GLSConfigurationManager.getInstance().getGlsNettyPort(), false);
		/*     */ }

	/*     */
	/*     */ public JettyRestEngine getJettyRestEngine() {
		/* 158 */ return this.jettyRestEngine;
		/*     */ }

	/*     */
	/*     */ public Map<String, String> jsonToMap(JSONObject json) throws JSONException {
		/* 162 */ Map<String, String> retMap = new HashMap<>();
		/*     */
		/* 164 */ if (json != JSONObject.NULL) {
			/* 165 */ retMap = toMap(json);
			/*     */ }
		/* 167 */ return retMap;
		/*     */ }

	/*     */
	/*     */
	/*     */ public Map<String, String> toMap(JSONObject object) throws JSONException {
		/* 172 */ Map<String, String> map = new HashMap<>();
		/*     */
		/* 174 */ Iterator<String> keysItr = object.keys();
		/*     */
		/* 176 */ while (keysItr.hasNext()) {
			/* 177 */ String key = keysItr.next();
			/* 178 */ String value = object.getString(key);
			/*     */
			/* 180 */ map.put(key, value);
			/*     */ }
		/* 182 */ return map;
		/*     */ }

	public void initializeElasticSearchSessionFactory() {
		try {

			IndexConfig indexConfig = new IndexConfig();
			indexConfig.setIndexName("dev_subscriptionengine");
//		indexConfig.setType("ES_TypeName");
			indexConfig.setType("data");

			ElasticConfig elasticConfig = new ElasticConfig();
//		elasticConfig.setClusterName("es_7_5_1_load_cluster");
			elasticConfig.setClusterName("development_cluster");
			elasticConfig.setUserName("elastic");
			elasticConfig.setPassword("changeme");
//		elasticConfig.setHost("10.32.142.174:9202,10.32.142.172:9202,10.32.142.176:9202,10.32.142.175:9202");
//		elasticConfig.setHost("10.32.209.22:9202,10.32.209.23:9202,10.32.209.24:9202");

			elasticConfig.setHost("10.32.131.213:9200");

			SessionFactory factory = new SessionFactory.builder(indexConfig).withElasticConfig(elasticConfig)
					.buildSessionFactory();

			boolean isConnected = factory.ping();

			if (isConnected) {
//			InterfaceStatus.status.setEsConnected(true);
//			DappLoggerService.GENERAL_INFO_LOG.getLogBuilder(
//					"###################### Connection has been created with ES cluster ######################",
//					this.getClass().getName(), "initializeElasticSearchSessionFactory").writeLog();

			} else {

			}

		} catch (Exception e) {
			System.out.println("Exception in creation ES connection");
		}

	}
	/*     */ }

/*
 * Location: C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\
 * boostrapmanager\GLSBootstrapper.class Java compiler version: 8 (52.0) JD-Core
 * Version: 1.1.3
 */