/*    */ package com.rjil.gls.jetty;
/*    */ 
/*    */ import com.jio.telco.framework.resource.ResourceBuilder;
/*    */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import com.rjil.gls.resthandler.GLSEventReceiverHandler;
/*    */ import org.eclipse.jetty.server.Server;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JettyRestEngine
/*    */ {
/*    */   private Server jettyServer;
/*    */   private boolean started = false;
/*    */   
/*    */   public void initialise() {
/*    */     try {
/* 22 */       StackTrace.printToConsole("port :  " + GLSConfigurationManager.getInstance().getGlsPort());
/*    */       
/* 24 */       this
/*    */ 
/*    */ 
/*    */         
/* 28 */         .jettyServer = ResourceBuilder.jetty().setIP("localhost").setPort(5669).setMinThreadsForPool(8).setMaxThreadsForPool(8 * Runtime.getRuntime().availableProcessors()).addHandler(GLSConfigurationManager.getInstance().getMsHandler(), GLSEventReceiverHandler.class).start();
/*    */     }
/* 30 */     catch (Exception e) {
/* 31 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isStarted() {
/* 36 */     return this.started;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void stopJettyServer() {
/*    */     try {
/* 44 */       this.jettyServer.stop();
/* 45 */     } catch (Exception e) {
/* 46 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */   
/*    */   public String jettyStats() {
/* 51 */     StringBuilder str = new StringBuilder();
/* 52 */     str.append("---------------------------------------------------------------------------------------------- \njetty Server Running State                          : " + this.jettyServer
/* 53 */         .getState() + " \nJetty Server URI                                    : " + this.jettyServer
/* 54 */         .getURI() + " \nJetty Server Version                                : " + 
/* 55 */         Server.getVersion() + " \nJetty Server StopTimeout                            : " + this.jettyServer
/* 56 */         .getStopTimeout() + " \nMaximum Number of Threads Available in The Pool     : " + this.jettyServer
/* 57 */         .getThreadPool().getThreads() + " \nMaximum Number of IdleThreds Available in The Pool  : " + this.jettyServer
/*    */         
/* 59 */         .getThreadPool().getIdleThreads() + " \nIs ThreadPool Low On Threads                        : " + this.jettyServer
/*    */         
/* 61 */         .getThreadPool().isLowOnThreads() + " \n-----------------------------------------------------------------------------------------------");
/*    */ 
/*    */     
/* 64 */     return str.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\jetty\JettyRestEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */