/*    */ package com.rjil.gls.netty.client;
/*    */ 
/*    */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import io.netty.bootstrap.Bootstrap;
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelOption;
/*    */ import io.netty.channel.EventLoopGroup;
/*    */ import io.netty.channel.WriteBufferWaterMark;
/*    */ import io.netty.channel.nio.NioEventLoopGroup;
/*    */ import io.netty.channel.socket.nio.NioSocketChannel;
/*    */ import io.netty.handler.ssl.SslContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSNettyHttp2Client
/*    */ {
/* 23 */   private static final GLSNettyHttp2Client dAppNettyHttp2Client = new GLSNettyHttp2Client();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static GLSNettyHttp2Client getInstance() {
/* 31 */     return dAppNettyHttp2Client;
/*    */   }
/*    */ 
/*    */   
/*    */   public Channel initializeNettyClient(String nodeName) {
/*    */     try {
/* 37 */       if (GLSCacheManager.getInstance().getChannelMap().get(nodeName) != null) {
/* 38 */         return (Channel)GLSCacheManager.getInstance().getChannelMap().get(nodeName);
/*    */       }
/* 40 */       NioEventLoopGroup nioEventLoopGroup = new NioEventLoopGroup();
/*    */       
/* 42 */       SslContext sslCtx = null;
/* 43 */       Bootstrap b = new Bootstrap();
/*    */       
/* 45 */       String ip = (String)GLSCacheManager.getInstance().getPropertyMap().get("ip");
/* 46 */       String port = (String)GLSCacheManager.getInstance().getPropertyMap().get("port");
/*    */       
/* 48 */       b.group((EventLoopGroup)nioEventLoopGroup);
/* 49 */       b.option(ChannelOption.SO_SNDBUF, Integer.valueOf(5242880));
/* 50 */       b.option(ChannelOption.SO_RCVBUF, Integer.valueOf(5242880));
/* 51 */       b.option(ChannelOption.WRITE_BUFFER_WATER_MARK, new WriteBufferWaterMark(5242880, 5242880));
/* 52 */       b.channel(NioSocketChannel.class);
/* 53 */       b.option(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(true));
/* 54 */       b.remoteAddress(ip, Integer.parseInt(port));
/* 55 */       b.handler((ChannelHandler)new Http2ClientFrameInitializerRequest(sslCtx));
/*    */ 
/*    */       
/* 58 */       Channel channel = b.connect().syncUninterruptibly().channel();
/*    */       
/* 60 */       if (channel != null) {
/*    */         
/* 62 */         StackTrace.printToConsole("Connected to [" + ip + ':' + port + ']' + " for channel : " + channel);
/*    */         
/* 64 */         GLSCacheManager.getInstance().getChannelMap().put(nodeName, channel);
/*    */       } 
/* 66 */       return channel;
/*    */     }
/* 68 */     catch (Exception e) {
/* 69 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause() + " GLSNettyHttp2Client:initializeNettyClient");
/* 70 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\client\GLSNettyHttp2Client.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */