/*    */ package com.rjil.gls.netty.client;
/*    */ 
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelInitializer;
/*    */ import io.netty.channel.SimpleChannelInboundHandler;
/*    */ import io.netty.handler.codec.http2.Http2FrameCodec;
/*    */ import io.netty.handler.codec.http2.Http2FrameCodecBuilder;
/*    */ import io.netty.handler.codec.http2.Http2MultiplexHandler;
/*    */ import io.netty.handler.codec.http2.Http2Settings;
/*    */ import io.netty.handler.ssl.SslContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Http2ClientFrameInitializerRequest
/*    */   extends ChannelInitializer<Channel>
/*    */ {
/*    */   private final SslContext sslCtx;
/*    */   
/*    */   public Http2ClientFrameInitializerRequest(SslContext sslCtx) {
/* 23 */     this.sslCtx = sslCtx;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void initChannel(Channel ch) throws Exception {
/* 30 */     if (this.sslCtx != null) {
/* 31 */       ch.pipeline().addFirst(new ChannelHandler[] { (ChannelHandler)this.sslCtx.newHandler(ch.alloc()) });
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 38 */     Http2FrameCodec http2FrameCodec = Http2FrameCodecBuilder.forClient().initialSettings(Http2Settings.defaultSettings().maxFrameSize(5242880).initialWindowSize(5242880)).build();
/*    */     
/* 40 */     ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)http2FrameCodec });
/*    */     
/* 42 */     ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new Http2MultiplexHandler((ChannelHandler)new SimpleChannelInboundHandler<Object>() {
/*    */               protected void channelRead0(ChannelHandlerContext arg0, Object arg1) throws Exception {}
/*    */             }) });
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\client\Http2ClientFrameInitializerRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */