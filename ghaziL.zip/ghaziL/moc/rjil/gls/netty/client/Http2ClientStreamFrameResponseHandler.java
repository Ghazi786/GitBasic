/*     */ package com.rjil.gls.netty.client;
/*     */ 
/*     */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import com.rjil.gls.countermanager.GLSCounterManager;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.SimpleChannelInboundHandler;
/*     */ import io.netty.handler.codec.http2.Http2DataFrame;
/*     */ import io.netty.handler.codec.http2.Http2HeadersFrame;
/*     */ import io.netty.handler.codec.http2.Http2StreamFrame;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2ClientStreamFrameResponseHandler
/*     */   extends SimpleChannelInboundHandler<Http2StreamFrame>
/*     */ {
/*  28 */   private final CountDownLatch latch = new CountDownLatch(1);
/*  29 */   private Map<String, Map<String, String>> headerMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void channelRead0(ChannelHandlerContext ctx, Http2StreamFrame msg) throws Exception {
/*  35 */     if (msg instanceof Http2DataFrame && ((Http2DataFrame)msg).isEndStream()) {
/*  36 */       this.latch.countDown();
/*     */       
/*  38 */       if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("loadtest")) {
/*  39 */         GLSCounterManager.getInstance().getReceivedCount().incrementAndGet();
/*  40 */       } else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("unittest")) {
/*  41 */         onDataRead(ctx, (Http2DataFrame)msg);
/*     */       }
/*     */     
/*     */     }
/*  45 */     else if (msg instanceof Http2HeadersFrame) {
/*  46 */       onHeadersRead(ctx, (Http2HeadersFrame)msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onDataRead(ChannelHandlerContext ctx, Http2DataFrame data) {
/*     */     try {
/*  56 */       StackTrace.printToConsole("Status Code received : " + (String)((Map)this.headerMap
/*  57 */           .get(data.stream().id() + ctx.channel().id().asLongText())).get(":status") + " with response body : " + data
/*  58 */           .content().toString(CharsetUtil.UTF_8));
/*     */     }
/*  60 */     catch (Exception e) {
/*  61 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onHeadersRead(ChannelHandlerContext ctx, Http2HeadersFrame headerFrame) {
/*     */     try {
/*  77 */       Map<String, String> headers = new HashMap<>();
/*     */       
///*  79 */  ghazi      headerFrame.headers().forEach(k -> (String)headers.put(((CharSequence)k.getKey()).toString(), ((CharSequence)k.getValue()).toString()));
/*     */       
/*  81 */       this.headerMap.put(headerFrame.stream().id() + ctx.channel().id().asLongText(), headers);
/*     */     }
/*  83 */     catch (Exception e) {
/*  84 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean responseSuccessfullyCompleted() {
/*     */     try {
/*  96 */       return this.latch.await(5L, TimeUnit.SECONDS);
/*     */     
/*     */     }
/*  99 */     catch (Exception ie) {
/* 100 */       StackTrace.printToConsole("Latch exception: " + ie.getMessage());
/*     */       
/* 102 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\client\Http2ClientStreamFrameResponseHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */