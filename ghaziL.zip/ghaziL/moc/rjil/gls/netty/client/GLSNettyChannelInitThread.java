/*    */ package com.rjil.gls.netty.client;
/*    */ 
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import io.netty.channel.Channel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSNettyChannelInitThread
/*    */   implements Runnable
/*    */ {
/*    */   String nodeName;
/*    */   
/*    */   public GLSNettyChannelInitThread(String nodeName) {
/* 19 */     this.nodeName = nodeName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 25 */     int retryCount = 3;
/*    */     
/*    */     try {
/* 28 */       Channel channel1 = GLSNettyHttp2Client.getInstance().initializeNettyClient(this.nodeName + "1");
/*    */       
/* 30 */       while (channel1 == null && retryCount-- > 0) {
/*    */ 
/*    */         
/* 33 */         Thread.sleep(20000L);
/*    */         
/* 35 */         channel1 = GLSNettyHttp2Client.getInstance().initializeNettyClient(this.nodeName + "1");
/*    */       } 
/*    */ 
/*    */       
/* 39 */       if (channel1 == null) {
/*    */         return;
/*    */       }
/* 42 */       retryCount = 3;
/*    */       
/* 44 */       Channel channel2 = GLSNettyHttp2Client.getInstance().initializeNettyClient(this.nodeName + "2");
/*    */       
/* 46 */       while (channel2 == null && retryCount-- > 0)
/*    */       {
/*    */         
/* 49 */         Thread.sleep(20000L);
/*    */         
/* 51 */         channel2 = GLSNettyHttp2Client.getInstance().initializeNettyClient(this.nodeName + "2");
/*    */       }
/*    */     
/* 54 */     } catch (Exception e) {
/* 55 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause() + " GLSNettyChannelInitThread:run");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\client\GLSNettyChannelInitThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */