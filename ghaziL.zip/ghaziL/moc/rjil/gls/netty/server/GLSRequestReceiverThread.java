/*    */ package com.rjil.gls.netty.server;
/*    */ 
/*    */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import com.rjil.gls.countermanager.GLSCounterManager;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http.HttpResponseStatus;
/*    */ import io.netty.handler.codec.http2.DefaultHttp2Headers;
/*    */ import io.netty.handler.codec.http2.DefaultHttp2HeadersFrame;
/*    */ import io.netty.handler.codec.http2.Http2Headers;
/*    */ import io.netty.util.CharsetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSRequestReceiverThread
/*    */   implements Runnable
/*    */ {
/*    */   private ChannelHandlerContext ctx;
/*    */   private ByteBuf payload;
/*    */   
/*    */   public GLSRequestReceiverThread(ChannelHandlerContext ctx, ByteBuf payload) {
/* 29 */     this.ctx = ctx;
/* 30 */     this.payload = payload;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     try {
/* 37 */       if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("unittest")) {
/*    */         
/* 39 */         StackTrace.printToConsole("Received request/requestAck: " + this.payload.toString(CharsetUtil.UTF_8));
/*    */       }
/* 41 */       else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("loadtest")) {
/* 42 */         GLSCounterManager.getInstance().getHttp2ServerCount().incrementAndGet();
/*    */       } 
/* 44 */       Http2Headers headers = (new DefaultHttp2Headers()).status((CharSequence)HttpResponseStatus.ACCEPTED.codeAsText());
/* 45 */       this.ctx.writeAndFlush(new DefaultHttp2HeadersFrame(headers));
/*    */     }
/* 47 */     catch (Exception e) {
/* 48 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\server\GLSRequestReceiverThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */