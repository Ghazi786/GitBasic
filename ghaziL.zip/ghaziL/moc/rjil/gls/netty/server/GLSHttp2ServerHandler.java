/*    */ package com.rjil.gls.netty.server;
/*    */ 
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import io.netty.channel.ChannelDuplexHandler;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http2.Http2DataFrame;
/*    */ import io.netty.handler.codec.http2.Http2Headers;
/*    */ import io.netty.handler.codec.http2.Http2HeadersFrame;
/*    */ import io.netty.util.CharsetUtil;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ public class GLSHttp2ServerHandler
/*    */   extends ChannelDuplexHandler
/*    */ {
/* 24 */   private Map<String, Http2Headers> streamId = new ConcurrentHashMap<>();
/* 25 */   private Map<String, StringBuilder> reqMap = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 33 */     super.exceptionCaught(ctx, cause);
/*    */     
/* 35 */     StackTrace.printToConsole("Exception occured : " + cause.getMessage() + "/n" + cause.toString());
/* 36 */     ctx.close();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 42 */     if (msg instanceof Http2HeadersFrame) {
/* 43 */       onHeadersRead(ctx, (Http2HeadersFrame)msg);
/* 44 */     } else if (msg instanceof Http2DataFrame) {
/*    */       
/* 46 */       onDataRead(ctx, (Http2DataFrame)msg);
/*    */     } else {
/*    */       
/* 49 */       super.channelRead(ctx, msg);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 56 */     ctx.flush();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void onDataRead(ChannelHandlerContext ctx, Http2DataFrame data) {
/* 64 */     String d = data.stream().id() + ctx.channel().id().asShortText();
/*    */     
/* 66 */     this.reqMap.putIfAbsent(d, new StringBuilder());
/* 67 */     ((StringBuilder)this.reqMap.get(d)).append(data.content().toString(CharsetUtil.UTF_8));
/*    */     
/* 69 */     if (data.isEndStream()) {
/*    */       
/* 71 */       StackTrace.printToConsole("String Builder received : " + ((StringBuilder)this.reqMap.get(d)).toString());
/* 72 */       if (data.isEndStream()) {
/*    */         
/* 74 */         (new Thread(new GLSRequestReceiverThread(ctx, Unpooled.wrappedBuffer(((StringBuilder)this.reqMap.get(d)).toString().getBytes())))).start();
/*    */         
/* 76 */         this.reqMap.remove(this.streamId + ctx.channel().id().asLongText());
/* 77 */         this.streamId.remove(this.streamId + ctx.channel().id().asLongText());
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void onHeadersRead(ChannelHandlerContext ctx, Http2HeadersFrame headers) {
/* 88 */     this.streamId.put(headers.stream().id() + ctx.channel().id().asLongText(), headers.headers());
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\server\GLSHttp2ServerHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */