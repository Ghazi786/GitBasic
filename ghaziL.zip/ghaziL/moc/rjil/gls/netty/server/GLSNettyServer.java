/*    */ package com.rjil.gls.netty.server;
/*    */ 
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import io.netty.bootstrap.ServerBootstrap;
/*    */ import io.netty.channel.ChannelFuture;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelOption;
/*    */ import io.netty.channel.EventLoopGroup;
/*    */ import io.netty.channel.WriteBufferWaterMark;
/*    */ import io.netty.channel.nio.NioEventLoopGroup;
/*    */ import io.netty.channel.socket.nio.NioServerSocketChannel;
/*    */ import io.netty.handler.codec.http2.Http2SecurityUtil;
/*    */ import io.netty.handler.logging.LogLevel;
/*    */ import io.netty.handler.logging.LoggingHandler;
/*    */ import io.netty.handler.ssl.ApplicationProtocolConfig;
/*    */ import io.netty.handler.ssl.CipherSuiteFilter;
/*    */ import io.netty.handler.ssl.OpenSsl;
/*    */ import io.netty.handler.ssl.SslContext;
/*    */ import io.netty.handler.ssl.SslContextBuilder;
/*    */ import io.netty.handler.ssl.SslProvider;
/*    */ import io.netty.handler.ssl.SupportedCipherSuiteFilter;
/*    */ import io.netty.handler.ssl.util.SelfSignedCertificate;
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSNettyServer
/*    */ {
/*    */   public void start(String serverIp, int port, boolean ssl) {
/*    */     try {
/*    */       SslContext sslCtx;
/* 42 */       if (ssl) {
/* 43 */         SslProvider provider = OpenSsl.isAlpnSupported() ? SslProvider.OPENSSL : SslProvider.JDK;
/*    */         
/* 45 */         SelfSignedCertificate ssc = new SelfSignedCertificate();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 62 */         sslCtx = SslContextBuilder.forServer(ssc.certificate(), ssc.privateKey()).sslProvider(provider).ciphers(Http2SecurityUtil.CIPHERS, (CipherSuiteFilter)SupportedCipherSuiteFilter.INSTANCE).applicationProtocolConfig(new ApplicationProtocolConfig(ApplicationProtocolConfig.Protocol.ALPN, ApplicationProtocolConfig.SelectorFailureBehavior.NO_ADVERTISE, ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT, new String[] { "h2", "http/1.1" })).build();
/*    */       } else {
/* 64 */         sslCtx = null;
/*    */       } 
/*    */       
/* 67 */       NioEventLoopGroup nioEventLoopGroup1 = new NioEventLoopGroup();
/* 68 */       NioEventLoopGroup nioEventLoopGroup2 = new NioEventLoopGroup();
/*    */       
/* 70 */       ServerBootstrap b = new ServerBootstrap();
/*    */       
/* 72 */       ((ServerBootstrap)((ServerBootstrap)((ServerBootstrap)((ServerBootstrap)((ServerBootstrap)((ServerBootstrap)b.group((EventLoopGroup)nioEventLoopGroup1, (EventLoopGroup)nioEventLoopGroup2).option(ChannelOption.SO_BACKLOG, Integer.valueOf(4096)))
/* 73 */         .option(ChannelOption.SO_SNDBUF, Integer.valueOf(5242880))).option(ChannelOption.SO_RCVBUF, Integer.valueOf(5242880)))
/* 74 */         .option(ChannelOption.WRITE_BUFFER_WATER_MARK, new WriteBufferWaterMark(5242880, 5242880)))
/* 75 */         .channel(NioServerSocketChannel.class)).handler((ChannelHandler)new LoggingHandler(LogLevel.ERROR)))
/* 76 */         .childHandler((ChannelHandler)new GLSHttp2ServerInitializer(sslCtx));
/*    */       
/* 78 */       ChannelFuture ch = b.bind(new InetSocketAddress(serverIp, port)).sync();
/*    */       
/* 80 */       StackTrace.printToConsole("Started and listening on : " + ch.channel().localAddress());
/*    */     }
/* 82 */     catch (Exception e) {
/* 83 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\server\GLSNettyServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */