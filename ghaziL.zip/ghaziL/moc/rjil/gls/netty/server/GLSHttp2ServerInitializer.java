/*    */ package com.rjil.gls.netty.server;
/*    */ 
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelInitializer;
/*    */ import io.netty.channel.socket.SocketChannel;
/*    */ import io.netty.handler.codec.http2.Http2FrameCodecBuilder;
/*    */ import io.netty.handler.codec.http2.Http2MultiplexHandler;
/*    */ import io.netty.handler.codec.http2.Http2Settings;
/*    */ import io.netty.handler.ssl.SslContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSHttp2ServerInitializer
/*    */   extends ChannelInitializer<SocketChannel>
/*    */ {
/*    */   private final SslContext sslCtx;
/*    */   
/*    */   public GLSHttp2ServerInitializer(SslContext sslCtx) {
/* 28 */     this.sslCtx = sslCtx;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initChannel(SocketChannel ch) {
/* 34 */     if (this.sslCtx != null) {
/* 35 */       configureSsl(ch);
/*    */     }
/*    */     else {
/*    */       
/* 39 */       configureClearText(ch);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void configureSsl(SocketChannel ch) {
/* 47 */     ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)this.sslCtx.newHandler(ch.alloc()), (ChannelHandler)new GLSNettyHttpsHandler() });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void configureClearText(SocketChannel ch) {
/*    */     try {
			
///* 59 */  ghazi     Http2FrameCodecBuilder frameCodecBuilder = Http2FrameCodecBuilder.forServer().initialSettings(Http2Settings.defaultSettings().maxFrameSize(5242880).initialWindowSize(5242880)).autoAckPingFrame(true);
/*    */       
///* 61 */   ghazi    ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)frameCodecBuilder.build(), (ChannelHandler)new Http2MultiplexHandler((ChannelHandler)new GLSHttp2ServerHandler()) });
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 66 */     catch (Exception e) {
/* 67 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\server\GLSHttp2ServerInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */