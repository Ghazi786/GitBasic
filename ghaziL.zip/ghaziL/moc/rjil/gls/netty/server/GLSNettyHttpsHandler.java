/*    */ package com.rjil.gls.netty.server;
/*    */ 
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http2.Http2FrameCodecBuilder;
/*    */ import io.netty.handler.codec.http2.Http2MultiplexHandler;
/*    */ import io.netty.handler.ssl.ApplicationProtocolNegotiationHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSNettyHttpsHandler
/*    */   extends ApplicationProtocolNegotiationHandler
/*    */ {
/*    */   protected GLSNettyHttpsHandler() {
/* 19 */     super("h2");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void configurePipeline(ChannelHandlerContext ctx, String protocol) throws Exception {
/* 25 */     if ("h2".equals(protocol)) {
/* 26 */       ctx.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)Http2FrameCodecBuilder.forServer().build() });
/* 27 */       ctx.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new Http2MultiplexHandler((ChannelHandler)new GLSHttp2ServerHandler()) });
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 32 */     throw new IllegalStateException("Unknown protocol: " + protocol);
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\netty\server\GLSNettyHttpsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */