/*    */ package com.rjil.gls.cachemanager;
/*    */ 
/*    */ import io.netty.channel.Channel;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSCacheManager
/*    */ {
/* 14 */   private static final GLSCacheManager ltCacheManagerInstance = new GLSCacheManager();
/*    */   
/* 16 */   private int processors = Runtime.getRuntime().availableProcessors();
/*    */   
/*    */   private Map<String, String> headerMap;
/*    */   
/*    */   private Map<String, String> propertyMap;
/*    */   private Map<String, Channel> channelMap;
/*    */   
/*    */   public static GLSCacheManager getInstance() {
/* 24 */     return ltCacheManagerInstance;
/*    */   }
/*    */   private GLSCacheManager() {
/* 27 */     this.headerMap = new ConcurrentHashMap<>(64, 0.75F, this.processors);
/*    */     
/* 29 */     this.propertyMap = new ConcurrentHashMap<>(64, 0.75F, this.processors);
/*    */     
/* 31 */     this.channelMap = new ConcurrentHashMap<>(64, 0.75F, this.processors);
/*    */   }
/*    */   public Map<String, String> getHeaderMap() {
/* 34 */     return this.headerMap;
/*    */   }
/*    */   
/*    */   public Map<String, String> getPropertyMap() {
/* 38 */     return this.propertyMap;
/*    */   }
/*    */   
/*    */   public Map<String, Channel> getChannelMap() {
/* 42 */     return this.channelMap;
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\cachemanager\GLSCacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */