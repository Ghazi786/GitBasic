/*    */ package com.rjil.gls.timertask;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PoolingManager;
/*    */ import com.rjil.gls.boostrapmanager.GLSBootstrapper;
/*    */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*    */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import com.rjil.gls.countermanager.GLSCounterManager;
import com.rjil.gls.threadpool.GLSSDRPDRSubscriptionThread;
/*    */ import com.rjil.gls.threadpool.GLSThread;
import com.rjil.gls.threadpool.GLSThreadFile;
import com.rjil.gls.threadpool.GLSXMLCreationThread;

/*    */ import java.util.TimerTask;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSTimerTaskXMLCreation
/*    */   extends TimerTask
/*    */ {
/*    */   public void run() {
/*    */     try {
/* 26 */       for (int i = 0; i < 1; i++) {
/*    */ 
/*    */ 
/*    */         
/* 30 */         GLSXMLCreationThread task = (GLSXMLCreationThread)PoolingManager.getPoolingManager().borrowObject(GLSXMLCreationThread.class);
/* 32 */        
/*    */         
/* 38 */         GLSBootstrapper.getInstance().getThreadPoolExecutor().execute((Runnable)task);
/*    */         
/* 40 */      
/* 40 */         
/*    */       } 
/* 42 */     } catch (Exception e) {
/*    */       
/* 44 */       StackTrace.printToConsole("Exception occureds : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\timertask\GLSTimerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */