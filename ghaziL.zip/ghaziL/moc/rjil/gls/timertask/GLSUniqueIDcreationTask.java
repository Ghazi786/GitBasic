package com.rjil.gls.timertask;

import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.jio.subscrition.testing.SubscriptionUniqueIdStorage;
import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.gls.boostrapmanager.GLSBootstrapper;
import com.rjil.gls.threadpool.GLSUniqueIDcreationThread;

public class GLSUniqueIDcreationTask extends TimerTask {

	@Override
	public void run() {

		
		try {
			for (int i = 0; i < 1000; i++) {

				GLSUniqueIDcreationThread task = (GLSUniqueIDcreationThread) PoolingManager.getPoolingManager()
						.borrowObject(GLSUniqueIDcreationThread.class);
				GLSBootstrapper.getInstance().getThreadPoolExecutor().execute((Runnable) task);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
