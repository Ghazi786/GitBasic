package com.rjil.gls.timertask;

import java.util.TimerTask;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

import org.json.JSONObject;

import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.gls.boostrapmanager.GLSBootstrapper;
import com.rjil.gls.cachemanager.GLSCacheManager;
import com.rjil.gls.configurationmanager.GLSConfigurationManager;
import com.rjil.gls.constants.StackTrace;
import com.rjil.gls.countermanager.GLSCounterManager;
import com.rjil.gls.threadpool.GLSCustomerDumpThread;

public class GLSTimerTaskCustomerDumpSubscription extends TimerTask {
	// private static final int MAX_CONCURRENT_THREADS =
	// Runtime.getRuntime().availableProcessors() * 2;
	

	// private static final Semaphore semaphore = new
	// Semaphore(MAX_CONCURRENT_THREADS);
	@Override
	public void run() {
		try {
			for (int i = 0; i < GLSConfigurationManager.getInstance().getThreadCount(); i++) {

				// semaphore.acquire();

				GLSCustomerDumpThread task = (GLSCustomerDumpThread) PoolingManager.getPoolingManager()
						.borrowObject(GLSCustomerDumpThread.class);
				JSONObject headerJsonObj = new JSONObject(
						(String) GLSCacheManager.getInstance().getPropertyMap().get("headerJson"));
				task.setParams(GLSBootstrapper.getInstance().jsonToMap(headerJsonObj));
				task.setStartingIndex(i*1000);
				GLSCounterManager.getInstance().getAfterPoolCount().incrementAndGet();
				GLSBootstrapper.getInstance().getThreadPoolExecutor().execute((Runnable) task);
				GLSCounterManager.getInstance().getAfterScheduleCount().incrementAndGet();

			}
		} catch (Exception e) {
			StackTrace.printToConsole("Exception occureds : " + e.getMessage() + "/n" + e.getCause());
		} finally {
			// semaphore.release();
		}

	}

}
