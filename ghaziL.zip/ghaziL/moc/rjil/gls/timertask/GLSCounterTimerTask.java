/*    */ package com.rjil.gls.timertask;
/*    */ 
/*    */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import com.rjil.gls.countermanager.GLSCounterManager;
/*    */ import java.util.TimerTask;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSCounterTimerTask
/*    */   extends TimerTask
/*    */ {
/* 15 */   private static GLSCounterManager count = GLSCounterManager.getInstance();
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
///* 20 */     if (GLSConfigurationManager.getInstance().getInterfaceName().equalsIgnoreCase("http2")) {
///*    */       
///* 22 */       StackTrace.printToConsole("Time:  " + count.getTime().incrementAndGet() + "  SendCount:  " + count
///* 23 */           .getSendCount() + "  ReceivedCount:  " + count.getReceivedCount() + "  FailCount:  " + count
///* 24 */           .getFailureCount() + "  ServerCount:  " + count.getHttp2ServerCount() + "  SyncTPS:  " + (count
///* 25 */           .getReceivedCount().get() / count.getTime().get()) + "  ServerTPS:  " + (count
///* 26 */           .getHttp2ServerCount().get() / count.getTime().get()));
///*    */     } else {
/*    */       
/* 29 */       StackTrace.printToConsole("Time:  " + count.getTime().incrementAndGet() + "  SendCount:  " + count
/* 30 */           .getSendCount() + "  ReceivedCount:  " + count.getReceivedCount() + "  FailCount:  " + count
/* 31 */           .getFailureCount() + "  ServerCount:  " + count.getHttpServerCount() + "  SyncTPS:  " + (count
/* 32 */           .getReceivedCount().get() / count.getTime().get()) + "  ServerTPS:  " + (count
/* 33 */           .getHttpServerCount().get() / count.getTime().get()));
///*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\timertask\GLSCounterTimerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */