/*    */ package com.rjil.gls.timertask;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PoolingManager;
/*    */ import com.rjil.gls.boostrapmanager.GLSBootstrapper;
/*    */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*    */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import com.rjil.gls.countermanager.GLSCounterManager;
import com.rjil.gls.threadpool.GLSSDRPDRSubscriptionThread;
/*    */ import com.rjil.gls.threadpool.GLSThread;
import com.rjil.gls.threadpool.GLSThreadFile;

/*    */ import java.util.TimerTask;
/*    */ import org.json.JSONObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSTimerTaskSDRPDRSubscription
/*    */   extends TimerTask
/*    */ {
/*    */   public void run() {
/*    */     try {
/* 26 */       for (int i = 0; i < GLSConfigurationManager.getInstance().getThreadCount(); i++) {
/*    */ 
/*    */ 
/*    */         
/* 30 */         GLSSDRPDRSubscriptionThread task = (GLSSDRPDRSubscriptionThread)PoolingManager.getPoolingManager().borrowObject(GLSSDRPDRSubscriptionThread.class);
/* 32 */         JSONObject headerJsonObj = new JSONObject((String)GLSCacheManager.getInstance().getPropertyMap().get("headerJson"));
/*    */         
/* 34 */         task.setParams(GLSBootstrapper.getInstance().jsonToMap(headerJsonObj));
/*    */         
/* 36 */         GLSCounterManager.getInstance().getAfterPoolCount().incrementAndGet();
/*    */         
/* 38 */         GLSBootstrapper.getInstance().getThreadPoolExecutor().execute((Runnable)task);
/*    */         
/* 40 */         GLSCounterManager.getInstance().getAfterScheduleCount().incrementAndGet();
/* 40 */         
/*    */       } 
/* 42 */     } catch (Exception e) {
/*    */       
/* 44 */       StackTrace.printToConsole("Exception occureds : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\timertask\GLSTimerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */