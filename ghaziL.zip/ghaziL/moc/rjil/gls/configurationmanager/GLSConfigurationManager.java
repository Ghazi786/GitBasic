/*     */
package com.rjil.gls.configurationmanager;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/*     */
/*     */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import java.io.FileReader;
import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;

/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */ public class GLSConfigurationManager
/*     */ {
	/* 21 */ private static final GLSConfigurationManager gLSConfigurationManager = new GLSConfigurationManager();
	/*     */
	/*     */ private Properties properties;
	/*     */
	/*     */ private String headerJson;
	/*     */
	/*     */ private JSONObject headerJsonObj;
	/* 28 */ private int threadCount = 0;
	/* 29 */ private int rateLimit = 0;
	/* 30 */ private int corePoolSize = 0;
	/* 31 */ private int maximumPoolSize = 0;
	/* 32 */ private String glsIp = null;
	/* 33 */ private int glsPort = 0;
	/* 34 */ private int glsNettyPort = 0;
	/* 35 */ private String nodeId = null;
	/* 36 */ private String msHandler = null;
	/* 37 */ private String eventName = null;
	/* 38 */ private String interfaceName = null;
	/* 39 */ private String loadtestOrUnitTest = null;
	public int dump = 0;
	public int maxqueuesize = 0;

	public int getMaxqueuesize() {
		return maxqueuesize;
	}

	public void setMaxqueuesize(int maxqueuesize) {
		this.maxqueuesize = maxqueuesize;
	}

	/*     */
	/*     */ public String getMsHandler() {
		/* 42 */ return this.msHandler;
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public static GLSConfigurationManager getInstance() {
		/* 51 */ return gLSConfigurationManager;
		/*     */ }

	/*     */
	/*     */
	/*     */ public void readConfiguration() {

		String profile = System.getProperty("profile");
		String path;
		if (profile != null && profile.equals("dev")) {
			path = "./configuration/ClientProperty.properties";
		} else {
			path = "../configuration/ClientProperty.properties";
		}
		/* 56 */ try (FileReader fileReader = new FileReader(path)) {
			/* 57 */ this.properties = new Properties();
			/* 58 */ this.properties.load(fileReader);
			/*     */
			/* 60 */ this.glsIp = this.properties.getProperty("ip");
			/* 61 */ this.glsPort = Integer.parseInt(this.properties.getProperty("port"));

			/* 62 */ this.glsNettyPort = Integer.parseInt(this.properties.getProperty("nettyport"));
			/* 63 */ setThreadCount(Integer.parseInt(this.properties.getProperty("threadCount")));
			/* 64 */ setRateLimit(Integer.parseInt(this.properties.getProperty("rateLimit")));
			/* 65 */ this.corePoolSize = Integer.parseInt(this.properties.getProperty("corePoolSize"));
			/* 66 */ this.maximumPoolSize = Integer.parseInt(this.properties.getProperty("maximumPoolSize"));
			/* 67 */ this.interfaceName = this.properties.getProperty("interfaceName");
			/* 68 */ this.msHandler = this.properties.getProperty("msHandler");
			/* 69 */ this.eventName = this.properties.getProperty("eventNameToReceiveAck");
			/* 70 */ this.loadtestOrUnitTest = this.properties.getProperty("loadtestOrUnitTest");
			this.dump = Integer.parseInt(this.properties.getProperty("dump"));
			this.maxqueuesize = Integer.parseInt(this.properties.getProperty("maxqueuesize"));
			/*     */
			String path2;
			if (profile != null && profile.equals("dev")) {
				path2 = "./configuration/ApiProperty.txt";
			} else {
				path2 = "../configuration/ApiProperty.txt";
			}
			/* 72 */ try (FileReader fileReader1 = new FileReader(path2)) {
				/* 73 */ this.properties.load(fileReader1);
				/*     */ }
			/*     */
			/* 76 */ } catch (Exception e) {
			/* 77 */ StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
			/*     */ }
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public String getGlsIp() {
		/* 85 */ return this.glsIp;
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public int getGlsPort() {
		/* 92 */ return this.glsPort;
		/*     */ }

	/*     */
	/*     */
	/*     */ public void readPropertyFile() throws JSONException, JsonProcessingException, IOException {
		/* 97 */ Map<String, String> propertyMap = GLSCacheManager.getInstance().getPropertyMap();
		/*     */
		/* 99 */ propertyMap.put("ip", this.properties.getProperty("ip"));
		/* 100 */ propertyMap.put("port", this.properties.getProperty("port"));
		/* 101 */ propertyMap.put("context", this.properties.getProperty("context"));
		/* 102 */// propertyMap.put("requestJson", this.properties.getProperty("requestJson"));
		String property = this.properties.getProperty("requestJson");
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode readTree = objectMapper.readTree(property);
		JsonNode deepCopy = readTree.deepCopy();
		propertyMap.put("requestJson", objectMapper.writeValueAsString(deepCopy));

		/* 103 */ propertyMap.put("headerJson", this.properties.getProperty("headerJson"));
		/* 104 */ propertyMap.put("httpMethod", this.properties.getProperty("httpMethod"));
		/*     */
		/* 106 */ this.headerJson = (String) GLSCacheManager.getInstance().getPropertyMap().get("headerJson");
		/*     */ }

	/*     */
	/*     */
	/*     */ public int getThreadCount() {
		/* 111 */ return this.threadCount;
		/*     */ }

	/*     */
	/*     */ public int getRateLimit() {
		/* 115 */ return this.rateLimit;
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public int getCorePoolSize() {
		/* 122 */ return this.corePoolSize;
		/*     */ }

	/*     */
	/*     */
	/*     */
	/*     */
	/*     */ public int getMaximumPoolSize() {
		/* 129 */ return this.maximumPoolSize;
		/*     */ }

	/*     */
	/*     */ public JSONObject getHeaderJsonObj() {
		/* 133 */ return this.headerJsonObj;
		/*     */ }

	/*     */
	/*     */ public String getHeaderJson() {
		/* 137 */ return this.headerJson;
		/*     */ }

	/*     */
	/*     */ public String getNodeId() {
		/* 141 */ return this.nodeId;
		/*     */ }

	/*     */
	/*     */ public void setNodeId(String nodeId) {
		/* 145 */ this.nodeId = nodeId;
		/*     */ }

	/*     */
	/*     */ public String getInterfaceName() {
		/* 149 */ return this.interfaceName;
		/*     */ }

	/*     */
	/*     */ public String getEventName() {
		/* 153 */ return this.eventName;
		/*     */ }

	/*     */
	/*     */ public int getGlsNettyPort() {
		/* 157 */ return this.glsNettyPort;
		/*     */ }

	/*     */
	/*     */ public String getLoadtestOrUnitTest() {
		/* 161 */ return this.loadtestOrUnitTest;
		/*     */ }

	/*     */
	/*     */ public void setThreadCount(int threadCount) {
		/* 165 */ this.threadCount = threadCount;
		/*     */ }

	/*     */
	/*     */ public void setRateLimit(int rateLimit) {
		/* 169 */ this.rateLimit = rateLimit;
		/*     */ }
	/*     */ }

/*
 * Location: C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\
 * configurationmanager\GLSConfigurationManager.class Java compiler version: 8
 * (52.0) JD-Core Version: 1.1.3
 */