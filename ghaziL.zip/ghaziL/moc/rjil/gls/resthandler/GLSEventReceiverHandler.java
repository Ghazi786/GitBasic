/*     */ package com.rjil.gls.resthandler;
/*     */ 
/*     */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import com.rjil.gls.countermanager.GLSCounterManager;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GLSEventReceiverHandler
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
/*     */     try {
/*  24 */       if (req == null) {
/*  25 */         throw new NullPointerException("null request found for post ");
/*     */       }
/*  27 */       handlerequest(req, resp);
/*  28 */     } catch (Exception e) {
/*  29 */       StackTrace.printToConsole("Exception occured in post : " + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
/*     */     try {
/*  36 */       if (req == null) {
/*  37 */         throw new NullPointerException("null request found for get");
/*     */       }
/*  39 */       handlerequest(req, resp);
/*  40 */     } catch (Exception e) {
/*  41 */       StackTrace.printToConsole("Exception occured in get : " + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doPut(HttpServletRequest req, HttpServletResponse resp) {
/*     */     try {
/*  48 */       if (req == null) {
/*  49 */         throw new NullPointerException("null request found for put");
/*     */       }
/*  51 */       handlerequest(req, resp);
/*  52 */     } catch (Exception e) {
/*  53 */       StackTrace.printToConsole("Exception occured in do put : " + e.getMessage() + "/n" + e.getCause());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlerequest(HttpServletRequest httpservletrequest, HttpServletResponse resp) {
/*     */     try {
/*  62 */       String eventName = httpservletrequest.getHeader("X-Event-Name");
/*  63 */       String taskType = httpservletrequest.getHeader("X-Message-Type");
/*     */       
/*  65 */       if (eventName == null && taskType == null) {
/*     */         
/*  67 */         resp.setStatus(400);
/*     */         
/*     */         return;
/*     */       } 
/*  71 */       switch (taskType) {
/*     */         
/*     */         case "event":
/*  74 */           if (httpservletrequest.getHeader("X-Event-Name")
/*  75 */             .equals(GLSConfigurationManager.getInstance().getEventName())) {
/*  76 */             if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("unittest")) {
/*     */               
/*  78 */               StackTrace.printToConsole("Received event: " + eventName);
/*     */             }
/*  80 */             else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("loadtest")) {
/*  81 */               GLSCounterManager.getInstance().getHttpServerCount().incrementAndGet();
/*     */             } 
/*  83 */             resp.setStatus(202);
/*     */           } 
/*     */           return;
/*     */ 
/*     */         
/*     */         case "eventACK":
/*  89 */           if (httpservletrequest.getHeader("X-Event-Name")
/*  90 */             .equals(GLSConfigurationManager.getInstance().getEventName())) {
/*     */             
/*  92 */             if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("unittest")) {
/*  93 */               StackTrace.printToConsole("Received event ack for event name : " + eventName);
/*     */             }
/*  95 */             else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("loadtest")) {
/*  96 */               GLSCounterManager.getInstance().getHttpServerCount().incrementAndGet();
/*     */             } 
/*  98 */             resp.setStatus(202);
/*     */           } 
/*     */           return;
/*     */       } 
/*     */       
/* 103 */       resp.setStatus(400);
/*     */     
/*     */     }
/* 106 */     catch (Exception e) {
/*     */       
/* 108 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\resthandler\GLSEventReceiverHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */