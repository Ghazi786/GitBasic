/*    */ package com.rjil.gls.gracefulshutdown;
/*    */ 
/*    */ import com.rjil.gls.boostrapmanager.GLSBootstrapper;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerShutdownHook
/*    */   extends Thread
/*    */ {
/*    */   private GLSBootstrapper bootStrapper;
/*    */   
/*    */   public ServerShutdownHook(GLSBootstrapper bootStrapper) {
/* 16 */     this.bootStrapper = bootStrapper;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 21 */     StackTrace.printToConsole("Shutdown hook called...");
/*    */     
/* 23 */     this.bootStrapper.getJettyRestEngine().stopJettyServer();
/*    */     
/* 25 */     StackTrace.printToConsole("Mbean stopped successfully");
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\gracefulshutdown\ServerShutdownHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */