/*    */ package com.rjil.gls.gracefulshutdown;
/*    */ 
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import com.rjil.gls.metrics.jetty.CommonStatisticsMBean;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.util.Properties;
/*    */ import javax.management.JMX;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.remote.JMXConnector;
/*    */ import javax.management.remote.JMXConnectorFactory;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GracefulShutdown
/*    */ {
/*    */   public static void main(String[] args) throws IOException, MalformedObjectNameException {
/* 35 */     String jmxIP = null;
/* 36 */     String jmxPort = null;
/*    */     
/* 38 */     Properties env = new Properties();
/* 39 */     try (FileInputStream f = new FileInputStream("./run-as.sh")) {
/*    */       
/* 41 */       String os = System.getProperty("os.name").toLowerCase();
/*    */ 
/*    */       
/* 44 */       if (os.indexOf("win") < 0) {
/*    */ 
/*    */         
/* 47 */         env.load(f);
/* 48 */         jmxIP = env.getProperty("jmxip");
/* 49 */         InetAddress ip = InetAddress.getByName(jmxIP);
/*    */         
/* 51 */         if (ip instanceof java.net.Inet4Address) {
/* 52 */           jmxIP = ip.getHostAddress();
/* 53 */         } else if (ip instanceof java.net.Inet6Address) {
/*    */           
/* 55 */           jmxIP = "[" + ip.getHostAddress() + "]";
/*    */         } 
/* 57 */         jmxPort = env.getProperty("jmxport");
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/*    */     try {
/* 63 */       CommonStatisticsMBean configMBean = getERMRuntimeConfigurationEngineMBeanReference(jmxPort, jmxIP);
/* 64 */       if (configMBean != null) {
/* 65 */         configMBean.gracefulSHutdown();
/*    */       }
/* 67 */     } catch (Exception e) {
/* 68 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static CommonStatisticsMBean getERMRuntimeConfigurationEngineMBeanReference(String jmxPort, String jmxIP) throws IOException, MalformedObjectNameException {
/* 78 */     JMXConnector jmxc = null;
/*    */     
/*    */     try {
/* 81 */       JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://" + jmxIP + ":" + jmxPort + "/jmxrmi");
/* 82 */       jmxc = JMXConnectorFactory.connect(url, null);
/* 83 */       MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
/* 84 */       return JMX.<CommonStatisticsMBean>newMBeanProxy(mbsc, new ObjectName("com.rjil.gls.metrics.jetty:rtSDP_gls=CommonStatisticsMBean"), CommonStatisticsMBean.class, true);
/*    */     }
/*    */     finally {
/*    */       
/* 88 */       if (jmxc != null)
/* 89 */         jmxc.close(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\gracefulshutdown\GracefulShutdown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */