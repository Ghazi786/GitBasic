/*    */ package com.rjil.gls.constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StackTrace
/*    */ {
/*    */   public static void printToConsole(String msg) {
/* 17 */     System.out.println(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\constants\StackTrace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */