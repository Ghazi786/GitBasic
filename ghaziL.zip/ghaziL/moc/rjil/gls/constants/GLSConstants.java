package com.rjil.gls.constants;

public final class GLSConstants {
  public static final String LOG_LEVEL_ERROR = "ERROR";
  
  public static final String LOG_LEVEL_DEBUG = "DEBUG";
  
  public static final String LOG_LEVEL_INFO = "INFO";
  
  public static final String LOG_LEVEL_WARN = "WARN";
  
  public static final String LOG_LEVEL_TRACE = "TRACE";
  
  public static final String LOG_LEVEL_FATAL = "FATAL";
  
  public static final String FAILURE = "FAILURE";
  
  public static final String SUCCESS_STATUS = "SUCCESS";
  
  public static final String MBEAN_NAME_STATISTICS = "com.rjil.gls.metrics.jetty:rtSDP_gls=CommonStatisticsMBean";
  
  public static final String JETTY_UTIL_LOG_CLASS = "org.eclipse.jetty.util.log.class";
  
  public static final String JETTY_UTIL_LOG_STDERRLOG = "org.eclipse.jetty.util.log.StdErrLog";
  
  public static final String JETTY_LEVEL = "org.eclipse.jetty.LEVEL";
  
  public static final String OFF = "OFF";
  
  public static final String HTTP = "http://";
  
  public static final String HTTPS = "https://";
  
  public static final String OP_COLLON = ":";
  
  public static final String OP_SLASH = "/";
  
  public static final String HTTP2 = "http2";
  
  public static final String LOAD_TEST = "loadtest";
  
  public static final String UNIT_TEST = "unittest";
}


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\constants\GLSConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */