package com.rjil.gls.constants;

public final class GLSPropertyConstants {
  public static final String CLIENT_PATH = "./../configuration/ClientProperty.properties";
  
  public static final String RATE_LIMIT = "rateLimit";
  
  public static final String THREAD_COUNT = "threadCount";
  
  public static final String INPUT_PATH = "inputPropertyFile";
  
  public static final String IP = "ip";
  
  public static final String PORT = "port";
  
  public static final String CONTEXT = "context";
  
  public static final String REQUEST_JSON = "requestJson";
  
  public static final String HEADER_JSON = "headerJson";
  
  public static final String HTTP_METHOD = "httpMethod";
  
  public static final String CORE_POOL_SIZE = "corePoolSize";
  
  public static final String MAXIMUM_POOL_SIZE = "maximumPoolSize";
}


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\constants\GLSPropertyConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */