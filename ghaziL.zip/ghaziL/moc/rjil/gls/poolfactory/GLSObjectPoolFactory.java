/*    */ package com.rjil.gls.poolfactory;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PooledObject;
/*    */ import com.jio.telco.framework.pool.PooledObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GLSObjectPoolFactory
/*    */   implements PooledObjectFactory<Object>
/*    */ {
/* 13 */   private String objectName = null;
/* 14 */   private String className = null;
/*    */   
/*    */   public GLSObjectPoolFactory(String objName, String classsName) {
/* 17 */     this.objectName = objName;
/* 18 */     this.className = classsName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void activateObject(PooledObject<Object> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroyObject(PooledObject<Object> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void passivateObject(PooledObject<Object> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean validateObject(PooledObject<Object> arg0) {
/* 39 */     return false;
/*    */   }
/*    */   
/*    */   public String getObjectName() {
/* 43 */     return this.objectName;
/*    */   }
/*    */   
/*    */   public String getClassName() {
/* 47 */     return this.className;
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\poolfactory\GLSObjectPoolFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */