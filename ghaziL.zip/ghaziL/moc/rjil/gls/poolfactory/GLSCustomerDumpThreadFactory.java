package com.rjil.gls.poolfactory;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;
import com.rjil.gls.threadpool.GLSCustomerDumpThread;

public class GLSCustomerDumpThreadFactory implements PooledObjectFactory<GLSCustomerDumpThread>{

	@Override
	public void activateObject(PooledObject<GLSCustomerDumpThread> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroyObject(PooledObject<GLSCustomerDumpThread> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PooledObject<GLSCustomerDumpThread> makeObject() throws Exception {
		return new DefaultPooledObject(new GLSCustomerDumpThread());
	}

	@Override
	public void passivateObject(PooledObject<GLSCustomerDumpThread> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateObject(PooledObject<GLSCustomerDumpThread> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

}
