/*    */
package com.rjil.gls.poolfactory;

/*    */
/*    */ import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.subscrition.testing.SubscriberCreateThread;
import com.jio.subscrition.testing.SubscriberReadThread;
/*    */ import com.jio.telco.framework.pool.PoolBuilder;
/*    */ import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.gls.threadpool.GLSCustomerDumpThread;
import com.rjil.gls.threadpool.GLSSDRPDRSubscriptionThread;
/*    */ import com.rjil.gls.threadpool.GLSThread;
import com.rjil.gls.threadpool.GLSThreadFile;
import com.rjil.gls.threadpool.GLSUniqueIDcreationThread;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class GLSPoolingManager
/*    */ {
	/* 14 */ public static final GLSPoolingManager gLSPoolingManager = new GLSPoolingManager();

	/*    */
	/*    */
	/*    */
	/*    */
	/*    */
	/*    */ public static GLSPoolingManager getInstance() {
		/* 21 */ return gLSPoolingManager;
		/*    */ }

	/*    */
	/*    */
	/*    */
	/*    */
	/*    */ public void initialize() {
		/* 28 */ PoolBuilder builder = ResourceBuilder.objectPool().setMaxActive(-1).setMinIdle(5000).setMaxIdle(-1)
				.setWhenExhaustAction(false).setTestOnBorrow(false).setTestOnReturn(false).setTestWhileIdle(false)
				.setTimeBetweenEvictionRunsMillis(-1L).setMinEvictableIdleTimeMillis(-1L);
		/*    */
		/* 30 */ builder.createObjectPool(new GLSThreadPoolFactory(), GLSThreadFile.class);

		/* 31 */ builder.createObjectPool(new NodeRestTalkBuilderFactory(), RestTalkBuilder.class);
		builder.createObjectPool(new SubscriberReadFactory(), SubscriberReadThread.class);
		builder.createObjectPool(new SubscriberCreateFactory(), SubscriberCreateThread.class);
		builder.createObjectPool(new GLSUniqueIDcreationFactory(), GLSUniqueIDcreationThread.class);
		builder.createObjectPool(new GLSSDRPDRSubscriptionThreadFactory(), GLSSDRPDRSubscriptionThread.class);
		builder.createObjectPool(new GLSCustomerDumpThreadFactory(), GLSCustomerDumpThread.class);

		/*    */ }
	/*    */ }

/*
 * Location: C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\
 * poolfactory\GLSPoolingManager.class Java compiler version: 8 (52.0) JD-Core
 * Version: 1.1.3
 */