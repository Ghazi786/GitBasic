/*    */ package com.rjil.gls.poolfactory;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PooledObject;
/*    */ import com.jio.telco.framework.pool.impl.DefaultPooledObject;
/*    */ import com.rjil.gls.threadpool.GLSThread;
import com.rjil.gls.threadpool.GLSThreadFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSThreadPoolFactory
/*    */   extends GLSObjectPoolFactory
/*    */ {
/*    */   private static final String OBJECT_NAME = "GLSThreadFile";
/* 15 */   private static final String CLASS_NAME = GLSThreadPoolFactory.class.getSimpleName();
/*    */   
/*    */   public GLSThreadPoolFactory() {
/* 18 */     super("GLSThreadFile", CLASS_NAME);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PooledObject<Object> makeObject() throws Exception {
/* 24 */     return (PooledObject<Object>)new DefaultPooledObject(new GLSThreadFile());
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\poolfactory\GLSThreadPoolFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */