/*    */ package com.rjil.gls.poolfactory;
import com.jio.subscrition.testing.SubscriberCreateThread;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PooledObject;
/*    */ import com.jio.telco.framework.pool.PooledObjectFactory;
/*    */ import com.jio.telco.framework.pool.impl.DefaultPooledObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberCreateFactory
/*    */   implements PooledObjectFactory<Object>
/*    */ {
/*    */   private static final String OBJECT_NAME = "SubscriberCreateThread";
/* 16 */   private static final String CLASS_NAME = SubscriberCreateFactory.class.getSimpleName();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void activateObject(PooledObject<Object> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroyObject(PooledObject<Object> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PooledObject<Object> makeObject() throws Exception {
/* 32 */     return (PooledObject<Object>)new DefaultPooledObject(new SubscriberCreateThread());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void passivateObject(PooledObject<Object> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean validateObject(PooledObject<Object> arg0) {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */   public static String getObjectName() {
/* 47 */     return "SubscriberCreateThread";
/*    */   }
/*    */   
/*    */   public static String getClassName() {
/* 51 */     return CLASS_NAME;
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\poolfactory\NodeSubscriberCreateThreadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */