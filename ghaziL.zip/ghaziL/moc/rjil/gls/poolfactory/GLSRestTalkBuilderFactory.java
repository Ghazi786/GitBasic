/*    */ package com.rjil.gls.poolfactory;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PooledObject;
/*    */ import com.jio.telco.framework.pool.PooledObjectFactory;
/*    */ import com.jio.telco.framework.pool.impl.DefaultPooledObject;
/*    */ import com.rjil.gls.threadpool.GLSThread;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSRestTalkBuilderFactory
/*    */   implements PooledObjectFactory<GLSThread>
/*    */ {
/*    */   public void activateObject(PooledObject<GLSThread> arg0) throws Exception {}
/*    */   
/*    */   public void destroyObject(PooledObject<GLSThread> arg0) throws Exception {}
/*    */   
/*    */   public PooledObject<GLSThread> makeObject() throws Exception {
/* 27 */     return (PooledObject<GLSThread>)new DefaultPooledObject(new GLSThread());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void passivateObject(PooledObject<GLSThread> arg0) throws Exception {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean validateObject(PooledObject<GLSThread> arg0) {
/* 37 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\poolfactory\GLSRestTalkBuilderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */