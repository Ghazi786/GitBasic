/*    */ package com.rjil.gls.countermanager;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSCounterManager
/*    */ {
/* 11 */   private AtomicLong receivedCount = new AtomicLong(0L);
/* 12 */   private AtomicLong sendCount = new AtomicLong(0L);
/* 13 */   private AtomicLong prepareCount = new AtomicLong(0L);
/* 14 */   private AtomicLong afterPoolCount = new AtomicLong(0L);
/* 15 */   private AtomicLong afterScheduleCount = new AtomicLong(0L);
/* 16 */   private AtomicLong httpServerCount = new AtomicLong(0L);
/* 17 */   private AtomicLong successCount = new AtomicLong(0L);
/* 18 */   private AtomicLong failureCount = new AtomicLong(0L);
/* 19 */   private AtomicLong requestCountAtomicLong = new AtomicLong(0L);
/* 20 */   private AtomicLong http2ServerCount = new AtomicLong(0L);
/*    */   
/* 22 */   private AtomicLong time = new AtomicLong(0L);
/*    */   
/* 24 */   private static final GLSCounterManager glsCounterManager = new GLSCounterManager();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static GLSCounterManager getInstance() {
/* 32 */     return glsCounterManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicLong getReceivedCount() {
/* 39 */     return this.receivedCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicLong getSendCount() {
/* 46 */     return this.sendCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicLong getPrepareCount() {
/* 53 */     return this.prepareCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicLong getAfterPoolCount() {
/* 60 */     return this.afterPoolCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicLong getAfterScheduleCount() {
/* 67 */     return this.afterScheduleCount;
/*    */   }
/*    */   
/*    */   public AtomicLong getHttpServerCount() {
/* 71 */     return this.httpServerCount;
/*    */   }
/*    */   
/*    */   public AtomicLong getTime() {
/* 75 */     return this.time;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AtomicLong getSuccessCount() {
/* 82 */     return this.successCount;
/*    */   }
/*    */   
/*    */   public AtomicLong getRequestCountAtomicLong() {
/* 86 */     return this.requestCountAtomicLong;
/*    */   }
/*    */   
/*    */   public AtomicLong getFailureCount() {
/* 90 */     return this.failureCount;
/*    */   }
/*    */   
/*    */   public AtomicLong getHttp2ServerCount() {
/* 94 */     return this.http2ServerCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\countermanager\GLSCounterManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */