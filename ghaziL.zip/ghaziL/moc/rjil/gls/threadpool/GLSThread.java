/*     */ package com.rjil.gls.threadpool;
import com.fasterxml.jackson.databind.JsonNode;
/*     */ 
/*     */ import com.jio.resttalk.service.impl.RestTalkBuilder;
/*     */ import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.subscriptionengine.batchprocessing.node.startup.BatchProcessingBootStrapper;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;
import com.jio.subscriptions.modules.bean.Plan;
import com.jio.subscrition.testing.SubscriberExcelCreation;
/*     */ import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.gls.boostrapmanager.GLSBootstrapper;
/*     */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*     */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import com.rjil.gls.countermanager.GLSCounterManager;
/*     */ import com.rjil.gls.netty.client.GLSNettyHttp2Client;
/*     */ import com.rjil.gls.netty.client.Http2ClientStreamFrameResponseHandler;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.handler.codec.http2.DefaultHttp2DataFrame;
/*     */ import io.netty.handler.codec.http2.DefaultHttp2Headers;
/*     */ import io.netty.handler.codec.http2.DefaultHttp2HeadersFrame;
/*     */ import io.netty.handler.codec.http2.Http2Headers;
/*     */ import io.netty.handler.codec.http2.Http2StreamChannel;
/*     */ import io.netty.handler.codec.http2.Http2StreamChannelBootstrap;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

import com.jio.subscrition.testing.SubscriberExcelCreation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GLSThread
/*     */   implements Runnable
/*     */ {
/*  35 */   GLSConfigurationManager config = GLSConfigurationManager.getInstance();
/*  36 */   private static GLSCounterManager counter = GLSCounterManager.getInstance();
/*  37 */   RestTalkBuilder restTalkBuilder = new RestTalkBuilder();
/*     */   String ip;
/*     */   String port;
/*     */   String context;
/*     */   String requestJson;
/*     */   Map<String, String> headerMap;
/*  43 */   String choice = ((String)GLSCacheManager.getInstance().getPropertyMap().get("httpMethod")).toUpperCase();
/*     */   
/*     */   public void setParams(Map<String, String> headerMap) {
/*  46 */     this.headerMap = headerMap;
/*     */   }
/*     */   
/*  49 */   private static int requestLimit = GLSConfigurationManager.getInstance().getRateLimit() / 10 * (
/*  50 */     (GLSConfigurationManager.getInstance().getThreadCount() != 0) ? 
/*  51 */     GLSConfigurationManager.getInstance().getThreadCount() : Integer.MAX_VALUE);
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
				
//				synchronized (this) {			
					/*     */     try {
//				restTalkBuilder=(RestTalkBuilder)PoolingManager.getPoolingManager().borrowObject(RestTalkBuilder.class);
						/*  57 */       this.ip = (String)GLSCacheManager.getInstance().getPropertyMap().get("ip");
						/*  58 */       this.port = (String)GLSCacheManager.getInstance().getPropertyMap().get("port");
						/*  59 */       this.context = (String)GLSCacheManager.getInstance().getPropertyMap().get("context");
						/*  60 */       this.requestJson = (String)GLSCacheManager.getInstance().getPropertyMap().get("requestJson");
						/*     */       
						/*  62 */       if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
								/*  63 */         .equalsIgnoreCase("unittest"))
						/*     */       {
							/*  65 */         sendRequest(this.headerMap, this.requestJson, "channel","");
							/*     */       
						/*     */       }
						/*  68 */       else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
								/*  69 */         .equalsIgnoreCase("loadtest"))
						/*     */       {
							
							/*  71 */         for (int i = 0; i < requestLimit; i++) {
								
								if (GLSBootstrapper.getInstance().getThreadPoolExecutor().getQueue().size() > 5)
									continue;
								/*  72 */           counter.getPrepareCount().incrementAndGet();
								
								if(SubscriberExcelCreation.index<100 && SubscriberExcelCreation.list[SubscriberExcelCreation.index].size()>0) {
									
									
									String subId=SubscriberExcelCreation.list[SubscriberExcelCreation.index].poll();
									this.headerMap.put("X-Subscriber-Id",subId);
									CopyOnWriteArrayList<String> plans=SubscriberExcelCreation.planlist;
									
									for (String planid : plans) {
										this.context="/USER_SUBSCRIPTION_MS/?planId="+planid;
										sendRequest(this.headerMap, this.requestJson, "channel",this.context);
									}
									
									/*     */           
								}
								else {
									if(SubscriberExcelCreation.index<99)
										SubscriberExcelCreation.index++;
								}
							/*     */         }
							/*     */       
						/*     */       }
						/*     */     
					/*     */     }
					/*  80 */     catch (Exception e) {
						/*  81 */       StackTrace.printToConsole("Exception occured in run : " + e
								/*  82 */           .getMessage() + "/n" + e.getCause() + " GLSThread:run");
					/*     */     } 
//				}
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendRequest(Map<String, String> headerMap, String requestJson, String nodeName, String context2) {
/*     */     try {
/*  89 */       if (GLSConfigurationManager.getInstance().getInterfaceName().equalsIgnoreCase("http2")) {
/*     */ 
/*     */         
/*  92 */         sendNettyHttp2Request(headerMap, nodeName);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/*  97 */         sendHttpOrHttpsRequest(headerMap, requestJson,context2);
/*     */       } 
/*  99 */     } catch (Exception e) {
/*     */       
/* 101 */       StackTrace.printToConsole("Exception occured in : " + e
/* 102 */           .getMessage() + "/n" + e.getCause() + " GLSThread:sendRequest");
/*     */       
/* 104 */       reinitializeChannel(nodeName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void reinitializeChannel(String nodeName) {
/* 110 */     Channel channel = null;
/*     */     
/* 112 */     if (GLSCounterManager.getInstance().getRequestCountAtomicLong().get() % 2L == 0L) {
/* 113 */       channel = (Channel)GLSCacheManager.getInstance().getChannelMap().get(nodeName + "1");
/*     */     } else {
/* 115 */       channel = (Channel)GLSCacheManager.getInstance().getChannelMap().get(nodeName + "2");
/*     */     } 
/* 117 */     if (channel != null) {
/*     */ 
/*     */       
/* 120 */       channel.close().syncUninterruptibly();
/*     */ 
/*     */ 
/*     */       
/* 124 */       GLSCacheManager.getInstance().getChannelMap().remove(nodeName + "1");
/* 125 */       GLSCacheManager.getInstance().getChannelMap().remove(nodeName + "2");
/*     */     } 
/*     */     
/*     */     try {
/* 129 */       Thread.sleep(1000L);
/* 130 */     } catch (InterruptedException e1) {
/* 131 */       Thread.currentThread().interrupt();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 136 */     GLSNettyHttp2Client.getInstance().initializeNettyClient(nodeName + "1");
/* 137 */     GLSNettyHttp2Client.getInstance().initializeNettyClient(nodeName + "2");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendHttpOrHttpsRequest(Map<String, String> headerMap, String requestJson, String context2) {
/*     */     try {
/* 144 */       if (GLSConfigurationManager.getInstance().getInterfaceName().equalsIgnoreCase("http")) {
/* 145 */         switch (this.choice) {
/*     */           case "GET":
/* 147 */             this.restTalkBuilder.Get("http://" + this.ip + ":" + this.port + this.context);
/*     */             break;
/*     */           case "POST":
/* 150 */             this.restTalkBuilder.Post("http://" + this.ip + ":" + this.port + context2);
/*     */             break;
/*     */           case "PUT":
/* 153 */             this.restTalkBuilder.Put("http://" + this.ip + ":" + this.port + this.context);
/*     */             break;
/*     */           case "DELETE":
/* 156 */             this.restTalkBuilder.Delete("http://" + this.ip + ":" + this.port + this.context);
/*     */             break;
/*     */         } 
/*     */       
/* 160 */       } else if (GLSConfigurationManager.getInstance().getInterfaceName().equalsIgnoreCase("https")) {
/* 161 */         switch (this.choice) {
/*     */           case "GET":
/* 163 */             this.restTalkBuilder.Get("https://" + this.ip + ":" + this.port + this.context);
/*     */             break;
/*     */           case "PUT":
/* 166 */             this.restTalkBuilder.Put("https://" + this.ip + ":" + this.port + this.context);
/*     */             break;
/*     */           case "POST":
/* 169 */             this.restTalkBuilder.Post("https://" + this.ip + ":" + this.port + context2);
/*     */             break;
/*     */           case "DELETE":
/* 172 */             this.restTalkBuilder.Delete("https://" + this.ip + ":" + this.port + this.context);
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 178 */       if (requestJson != null) {
/* 179 */         this.restTalkBuilder.addRequestData(requestJson);
/*     */       }
/* 181 */       headerMap.put("X-Branch-Id", UUID.randomUUID().toString() + "_1");
/* 182 */       headerMap.put("X-Flow-Id", UUID.randomUUID().toString());
/*     */       
/* 184 */       this.restTalkBuilder.addCustomHeaders(headerMap);
/*     */       
/* 186 */       RestTalkResponse response = this.restTalkBuilder.send();
/*     */       
/* 188 */       if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("unittest")) {
/*     */         
/* 190 */         StackTrace.printToConsole("Sending http request to " + this.ip + ":" + this.port + " with headermap : " + headerMap + "\n and json body : " + requestJson);
/*     */       
/*     */       }
/* 193 */       else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
/* 194 */         .equalsIgnoreCase("loadtest")) {
/*     */         
/* 196 */         counter.getSendCount().incrementAndGet();
/*     */       } 
/* 198 */       if (response == null) {
/* 199 */         StackTrace.printToConsole("Null response received!!!");
/*     */       } else {
/*     */         
/* 202 */         if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
/* 203 */           .equalsIgnoreCase("loadtest")) {
/*     */           
/* 205 */           if (response.getHttpStatusCode() == 200 || response.getHttpStatusCode() == 202) {
/* 206 */             counter.getReceivedCount().incrementAndGet();
/*     */           } else {
/* 208 */             counter.getFailureCount().incrementAndGet();
/*     */           }
/*     */         
/* 211 */         } else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
/* 212 */           .equalsIgnoreCase("unittest")) {
/*     */           
/* 214 */           StackTrace.printToConsole("Sync Response Received " + response.getHttpStatusCode() + " with body : " + response
/* 215 */               .answeredContent().responseString());
/*     */         } 
/*     */         
					
/*     */       } 
/* 220 */     } catch (Exception e) {
/* 221 */       StackTrace.printToConsole("Exception occured : " + e.getMessage() + "/n" + e.getCause() + " GLSThread:sendHttpOrHttpsRequest");
/*     */     }
				finally {
					if(this.restTalkBuilder!=null) {
						try {
							PoolingManager.getPoolingManager().returnObject(this.restTalkBuilder);
						} catch (Exception e) {
							 StackTrace.printToConsole("Exception occured while unallocating resource : " + e.getMessage() + "/n" + e.getCause() + " GLSThread:sendHttpOrHttpsRequest");
						}
					}
				}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendNettyHttp2Request(Map<String, String> headerMap, String nodeName) {
/* 228 */     Channel channel = null;
/*     */     
/* 230 */     if (GLSCounterManager.getInstance().getRequestCountAtomicLong().get() % 2L == 0L) {
/* 231 */       channel = (Channel)GLSCacheManager.getInstance().getChannelMap().get(nodeName + "1");
/*     */     } else {
/* 233 */       channel = (Channel)GLSCacheManager.getInstance().getChannelMap().get(nodeName + "2");
/*     */     } 
/* 235 */     Http2ClientStreamFrameResponseHandler streamFrameResponseHandler = new Http2ClientStreamFrameResponseHandler();
/*     */     
/* 237 */     Http2StreamChannelBootstrap streamChannelBootstrap = new Http2StreamChannelBootstrap(channel);
/*     */     
/* 239 */     Http2StreamChannel streamChannel = (Http2StreamChannel)streamChannelBootstrap.open().syncUninterruptibly().getNow();
/*     */     
/* 241 */     streamChannel.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)streamFrameResponseHandler });
/*     */     
/* 243 */     DefaultHttp2Headers headers = new DefaultHttp2Headers();
/*     */     
/* 245 */     headers.method("POST");
/* 246 */     headers.scheme("http");
/*     */     
///* 248 */  ghazi   headerMap.forEach((k, v) -> (Http2Headers)headers.add(k, v));
/*     */     
/* 250 */     DefaultHttp2HeadersFrame defaultHttp2HeadersFrame = new DefaultHttp2HeadersFrame((Http2Headers)headers);
/*     */     
/* 252 */     streamChannel.writeAndFlush(defaultHttp2HeadersFrame);
/*     */     
/* 254 */     DefaultHttp2DataFrame defaultHttp2DataFrame = new DefaultHttp2DataFrame(Unpooled.wrappedBuffer(this.requestJson.getBytes()), true);
/*     */     
/* 256 */     streamChannel.writeAndFlush(defaultHttp2DataFrame);
/*     */     
/* 258 */     if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest().equalsIgnoreCase("loadtest")) {
/*     */       
/* 260 */       counter.getSendCount().incrementAndGet();
/*     */     }
/* 262 */     else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
/* 263 */       .equalsIgnoreCase("unittest")) {
/*     */       
/* 265 */       StackTrace.printToConsole("Sending http2 request to " + this.ip + ":" + this.port + " with headermap : " + headerMap + "\n and json body : " + this.requestJson);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     if (!streamFrameResponseHandler.responseSuccessfullyCompleted())
/* 273 */       StackTrace.printToConsole("Did not get HTTP/2 response in expected time."); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\threadpool\GLSThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */