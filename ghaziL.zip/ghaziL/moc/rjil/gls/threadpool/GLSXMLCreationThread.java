/*     */
package com.rjil.gls.threadpool;

import java.io.File;
import java.io.FileWriter;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;

/*     */
/*     */ import com.jio.resttalk.service.impl.RestTalkBuilder;
/*     */ import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.subscriptionengine.batchprocessing.utils.ObjectMapperHelper;
import com.jio.subscriptionengine.batchprocessing.utils.RequestToBeanMapper;
import com.jio.subscriptionengine.modules.sdr.ProvisioningInfo;
import com.jio.subscrition.testing.SubscriberExcelCreation;
import com.jio.subscrition.testing.SubscriptionUniqueIdStorage;
/*     */ import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.gls.boostrapmanager.GLSBootstrapper;
/*     */ import com.rjil.gls.cachemanager.GLSCacheManager;
/*     */ import com.rjil.gls.configurationmanager.GLSConfigurationManager;
/*     */ import com.rjil.gls.constants.StackTrace;
/*     */ import com.rjil.gls.countermanager.GLSCounterManager;
/*     */ import com.rjil.gls.netty.client.GLSNettyHttp2Client;
/*     */ import com.rjil.gls.netty.client.Http2ClientStreamFrameResponseHandler;

import au.com.bytecode.opencsv.CSVWriter;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.handler.codec.http2.DefaultHttp2DataFrame;
/*     */ import io.netty.handler.codec.http2.DefaultHttp2Headers;
/*     */ import io.netty.handler.codec.http2.DefaultHttp2HeadersFrame;
/*     */ import io.netty.handler.codec.http2.Http2Headers;
/*     */ import io.netty.handler.codec.http2.Http2StreamChannel;
/*     */ import io.netty.handler.codec.http2.Http2StreamChannelBootstrap;

/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */ public class GLSXMLCreationThread/*     */ implements Runnable
/*     */ {
	/* 35 */ GLSConfigurationManager config = GLSConfigurationManager.getInstance();
	/* 36 */ private static GLSCounterManager counter = GLSCounterManager.getInstance();
	/* 37 */ RestTalkBuilder restTalkBuilder = new RestTalkBuilder();
	/*     */ String ip;
	/*     */ String port;
	/*     */ String context;
	/*     */ String requestJson;
	/*     */ Map<String, String> headerMap;
	/* 43 *

	/*     */
	/*     */ public void setParams(Map<String, String> headerMap) {
		/* 46 */ this.headerMap = headerMap;
		/*     */ }

	/*     */
//	 private static int requestLimit = GLSConfigurationManager.getInstance().getRateLimit() / 10 * (
//	 (GLSConfigurationManager.getInstance().getThreadCount() != 0) ?
//	GLSConfigurationManager.getInstance().getThreadCount() : Integer.MAX_VALUE);
	private static int requestLimit = GLSConfigurationManager.getInstance().getRateLimit()
			/ ((GLSConfigurationManager.getInstance().getThreadCount() != 0)
					? GLSConfigurationManager.getInstance().getThreadCount()
					: Integer.MAX_VALUE);

//	private static int requestLimit = GLSConfigurationManager.getInstance().getRateLimit();

	/*     */
	/*     */
	/*     */
	/*     */ public void run() {

//					System.out.println("Main task working fine="+requestLimit);
//				synchronized (this) {			
		/*     */ try {
//				restTalkBuilder=(RestTalkBuilder)PoolingManager.getPoolingManager().borrowObject(RestTalkBuilder.class);
			/* 57 *

			/*     */
			/* 62 */ if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
					/* 63 */ .equalsIgnoreCase("unittest"))
			/*     */ {
				/* 65 */
				/*     */
				/*     */ }
			/* 68 */ else if (GLSConfigurationManager.getInstance().getLoadtestOrUnitTest()
					/* 69 */ .equalsIgnoreCase("loadtest"))
			/*     */ {

				/* 71 */ for (int i = 0; i < requestLimit; i++) {

					if (GLSBootstrapper.getInstance().getThreadPoolExecutor().getQueue()
							.size() > GLSConfigurationManager.getInstance().getMaxqueuesize()) {
						System.out.println("Size of queue thread ="
								+ GLSBootstrapper.getInstance().getThreadPoolExecutor().getQueue().size());
						continue;
					}
					synchronized (this) {	
					for (;SubscriptionUniqueIdStorage.start <= 1074957;SubscriptionUniqueIdStorage.start++) {
						int number = SubscriptionUniqueIdStorage.start;
						String data = SubscriptionUniqueIdStorage.xml.replace(
								"<RECORD>\r\n" + "    <OPCODE>OP_START_LOG_SEGMENT</OPCODE>\r\n" + "    <DATA>\r\n"
										+ "      <TXID>1074959</TXID>\r\n" + "    </DATA>\r\n" + "  </RECORD>\r\n"
										+ "  <RECORD>\r\n" + "    <OPCODE>OP_END_LOG_SEGMENT</OPCODE>\r\n"
										+ "    <DATA>\r\n" + "      <TXID>1074960</TXID>\r\n" + "    </DATA>\r\n"
										+ "  </RECORD>",
								String.format(
										"<RECORD>\r\n" + "    <OPCODE>OP_START_LOG_SEGMENT</OPCODE>\r\n"
												+ "    <DATA>\r\n" + "      <TXID>%d</TXID>\r\n" + "    </DATA>\r\n"
												+ "  </RECORD>\r\n" + "  <RECORD>\r\n"
												+ "    <OPCODE>OP_END_LOG_SEGMENT</OPCODE>\r\n" + "    <DATA>\r\n"
												+ "      <TXID>%d</TXID>\r\n" + "    </DATA>\r\n" + "  </RECORD>",
										number, number + 1));
						String num1=String.format("%07d", number);
						String num2=String.format("%07d", number+1);
						String fileName ="edits_000000000000"+num1+"-000000000000"+num2+".xml";
						writeinfile(fileName, data);
//						SubscriptionUniqueIdStorage.start++;

						/*     */
					}
					}
					/*     */ }
				/*     */
				/*     */ }
			/*     */
			/*     */ }
		/* 80 */ catch (Exception e) {
			e.printStackTrace();
			/* 81 */ StackTrace.printToConsole(
					"Exception occured in run : " + e/* 82 */ .getMessage() + "/n" + e.getCause() + " GLSThread:run");
			/*     */ }
//				}
		/*     */ }

	public synchronized void writeinfile(String fileName, String data) {
		try {

			String profile = System.getProperty("profile");
			String path;
			if (profile != null && profile.equals("dev")) {
				path = "./txmlData/" + fileName;
			} else {
				path = "../txmlData/" + fileName;
			}
			FileWriter out = new FileWriter(new File(path));

			out.write(data);
			out.close();
			System.out.println("file written "+ fileName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String get7DigitNumber(int a) {

		return null;
	}

}
