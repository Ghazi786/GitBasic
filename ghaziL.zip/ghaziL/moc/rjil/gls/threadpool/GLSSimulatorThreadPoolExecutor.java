/*    */ package com.rjil.gls.threadpool;
/*    */ 
/*    */ import com.jio.telco.framework.pool.PoolingManager;
/*    */ import com.rjil.gls.constants.StackTrace;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.RejectedExecutionHandler;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GLSSimulatorThreadPoolExecutor
/*    */   extends ThreadPoolExecutor
/*    */ {
/*    */   public GLSSimulatorThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue, RejectedExecutionHandler handler) {
/* 29 */     super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, handler);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GLSSimulatorThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue) {
/* 43 */     super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void afterExecute(Runnable r, Throwable t) {
/* 48 */     super.afterExecute(r, t);
/*    */     try {
/* 50 */       PoolingManager.getPoolingManager().returnObject(r);
/* 51 */     } catch (Exception e) {
/* 52 */       StackTrace.printToConsole("Exception Occured : " + e.getMessage() + "/n" + e.getCause());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getThreadPoolInfo() {
/* 60 */     StringBuilder builder = new StringBuilder("");
/* 61 */     builder.append("ActiveCount(The approximate number of threads that are actively executing tasks)              = " + 
/*    */         
/* 63 */         getActiveCount() + "\n");
/* 64 */     builder.append("CompletedTaskCount(The approximate total number of tasks that have completed execution)       = " + 
/*    */         
/* 66 */         getCompletedTaskCount() + "\n");
/* 67 */     builder.append("LargestPoolSize(The largest number of threads that have ever simultaneously been in the pool) = " + 
/*    */         
/* 69 */         getLargestPoolSize() + "\n");
/* 70 */     builder.append("PoolSize(The current number of threads in the pool)                                           = " + 
/*    */         
/* 72 */         getPoolSize() + "\n");
/* 73 */     builder.append("TaskCount(The approximate total number of tasks that have ever been scheduled for execution)  = " + 
/*    */         
/* 75 */         getTaskCount() + "\n");
/* 76 */     builder.append("Queue Size(The number of elements in this queue)                                              = " + 
/*    */         
/* 78 */         getQueue().size() + "\n");
/* 79 */     builder.append("Remaining Capacity(The number of additional elements that this queue can ideally accept\n");
/* 80 */     builder.append("without blocking, or Integer.MAX_VALUE if there is no intrinsic limit)                        = " + 
/*    */         
/* 82 */         getQueue().remainingCapacity());
/* 83 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clearQueue() {
/* 90 */     getQueue().clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\Alpesh.Sonar\Downloads\rtJIO_BC_GLS_Run.jar!\com\rjil\gls\threadpool\GLSSimulatorThreadPoolExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */