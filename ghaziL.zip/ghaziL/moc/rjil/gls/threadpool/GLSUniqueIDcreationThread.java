package com.rjil.gls.threadpool;

import java.util.UUID;

import com.jio.subscrition.testing.SubscriptionUniqueIdStorage;

public class GLSUniqueIDcreationThread implements Runnable {

	@Override
	public void run() {

		synchronized (this) {

			for (int i = 0; i < 20; i++) {

				for (int j = 0; j < 500; j++) {
					String uuid = UUID.randomUUID().toString();
					try {

						SubscriptionUniqueIdStorage.hashSet.put("Ghazi"+uuid, "Ghazi");
					} catch (Exception e) {
						System.out.println(e);
					}

				}

			}

		}

	}

}
