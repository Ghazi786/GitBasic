package com.jio.crm.dms.utils;

import java.util.Date;

public interface IMasterData {
	public Date getStartDate();
	public void setStartDate(Date startDate);
}
