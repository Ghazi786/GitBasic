package com.jio.crm.dms.utils;

public interface I {
    public String myMethod(Object o);
}
