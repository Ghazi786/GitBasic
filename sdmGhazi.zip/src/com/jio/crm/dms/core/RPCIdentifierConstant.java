package com.jio.crm.dms.core;

public class RPCIdentifierConstant {

	public static final byte CUSTOMER_ID = 1;

	private RPCIdentifierConstant() {
		super();

	}

}
