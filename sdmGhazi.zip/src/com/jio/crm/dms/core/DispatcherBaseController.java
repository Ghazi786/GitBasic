package com.jio.crm.dms.core;

/**
 * Base controller class which will be implemented by every controllers
 * 
 * @author Barun.Rai
 * 
 */
public interface DispatcherBaseController {

}
